#!/bin/bash

source install/setup.bash

echo "=== Analyzing All ROS2 Topics QoS Settings ==="
echo ""

# Get all topics
topics=$(ros2 topic list)

# Create temporary files for categorization
reliable_file=$(mktemp)
best_effort_file=$(mktemp)
mismatch_file=$(mktemp)

for topic in $topics; do
    # Get topic info with verbose output
    info=$(ros2 topic info "$topic" -v 2>/dev/null)
    
    # Get topic type
    topic_type=$(echo "$info" | grep "Type:" | head -1 | awk '{print $2}')
    
    # Extract base type (last part after /)
    base_type=$(echo "$topic_type" | awk -F'/' '{print $NF}')
    
    # Get all QoS profiles for this topic (publishers and subscribers)
    qos_profiles=$(echo "$info" | grep "Reliability:" | awk '{print $2}')
    
    # Count unique QoS types
    unique_qos=$(echo "$qos_profiles" | sort -u)
    qos_count=$(echo "$unique_qos" | wc -l)
    
    # Check for mismatch
    if [ $qos_count -gt 1 ]; then
        echo "$topic|$base_type|MISMATCH|$qos_profiles" >> "$mismatch_file"
    else
        if echo "$unique_qos" | grep -q "BEST_EFFORT"; then
            echo "$topic|$base_type|BEST_EFFORT" >> "$best_effort_file"
        elif echo "$unique_qos" | grep -q "RELIABLE"; then
            echo "$topic|$base_type|RELIABLE" >> "$reliable_file"
        else
            echo "$topic|$base_type|UNKNOWN" >> "$reliable_file"
        fi
    fi
done

echo "=========================================="
echo "TOPICS WITH QoS MISMATCH (Publishers/Subscribers have different QoS)"
echo "=========================================="
if [ -s "$mismatch_file" ]; then
    echo "Topic | Type | Status | QoS Values"
    echo "------|------|--------|------------"
    cat "$mismatch_file" | while IFS='|' read -r topic type status qos; do
        printf "%-40s | %-20s | %-10s | %s\n" "$topic" "$type" "$status" "$qos"
    done
else
    echo "No mismatches found!"
fi

echo ""
echo "=========================================="
echo "BEST_EFFORT TOPICS"
echo "=========================================="
echo "Topic | Type"
echo "------|------"
if [ -s "$best_effort_file" ]; then
    cat "$best_effort_file" | while IFS='|' read -r topic type qos; do
        printf "%-40s | %s\n" "$topic" "$type"
    done
else
    echo "None found"
fi

echo ""
echo "=========================================="
echo "RELIABLE TOPICS"
echo "=========================================="
echo "Topic | Type"
echo "------|------"
if [ -s "$reliable_file" ]; then
    cat "$reliable_file" | while IFS='|' read -r topic type qos; do
        printf "%-40s | %s\n" "$topic" "$type"
    done
else
    echo "None found"
fi

# Cleanup
rm -f "$reliable_file" "$best_effort_file" "$mismatch_file"

echo ""
echo "=========================================="
echo "SUMMARY"
echo "=========================================="
total=$(echo "$topics" | wc -l)
echo "Total topics analyzed: $total"
