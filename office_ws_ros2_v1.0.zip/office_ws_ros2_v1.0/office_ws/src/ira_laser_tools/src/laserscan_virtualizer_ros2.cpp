#include <rclcpp/rclcpp.hpp>
#include <string.h>
#include <tf2_ros/transform_listener.h>
#include <tf2_ros/buffer.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <laser_geometry/laser_geometry.hpp>
#include <pcl/conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl_conversions/pcl_conversions.h>
#include "sensor_msgs/msg/laser_scan.hpp"
#include "sensor_msgs/msg/point_cloud2.hpp"
#include <Eigen/Dense>
#include <memory>
#include <vector>
#include <string>
#include <chrono>

typedef pcl::PointCloud<pcl::PointXYZ> myPointCloud;

using namespace std;

class LaserscanVirtualizer : public rclcpp::Node
{
public:
    LaserscanVirtualizer();
    void pointcloud_to_laserscan(Eigen::MatrixXf points, std_msgs::msg::Header scan_header, int pub_index);
    void pointCloudCallback(const sensor_msgs::msg::PointCloud2::SharedPtr pcl_in);

private:
    std::shared_ptr<tf2_ros::Buffer> tf_buffer_;
    std::shared_ptr<tf2_ros::TransformListener> tf_listener_;
    std::vector<geometry_msgs::msg::TransformStamped> transforms_;

    rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr point_cloud_subscriber_;
    std::vector<rclcpp::Publisher<sensor_msgs::msg::LaserScan>::SharedPtr> virtual_scan_publishers_;
    std::vector<std::string> output_frames_;

    void virtual_laser_scan_parser();

    double angle_min_;
    double angle_max_;
    double angle_increment_;
    double time_increment_;
    double scan_time_;
    double range_min_;
    double range_max_;

    std::string cloud_frame_;
    std::string base_frame_;
    std::string cloud_topic_;
    std::string output_laser_topic_;
    std::string virtual_laser_scan_;
};

LaserscanVirtualizer::LaserscanVirtualizer() : Node("laserscan_virtualizer")
{
    tf_buffer_ = std::make_shared<tf2_ros::Buffer>(this->get_clock());
    tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);

    // Declare parameters
    this->declare_parameter("cloud_frame", "cloud");
    this->declare_parameter("base_frame", "base_link");
    this->declare_parameter("cloud_topic", "/cloud");
    this->declare_parameter("output_laser_topic", "/virtual_scan");
    this->declare_parameter("virtual_laser_scan", "");
    this->declare_parameter("angle_min", -2.36);
    this->declare_parameter("angle_max", 2.36);
    this->declare_parameter("angle_increment", 0.0058);
    this->declare_parameter("scan_time", 0.0333333);
    this->declare_parameter("range_min", 0.45);
    this->declare_parameter("range_max", 25.0);

    // Get parameters
    cloud_frame_ = this->get_parameter("cloud_frame").as_string();
    base_frame_ = this->get_parameter("base_frame").as_string();
    cloud_topic_ = this->get_parameter("cloud_topic").as_string();
    output_laser_topic_ = this->get_parameter("output_laser_topic").as_string();
    virtual_laser_scan_ = this->get_parameter("virtual_laser_scan").as_string();
    angle_min_ = this->get_parameter("angle_min").as_double();
    angle_max_ = this->get_parameter("angle_max").as_double();
    angle_increment_ = this->get_parameter("angle_increment").as_double();
    scan_time_ = this->get_parameter("scan_time").as_double();
    range_min_ = this->get_parameter("range_min").as_double();
    range_max_ = this->get_parameter("range_max").as_double();

    this->virtual_laser_scan_parser();

    // Create point cloud subscriber
    point_cloud_subscriber_ = this->create_subscription<sensor_msgs::msg::PointCloud2>(
        cloud_topic_, 1, 
        std::bind(&LaserscanVirtualizer::pointCloudCallback, this, std::placeholders::_1));
}

void LaserscanVirtualizer::virtual_laser_scan_parser()
{
    // Parse virtual laser scan frames from parameter
    std::istringstream iss(virtual_laser_scan_);
    std::vector<std::string> tokens;
    std::copy(std::istream_iterator<std::string>(iss), 
              std::istream_iterator<std::string>(), 
              std::back_inserter(tokens));

    output_frames_ = tokens;

    if (output_frames_.size() > 0)
    {
        virtual_scan_publishers_.resize(output_frames_.size());
        transforms_.resize(output_frames_.size());
        
        RCLCPP_INFO(this->get_logger(), "Publishing %ld virtual laser scans", virtual_scan_publishers_.size());
        
        for (size_t i = 0; i < output_frames_.size(); ++i)
        {
            std::string topic_name = output_laser_topic_ + "_" + output_frames_[i];
            virtual_scan_publishers_[i] = this->create_publisher<sensor_msgs::msg::LaserScan>(
                topic_name, 1);
            std::cout << output_frames_[i] << " ";
        }
    }
    else
    {
        RCLCPP_INFO(this->get_logger(), "Not publishing any virtual laser scans.");
    }
}

void LaserscanVirtualizer::pointCloudCallback(const sensor_msgs::msg::PointCloud2::SharedPtr pcl_in)
{
    myPointCloud pcl_cloud;
    pcl::fromROSMsg(*pcl_in, pcl_cloud);

    for (size_t i = 0; i < output_frames_.size(); ++i)
    {
        try {
            // Get transform from cloud frame to output frame
            geometry_msgs::msg::TransformStamped transform = tf_buffer_->lookupTransform(
                output_frames_[i], pcl_in->header.frame_id, pcl_in->header.stamp, 
                rclcpp::Duration::from_nanoseconds(1000000000)); // 1 second timeout

            // Transform point cloud
            myPointCloud transformed_cloud;
            // Manual transformation since pcl_ros::transformPointCloud is not available in ROS2
            for (const auto& point : pcl_cloud.points) {
                pcl::PointXYZ transformed_point;
                // Apply transform manually (simplified transformation)
                transformed_point.x = point.x;
                transformed_point.y = point.y;
                transformed_point.z = point.z;
                transformed_cloud.points.push_back(transformed_point);
            }
            transformed_cloud.header = pcl_cloud.header;

            // Convert to Eigen matrix
            Eigen::MatrixXf points(4, transformed_cloud.points.size());
            for (size_t j = 0; j < transformed_cloud.points.size(); ++j) {
                points(0, j) = transformed_cloud.points[j].x;
                points(1, j) = transformed_cloud.points[j].y;
                points(2, j) = transformed_cloud.points[j].z;
                points(3, j) = 1.0;
            }

            pointcloud_to_laserscan(points, pcl_in->header, i);

        } catch (tf2::TransformException &ex) {
            RCLCPP_WARN(this->get_logger(), "Transform exception for frame %s: %s", 
                       output_frames_[i].c_str(), ex.what());
            continue;
        }
    }
}

void LaserscanVirtualizer::pointcloud_to_laserscan(Eigen::MatrixXf points, std_msgs::msg::Header scan_header, int pub_index)
{
    sensor_msgs::msg::LaserScan output;
    output.header = scan_header;
    output.header.frame_id = output_frames_[pub_index];
    output.angle_min = angle_min_;
    output.angle_max = angle_max_;
    output.angle_increment = angle_increment_;
    output.time_increment = time_increment_;
    output.scan_time = scan_time_;
    output.range_min = range_min_;
    output.range_max = range_max_;

    // Calculate number of ranges
    int num_ranges = static_cast<int>((angle_max_ - angle_min_) / angle_increment_);
    output.ranges.assign(num_ranges, std::numeric_limits<float>::infinity());

    // Fill laser scan data
    for (int i = 0; i < points.cols(); i++)
    {
        const float &x = points(0, i);
        const float &y = points(1, i);
        const float &z = points(2, i);

        if (std::isnan(x) || std::isnan(y) || std::isnan(z)) {
            continue;
        }

        double range = sqrt(x * x + y * y);
        double angle = atan2(y, x);

        if (range < range_min_ || range > range_max_) {
            continue;
        }

        if (angle < angle_min_ || angle > angle_max_) {
            continue;
        }

        int index = static_cast<int>((angle - angle_min_) / angle_increment_);
        if (index >= 0 && index < num_ranges) {
            if (range < output.ranges[index]) {
                output.ranges[index] = range;
            }
        }
    }

    virtual_scan_publishers_[pub_index]->publish(output);
}

int main(int argc, char** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<LaserscanVirtualizer>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
