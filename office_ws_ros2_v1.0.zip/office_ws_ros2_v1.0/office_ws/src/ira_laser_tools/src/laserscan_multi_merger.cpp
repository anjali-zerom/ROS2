#include <rclcpp/rclcpp.hpp>
#include <string.h>
#include <tf2_ros/transform_listener.h>
#include <tf2_ros/buffer.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <laser_geometry/laser_geometry.hpp>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <sensor_msgs/msg/point_cloud.hpp>
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <pcl_conversions/pcl_conversions.h>
#include "sensor_msgs/msg/laser_scan.hpp"
#include <Eigen/Dense>
#include <memory>
#include <vector>
#include <string>
#include <set>
#include <algorithm>
#include <chrono>

using namespace std;

class LaserscanMerger : public rclcpp::Node
{
public:
    LaserscanMerger();
    void scanCallback(const sensor_msgs::msg::LaserScan::SharedPtr scan, std::string topic);
    void pointcloud_to_laserscan(Eigen::MatrixXf points, pcl::PCLPointCloud2 *merged_cloud);

    laser_geometry::LaserProjection projector_;
    std::shared_ptr<tf2_ros::Buffer> tf_buffer_;
    std::shared_ptr<tf2_ros::TransformListener> tf_listener_;

    rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr point_cloud_publisher_;
    rclcpp::Publisher<sensor_msgs::msg::LaserScan>::SharedPtr laser_scan_publisher_;
    std::vector<rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr> scan_subscribers_;
    std::vector<bool> clouds_modified_;

    std::vector<pcl::PCLPointCloud2> clouds_;
    std::vector<std::string> input_topics_;

    void laserscan_topic_parser();

    double angle_min_;
    double angle_max_;
    double angle_increment_;
    double time_increment_;
    double scan_time_;
    double range_min_;
    double range_max_;

    std::string destination_frame_;
    std::string cloud_destination_topic_;
    std::string scan_destination_topic_;
    std::string laserscan_topics_;
};

LaserscanMerger::LaserscanMerger() : Node("laserscan_multi_merger")
{
    tf_buffer_ = std::make_shared<tf2_ros::Buffer>(this->get_clock());
    tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);

    // Declare parameters
    this->declare_parameter("destination_frame", "cart_frame");
    this->declare_parameter("cloud_destination_topic", "/merged_cloud");
    this->declare_parameter("scan_destination_topic", "/scan_multi");
    this->declare_parameter("laserscan_topics", "");
    this->declare_parameter("angle_min", -2.36);
    this->declare_parameter("angle_max", 2.36);
    this->declare_parameter("angle_increment", 0.0058);
    this->declare_parameter("scan_time", 0.0333333);
    this->declare_parameter("range_min", 0.45);
    this->declare_parameter("range_max", 25.0);

    // Get parameters
    destination_frame_ = this->get_parameter("destination_frame").as_string();
    cloud_destination_topic_ = this->get_parameter("cloud_destination_topic").as_string();
    scan_destination_topic_ = this->get_parameter("scan_destination_topic").as_string();
    laserscan_topics_ = this->get_parameter("laserscan_topics").as_string();
    angle_min_ = this->get_parameter("angle_min").as_double();
    angle_max_ = this->get_parameter("angle_max").as_double();
    angle_increment_ = this->get_parameter("angle_increment").as_double();
    scan_time_ = this->get_parameter("scan_time").as_double();
    range_min_ = this->get_parameter("range_min").as_double();
    range_max_ = this->get_parameter("range_max").as_double();

    // Use sensor data QoS profile (BEST_EFFORT)
    auto sensor_qos = rclcpp::SensorDataQoS();

    // Create publishers with sensor QoS
    point_cloud_publisher_ = this->create_publisher<sensor_msgs::msg::PointCloud2>(
        cloud_destination_topic_, sensor_qos);
    laser_scan_publisher_ = this->create_publisher<sensor_msgs::msg::LaserScan>(
        scan_destination_topic_, sensor_qos);

    this->laserscan_topic_parser();
}

void LaserscanMerger::laserscan_topic_parser()
{
    // Parse laser scan topics from parameter
    std::istringstream iss(laserscan_topics_);
    std::set<std::string> tokens;
    std::copy(std::istream_iterator<std::string>(iss), 
              std::istream_iterator<std::string>(), 
              std::inserter<std::set<std::string>>(tokens, tokens.begin()));
    
    std::vector<std::string> tmp_input_topics;
    
    // For simplicity, directly use the provided topics
    for (const auto& token : tokens) {
        tmp_input_topics.push_back(token);
    }

    std::sort(tmp_input_topics.begin(), tmp_input_topics.end());
    auto last = std::unique(tmp_input_topics.begin(), tmp_input_topics.end());
    tmp_input_topics.erase(last, tmp_input_topics.end());

    // Do not re-subscribe if the topics are the same
    if ((tmp_input_topics.size() != input_topics_.size()) || 
        !std::equal(tmp_input_topics.begin(), tmp_input_topics.end(), input_topics_.begin()))
    {
        // Clear previous subscribers
        scan_subscribers_.clear();

        input_topics_ = tmp_input_topics;

        if (input_topics_.size() > 0)
        {
            scan_subscribers_.resize(input_topics_.size());
            clouds_modified_.resize(input_topics_.size());
            clouds_.resize(input_topics_.size());
            
            RCLCPP_INFO(this->get_logger(), "Subscribing to %ld topics", scan_subscribers_.size());
            
            // Use sensor data QoS profile (BEST_EFFORT)
            auto sensor_qos = rclcpp::SensorDataQoS();
            
            for (size_t i = 0; i < input_topics_.size(); ++i)
            {
                auto callback = [this, topic = input_topics_[i]](const sensor_msgs::msg::LaserScan::SharedPtr scan) {
                    this->scanCallback(scan, topic);
                };
                
                scan_subscribers_[i] = this->create_subscription<sensor_msgs::msg::LaserScan>(
                    input_topics_[i], sensor_qos, callback);
                clouds_modified_[i] = false;
                std::cout << input_topics_[i] << " ";
            }
        }
        else
        {
            RCLCPP_INFO(this->get_logger(), "Not subscribed to any topic.");
        }
    }
}

void LaserscanMerger::scanCallback(const sensor_msgs::msg::LaserScan::SharedPtr scan, std::string topic)
{
    sensor_msgs::msg::PointCloud2 tmpCloud1;
    pcl::PCLPointCloud2 tmpCloud2;

    // Find which topic this callback is for
    size_t index = 0;
    for (size_t i = 0; i < input_topics_.size(); ++i) {
        if (input_topics_[i] == topic) {
            index = i;
            break;
        }
    }

    try {
        projector_.transformLaserScanToPointCloud(destination_frame_, *scan, tmpCloud1, *tf_buffer_);
        pcl_conversions::toPCL(tmpCloud1, tmpCloud2);
        clouds_[index] = tmpCloud2;
        clouds_modified_[index] = true;
    } catch (tf2::TransformException &ex) {
        RCLCPP_WARN(this->get_logger(), "Transform exception: %s", ex.what());
        return;
    }

    // Check if all clouds have been updated
    bool all_updated = true;
    for (size_t i = 0; i < clouds_modified_.size(); ++i) {
        if (!clouds_modified_[i]) {
            all_updated = false;
            break;
        }
    }

    if (all_updated) {
        // Merge all point clouds
        sensor_msgs::msg::PointCloud2 merged_cloud_ros;
        if (!clouds_.empty()) {
            pcl_conversions::fromPCL(clouds_[0], merged_cloud_ros);
            for (size_t i = 1; i < clouds_.size(); ++i) {
                sensor_msgs::msg::PointCloud2 cloud_ros;
                pcl_conversions::fromPCL(clouds_[i], cloud_ros);
                sensor_msgs::msg::PointCloud2 tmp;
                pcl::concatenatePointCloud(merged_cloud_ros, cloud_ros, tmp);
                merged_cloud_ros = tmp;
            }
        }

        // Publish merged point cloud
        merged_cloud_ros.header.frame_id = destination_frame_;
        merged_cloud_ros.header.stamp = this->get_clock()->now();
        point_cloud_publisher_->publish(merged_cloud_ros);

        // Convert to laser scan and publish
        if (!merged_cloud_ros.data.empty()) {
            pcl::PCLPointCloud2 pcl_cloud;
            pcl_conversions::toPCL(merged_cloud_ros, pcl_cloud);
            pointcloud_to_laserscan(Eigen::MatrixXf(), &pcl_cloud);
        }

        // Reset flags
        std::fill(clouds_modified_.begin(), clouds_modified_.end(), false);
    }
}

void LaserscanMerger::pointcloud_to_laserscan(Eigen::MatrixXf points, pcl::PCLPointCloud2 *merged_cloud)
{
    sensor_msgs::msg::LaserScan output;
    output.header.stamp = this->get_clock()->now();
    output.header.frame_id = destination_frame_;
    output.angle_min = angle_min_;
    output.angle_max = angle_max_;
    output.angle_increment = angle_increment_;
    output.time_increment = time_increment_;
    output.scan_time = scan_time_;
    output.range_min = range_min_;
    output.range_max = range_max_;

    // Calculate number of ranges
    int num_ranges = static_cast<int>((angle_max_ - angle_min_) / angle_increment_);
    output.ranges.assign(num_ranges, std::numeric_limits<float>::infinity());

    // Convert PCL point cloud to PCL PointCloud<PointXYZ>
    pcl::PointCloud<pcl::PointXYZ> cloud;
    pcl::fromPCLPointCloud2(*merged_cloud, cloud);

    // Fill laser scan data
    for (const auto& point : cloud.points) {
        if (std::isnan(point.x) || std::isnan(point.y) || std::isnan(point.z)) {
            continue;
        }

        double range = sqrt(point.x * point.x + point.y * point.y);
        double angle = atan2(point.y, point.x);

        if (range < range_min_ || range > range_max_) {
            continue;
        }

        if (angle < angle_min_ || angle > angle_max_) {
            continue;
        }

        int index = static_cast<int>((angle - angle_min_) / angle_increment_);
        if (index >= 0 && index < num_ranges) {
            if (range < output.ranges[index]) {
                output.ranges[index] = range;
            }
        }
    }

    laser_scan_publisher_->publish(output);
}

int main(int argc, char** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<LaserscanMerger>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}

