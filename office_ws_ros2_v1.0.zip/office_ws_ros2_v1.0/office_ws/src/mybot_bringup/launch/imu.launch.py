#!/usr/bin/env python3

import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # Declare launch arguments
    use_sim_time_arg = DeclareLaunchArgument(
        'use_sim_time',
        default_value='false',
        description='Use simulation time'
    )

    # Get package directories
    mybot_bringup_dir = get_package_share_directory('mybot_bringup')
    
    # IMU serial node
    imu_serial_node = Node(
        package='mybot_bringup',
        executable='led_imu.py',
        name='imu_serial',
        output='screen',
        parameters=[
            PathJoinSubstitution([mybot_bringup_dir, 'config', 'imu_serial_param.yaml']),
            {'use_sim_time': LaunchConfiguration('use_sim_time')}
        ]
    )
    
    # IMU calibration node
    imu_calibration_node = Node(
        package='mybot_bringup',
        executable='imu_calliberation.py',
        name='imu_calliberation',
        output='screen',
        parameters=[{'use_sim_time': LaunchConfiguration('use_sim_time')}]
    )
    
    # IMU raw filter node
    imu_raw_filter_node = Node(
        package='mybot_bringup',
        executable='imu_filter.py',
        name='imu_raw_filter',
        output='screen',
        parameters=[{'use_sim_time': LaunchConfiguration('use_sim_time')}],
        remappings=[
            ('/imu/imu_raw', '/imu/imu_raw_calib'),
            ('/imu/imu_filter', '/imu/imu_raw_filter')
        ]
    )
    
    # IMU filter madgwick node (ROS2 equivalent)
    imu_filter_madgwick_node = Node(
        package='imu_filter_madgwick',
        executable='imu_filter_madgwick_node',
        name='ImuFilterNodelet_imu',
        output='screen',
        parameters=[{
            'use_mag': False,
            'use_magnetic_field_msg': False,
            'publish_tf': False,
            'use_sim_time': LaunchConfiguration('use_sim_time')
        }],
        remappings=[
            ('imu/data_raw', 'imu/imu_raw_filter'),
            ('imu/data', 'imu/imu_raw_data')
        ]
    )
    
    # Final IMU filter node
    imu_final_filter_node = Node(
        package='mybot_bringup',
        executable='imu_filter.py',
        name='imu_final_filter',
        output='screen',
        parameters=[{'use_sim_time': LaunchConfiguration('use_sim_time')}],
        remappings=[
            ('/imu/imu_raw', '/imu/imu_raw_data'),
            ('/imu/imu_filter', '/imu/imu_data')
        ]
    )

    return LaunchDescription([
        # Launch arguments
        use_sim_time_arg,
        
        # Nodes
        imu_serial_node,
        imu_calibration_node,
        imu_raw_filter_node,
        imu_filter_madgwick_node,
        imu_final_filter_node,
    ])
