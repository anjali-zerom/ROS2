#!/usr/bin/env python3

from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    # Ticks based docking pattern node
    docking_pattern_node = Node(
        package='mybot_bringup',
        executable='ticks_based_docking_pattern_wrap.py',
        name='ticks_based_docking_pattern',
        output='screen'
    )

    return LaunchDescription([
        docking_pattern_node,
    ])
