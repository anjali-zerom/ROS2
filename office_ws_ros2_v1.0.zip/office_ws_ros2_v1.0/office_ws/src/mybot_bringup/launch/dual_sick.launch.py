#!/usr/bin/env python3
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, Command, TextSubstitution, PathJoinSubstitution
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():

    # Packages
    pkg_mybot_description = get_package_share_directory('mybot_description')
    pkg_mybot_bringup     = get_package_share_directory('mybot_bringup')

    # Launch arguments
    simulation    = LaunchConfiguration('simulation')
    front_sick_ip = LaunchConfiguration('front_sick_ip')
    rear_sick_ip  = LaunchConfiguration('rear_sick_ip')
    ipc_ip        = LaunchConfiguration('ipc_ip')

    # Robot description
    xacro_file = os.path.join(
        pkg_mybot_description,
        "urdf",
        "mybot.urdf.xacro"
    )

    robot_description = {
        "robot_description": Command([
            '/opt/ros/jazzy/bin/xacro ', xacro_file, ' simulation:=', simulation
        ])
    }

    robot_state_publisher_node = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        name="robot_state_publisher",
        output="screen",
        parameters=[
            robot_description,
            {"use_sim_time": simulation},
            {"publish_frequency": 100.0}
        ]
    )

    # SICK nodes
    def sick_node(name: str, ip: LaunchConfiguration, frame_id: str, topic: str, angle_start: float = -2.356194490192345, angle_end: float = 2.356194490192345):
        return Node(
            package         ='sick_safetyscanners2',
            executable      ='sick_safetyscanners2_node',
            name            = f'sick_{name}_node',
            output          ='screen',
            emulate_tty     =True,
            remappings      =[('/scan', topic)],
            parameters      =[{

                'sensor_ip': ip,
                'host_ip': ipc_ip,
                'interface_ip': '0.0.0.0',
                'host_udp_port': 0,

                'frame_id'               : frame_id,

                # MUST be floats - now configurable
                'angle_start'            : angle_start,
                'angle_end'              : angle_end,
                'time_offset'            : 0.0,
                'min_intensities'        : 0.0,

                'skip'                   : 0,
                'channel'                : 0,
                'channel_enabled'        : True,

                'general_system_state'  : True,
                'derived_settings'      : True,
                'measurement_data'      : True,
                'intrusion_data'        : True,
                'application_io_data'   : True,

                'use_persistent_config' : False,
                'publish_pointcloud'    : False,
                
                # QoS overrides - force BEST_EFFORT for scan topic
                'qos_overrides./scan.publisher.reliability': 'best_effort',
                'qos_overrides./scan.publisher.durability': 'volatile',
                'qos_overrides./scan.publisher.depth': 5,
            }]
        )

    # Front SICK with full range
    front_sick = sick_node('front', front_sick_ip, 'sick_front', '/scan_front')
    
    # Keep rear SICK with full range
    rear_sick = sick_node('rear', rear_sick_ip, 'sick_rear', '/scan_rear')

    # Laser merger - C++ version with BEST_EFFORT QoS (patched)
    merger = Node(
        package='ira_laser_tools',
        executable='laserscan_multi_merger',
        name='laserscan_multi_merger',
        output='screen',
        parameters=[{
            'destination_frame': 'base_link',
            'scan_destination_topic': '/scan',
            'laserscan_topics': '/scan_front_filtered /scan_rear_filtered',
            'angle_min': -3.1415926535,
            'angle_max':  3.1415926535,
            'angle_increment': 0.008726646,
            'scan_time': 0.033333,
            'range_min': 0.05,
            'range_max': 30.0,
            'use_sim_time': simulation,
        }]
    )

    # Final launch description
    return LaunchDescription([
        DeclareLaunchArgument('simulation',    default_value='false'),
        DeclareLaunchArgument('front_sick_ip', default_value='192.168.88.102'),
        DeclareLaunchArgument('rear_sick_ip',  default_value='192.168.88.104'),
        DeclareLaunchArgument('ipc_ip',        default_value='192.168.88.110'),

        # robot_state_publisher_node,
        front_sick,
        rear_sick,
        
        # Front angular filter using separate Python file
        Node(
            package="mybot_bringup",
            executable="angular_filter_front.py",
            name="angular_filter_front",
            output="screen",
            parameters=[{
                'range_1_start': -135.0,  # CHANGE THESE VALUES TO MODIFY RANGES
                'range_1_end': -100.0,
                'range_2_start': -90.0,
                'range_2_end': 90.0,
                'range_3_start': 100.0,
                'range_3_end': 135.0
            }]
        ),
        
        # Rear angular filter using separate Python file
        Node(
            package="mybot_bringup",
            executable="angular_filter_rear.py",
            name="angular_filter_rear",
            output="screen",
            parameters=[{
                'range_1_start': -135.0,   # CHANGE THESE VALUES FOR REAR RANGES
                'range_1_end': -100.0,
                'range_2_start': -90.0,
                'range_2_end': 90.0,
                'range_3_start': 100.0,
                'range_3_end': 135.0
            }]
        ),
        
        merger
    ])