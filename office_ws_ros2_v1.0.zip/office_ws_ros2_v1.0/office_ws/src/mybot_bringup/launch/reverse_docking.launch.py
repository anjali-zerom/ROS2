#!/usr/bin/env python3

from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    # Reverse docking node
    reverse_docking_node = Node(
        package='mybot_bringup',
        executable='ticks_based_reverse.py',
        name='docking_reverse',
        output='screen'
    )

    return LaunchDescription([
        reverse_docking_node,
    ])
