#!/usr/bin/env python3

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    # Declare launch arguments
    map_file_arg = DeclareLaunchArgument(
        'map_file',
        default_value=PathJoinSubstitution([
            FindPackageShare('mybot_bringup'),
            'map',
            'TML_H6_Fence_asrs.yaml'
        ]),
        description='Map file path'
    )

    # Map server node (lifecycle node)
    # NOTE: This is a lifecycle node that will be managed by the lifecycle_manager
    # in view_navigation.launch.py (which manages both map_server and amcl)
    map_server_node = Node(
        package='nav2_map_server',
        executable='map_server',
        name='map_server',
        output='screen',
        parameters=[{
            'yaml_filename': LaunchConfiguration('map_file'),
            'use_sim_time': False,
            'topic_name': 'map',
            'frame_id': 'map'
        }]
    )

    return LaunchDescription([
        # Launch arguments
        map_file_arg,
        
        # Nodes
        map_server_node,
    ])

