#!/usr/bin/env python3
"""
SLAM Toolbox Launch File for ROS2 AMR Localization and Mapping
"""

import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, EmitEvent, RegisterEventHandler
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node, LifecycleNode
from launch_ros.substitutions import FindPackageShare
from launch_ros.events.lifecycle import ChangeState
from launch_ros.event_handlers import OnStateTransition
from lifecycle_msgs.msg import Transition
from launch.events import matches_action
from launch.launch_description_sources import PythonLaunchDescriptionSource

def generate_launch_description():
    # Get package directory
    pkg_share = FindPackageShare('mybot_bringup').find('mybot_bringup')
    
    # Launch arguments
    use_sim_time_arg = DeclareLaunchArgument(
        'use_sim_time',
        default_value='false',
        description='Use simulation (Gazebo) clock if true'
    )
    
    slam_params_file_arg = DeclareLaunchArgument(
        'slam_params_file',
        default_value=PathJoinSubstitution([pkg_share, 'config', 'slam_toolbox_config.yaml']),
        description='Full path to SLAM Toolbox config file'
    )

    # SLAM Toolbox Node
    slam_toolbox_node = LifecycleNode(
        package='slam_toolbox',
        executable='async_slam_toolbox_node',
        name='slam_toolbox',
        namespace='',
        output='screen',
        parameters=[
            LaunchConfiguration('slam_params_file'),
            {'use_sim_time': LaunchConfiguration('use_sim_time')},
            # QoS override for hardware lidar compatibility
            {'qos_overrides./scan.subscription.reliability': 'best_effort'},
            {'qos_overrides./scan.subscription.durability': 'volatile'},
            {'qos_overrides./scan.subscription.depth': 1},
            # Increase message filter queue to prevent drops
            {'message_filter_queue_size': 100},  # Default is 10
            {'scan_queue_size': 10},
        ],
        remappings=[
            ('scan', '/scan'),
        ]
    )
    
    # Emit event to configure SLAM toolbox
    emit_configure = EmitEvent(
        event=ChangeState(
            lifecycle_node_matcher=matches_action(slam_toolbox_node),
            transition_id=Transition.TRANSITION_CONFIGURE
        )
    )
    
    # Register event handler to activate after configuring
    register_activate = RegisterEventHandler(
        OnStateTransition(
            target_lifecycle_node=slam_toolbox_node,
            start_state='configuring',
            goal_state='inactive',
            entities=[
                EmitEvent(
                    event=ChangeState(
                        lifecycle_node_matcher=matches_action(slam_toolbox_node),
                        transition_id=Transition.TRANSITION_ACTIVATE
                    )
                )
            ]
        )
    )

    return LaunchDescription([
        use_sim_time_arg,
        slam_params_file_arg,
        slam_toolbox_node,
        register_activate,
        emit_configure,
    ])