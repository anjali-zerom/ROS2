#!/usr/bin/env python3

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, GroupAction, IncludeLaunchDescription
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node, PushRosNamespace
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    # Declare launch arguments
    serial_no_arg = DeclareLaunchArgument(
        'serial_no',
        default_value='',
        description='RealSense camera serial number'
    )
    
    json_file_path_arg = DeclareLaunchArgument(
        'json_file_path',
        default_value='',
        description='Path to JSON configuration file'
    )
    
    camera_arg = DeclareLaunchArgument(
        'camera',
        default_value='camera',
        description='Camera name/namespace'
    )
    
    # Resolution arguments
    depth_width_arg = DeclareLaunchArgument('depth_width', default_value='640')
    depth_height_arg = DeclareLaunchArgument('depth_height', default_value='480')
    color_width_arg = DeclareLaunchArgument('color_width', default_value='640')
    color_height_arg = DeclareLaunchArgument('color_height', default_value='480')
    infra_width_arg = DeclareLaunchArgument('infra_width', default_value='640')
    infra_height_arg = DeclareLaunchArgument('infra_height', default_value='480')
    fisheye_width_arg = DeclareLaunchArgument('fisheye_width', default_value='640')
    fisheye_height_arg = DeclareLaunchArgument('fisheye_height', default_value='480')
    
    # FPS arguments
    depth_fps_arg = DeclareLaunchArgument('depth_fps', default_value='30')
    color_fps_arg = DeclareLaunchArgument('color_fps', default_value='30')
    infra_fps_arg = DeclareLaunchArgument('infra_fps', default_value='30')
    fisheye_fps_arg = DeclareLaunchArgument('fisheye_fps', default_value='30')
    gyro_fps_arg = DeclareLaunchArgument('gyro_fps', default_value='200')
    accel_fps_arg = DeclareLaunchArgument('accel_fps', default_value='100')
    
    # Enable/disable streams
    enable_depth_arg = DeclareLaunchArgument('enable_depth', default_value='true')
    enable_color_arg = DeclareLaunchArgument('enable_color', default_value='true')
    enable_infra1_arg = DeclareLaunchArgument('enable_infra1', default_value='true')
    enable_infra2_arg = DeclareLaunchArgument('enable_infra2', default_value='true')
    enable_fisheye_arg = DeclareLaunchArgument('enable_fisheye', default_value='false')
    enable_gyro_arg = DeclareLaunchArgument('enable_gyro', default_value='true')
    enable_accel_arg = DeclareLaunchArgument('enable_accel', default_value='true')
    enable_pointcloud_arg = DeclareLaunchArgument('enable_pointcloud', default_value='false')
    
    # Other configuration
    enable_sync_arg = DeclareLaunchArgument('enable_sync', default_value='false')
    align_depth_arg = DeclareLaunchArgument('align_depth', default_value='false')
    clip_distance_arg = DeclareLaunchArgument('clip_distance', default_value='5.0')
    linear_accel_cov_arg = DeclareLaunchArgument('linear_accel_cov', default_value='0.01')
    initial_reset_arg = DeclareLaunchArgument('initial_reset', default_value='false')
    unite_imu_method_arg = DeclareLaunchArgument(
        'unite_imu_method',
        default_value='linear_interpolation'
    )
    
    # RealSense camera node with namespace
    camera_node = GroupAction([
        PushRosNamespace(LaunchConfiguration('camera')),
        
        Node(
            package='realsense2_camera',
            executable='realsense2_camera_node',
            name='realsense2_camera_node',
            output='screen',
            parameters=[{
                'serial_no': LaunchConfiguration('serial_no'),
                'json_file_path': LaunchConfiguration('json_file_path'),
                
                # Depth stream
                'enable_depth': LaunchConfiguration('enable_depth'),
                'depth_module.profile': [
                    LaunchConfiguration('depth_width'),
                    'x',
                    LaunchConfiguration('depth_height'),
                    'x',
                    LaunchConfiguration('depth_fps')
                ],
                
                # Color stream
                'enable_color': LaunchConfiguration('enable_color'),
                'rgb_camera.profile': [
                    LaunchConfiguration('color_width'),
                    'x',
                    LaunchConfiguration('color_height'),
                    'x',
                    LaunchConfiguration('color_fps')
                ],
                
                # Infrared streams
                'enable_infra1': LaunchConfiguration('enable_infra1'),
                'enable_infra2': LaunchConfiguration('enable_infra2'),
                'infra_rgb': False,
                
                # Fisheye
                'enable_fisheye': LaunchConfiguration('enable_fisheye'),
                
                # IMU
                'enable_gyro': LaunchConfiguration('enable_gyro'),
                'enable_accel': LaunchConfiguration('enable_accel'),
                'gyro_fps': LaunchConfiguration('gyro_fps'),
                'accel_fps': LaunchConfiguration('accel_fps'),
                'unite_imu_method': LaunchConfiguration('unite_imu_method'),
                
                # Pointcloud
                'enable_pointcloud': LaunchConfiguration('enable_pointcloud'),
                'pointcloud.enable': LaunchConfiguration('enable_pointcloud'),
                
                # Sync and alignment
                'enable_sync': LaunchConfiguration('enable_sync'),
                'align_depth.enable': LaunchConfiguration('align_depth'),
                
                # Filters
                'clip_distance': LaunchConfiguration('clip_distance'),
                'linear_accel_cov': LaunchConfiguration('linear_accel_cov'),
                'initial_reset': LaunchConfiguration('initial_reset'),
            }]
        )
    ])
    
    # Uncomment below if you need IMU filtering (requires imu_filter_madgwick package)
    # imu_filter_node = Node(
    #     package='imu_filter_madgwick',
    #     executable='imu_filter_madgwick_node',
    #     name='imu_filter',
    #     output='screen',
    #     parameters=[{
    #         'use_mag': False,
    #         'publish_tf': False,
    #     }],
    #     remappings=[
    #         ('imu/data_raw', 'imu/camera_raw'),
    #     ]
    # )

    return LaunchDescription([
        # Launch arguments
        serial_no_arg,
        json_file_path_arg,
        camera_arg,
        depth_width_arg,
        depth_height_arg,
        color_width_arg,
        color_height_arg,
        infra_width_arg,
        infra_height_arg,
        fisheye_width_arg,
        fisheye_height_arg,
        depth_fps_arg,
        color_fps_arg,
        infra_fps_arg,
        fisheye_fps_arg,
        gyro_fps_arg,
        accel_fps_arg,
        enable_depth_arg,
        enable_color_arg,
        enable_infra1_arg,
        enable_infra2_arg,
        enable_fisheye_arg,
        enable_gyro_arg,
        enable_accel_arg,
        enable_pointcloud_arg,
        enable_sync_arg,
        align_depth_arg,
        clip_distance_arg,
        linear_accel_cov_arg,
        initial_reset_arg,
        unite_imu_method_arg,
        
        # Nodes
        camera_node,
        # imu_filter_node,  # Uncomment if needed
    ])
