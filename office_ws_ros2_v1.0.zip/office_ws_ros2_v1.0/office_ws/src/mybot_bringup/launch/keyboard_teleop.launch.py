#!/usr/bin/env python3

from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess

def generate_launch_description():

    keyboard_teleop_node = ExecuteProcess(
        cmd=['gnome-terminal', '--', 'ros2', 'run', 'mybot_bringup', 'mybot_teleop_keyboard.py'],
        output='screen',
    )


    return LaunchDescription([
        keyboard_teleop_node,
    ])