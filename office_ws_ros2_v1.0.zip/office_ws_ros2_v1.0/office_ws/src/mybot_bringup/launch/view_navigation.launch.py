#!/usr/bin/env python3
import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument, RegisterEventHandler, TimerAction, ExecuteProcess
from launch.event_handlers import OnProcessStart
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution, Command
from launch_ros.actions import Node, LifecycleNode
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # Package directories
    mybot_bringup_dir = get_package_share_directory('mybot_bringup')
    mybot_description_dir = get_package_share_directory('mybot_description')

    # Launch arguments
    simulation_arg = DeclareLaunchArgument(
        'simulation',
        default_value='false',
        description='Whether to run in simulation mode (true/false)'
    )
    simulation = LaunchConfiguration('simulation')

    # Robot description using xacro
    xacro_file = os.path.join(mybot_description_dir, 'urdf', 'mybot.urdf.xacro')
    robot_description = Command([
        'xacro ', xacro_file, ' simulation:=', simulation
    ])

    # RViz for navigation visualization
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2_navigation',
        arguments=['-d', PathJoinSubstitution([
            mybot_bringup_dir, 'rviz', 'view_navigation_ros2.rviz'
        ])],
        output='screen'
    )

    # Robot state publisher
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_description,
            'use_sim_time': simulation,
            'publish_frequency': 100.0
        }]
    )

    # Robot pose publisher (optional)
    robot_pose_publisher_node = Node(
        package='robot_pose_publisher',
        executable='robot_pose_publisher',
        name='robot_pose_publisher',
        output='screen'
    )

    # NOTE: odom → base_footprint is published by diff_tf.py in robot_standalone.launch.py
    # Do NOT add a static transform here as it will conflict!
    
    # NOTE: map → odom is published by AMCL
    # Do NOT add a static transform here as it will conflict!

    # TF2 web republisher (optional)
    tf2_web_republisher_node = Node(
        package='tf2_web_republisher',
        executable='tf2_web_republisher_node',
        name='tf2_web_republisher',
        output='screen'
    )

    # Map file argument
    map_file_arg = DeclareLaunchArgument(
        'map',
        default_value=PathJoinSubstitution([
            mybot_bringup_dir, 'map', 'my_amr_map.yaml'
        ]),
        description='Full path to map yaml file to load'
    )

    # ───────────────────────────────────────────────────────────────
    # Nav2 Bringup
    # ───────────────────────────────────────────────────────────────
    nav2_params_file = os.path.join(
        mybot_bringup_dir, 'config', 'nav2_params.yaml'
    )
    
    # Launch localization (map_server + AMCL)
    localization_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare('nav2_bringup'), 'launch', 'localization_launch.py'
            ])
        ),
        launch_arguments={
            'use_sim_time': simulation,
            'params_file': nav2_params_file,
            'map': LaunchConfiguration('map'),
            'autostart': 'true',
        }.items()
    )
    
    # Launch navigation (controller, planner, recoveries, bt_navigator)
    # Using standard nav2_bringup navigation_launch.py
    # Note: cmd_vel remapping is handled via controller_server parameter in nav2_params.yaml
    navigation_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare('nav2_bringup'), 'launch', 'navigation_launch.py'
            ])
        ),
        launch_arguments={
            'use_sim_time': simulation,
            'params_file': nav2_params_file,
            'autostart': 'true',
        }.items()
    )

    # ───────────────────────────────────────────────────────────────
    # Launch Description
    # ───────────────────────────────────────────────────────────────
    
    # Relay node to remap cmd_vel_nav to cmd_navigation for twist_mux compatibility
    # Nav2 controller_server publishes to /cmd_vel_nav, twist_mux expects /cmd_navigation
    cmd_vel_relay_node = Node(
        package='topic_tools',
        executable='relay',
        name='cmd_vel_to_navigation_relay',
        arguments=['/cmd_vel_nav', '/cmd_navigation'],
        output='screen'
    )
    
    # Node to activate lifecycle nodes after launch
    activate_localization_node = Node(
        package='mybot_bringup',
        executable='activate_localization.py',
        name='lifecycle_activator',
        output='screen'
    )
    
    return LaunchDescription([
        simulation_arg,
        map_file_arg,
        # robot_state_publisher_node,  # REMOVED: Already running in robot_standalone.launch.py
        localization_launch,
        navigation_launch,
        cmd_vel_relay_node,  # Relay cmd_vel → cmd_navigation

        robot_pose_publisher_node,
        tf2_web_republisher_node,
        rviz_node,
        activate_localization_node,  # Auto-activate lifecycle nodes
    ])