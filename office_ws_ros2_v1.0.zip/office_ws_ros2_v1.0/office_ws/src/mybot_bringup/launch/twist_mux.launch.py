#!/usr/bin/env python3

from launch import LaunchDescription
from launch_ros.actions import Node
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():

    twist_mux_node = Node(
        package='twist_mux',
        executable='twist_mux',
        name='twist_mux',
        parameters=[
            PathJoinSubstitution([
                FindPackageShare('mybot_bringup'),
                'config',
                'twist_mux_locks.yaml'
            ]),
            PathJoinSubstitution([
                FindPackageShare('mybot_bringup'),
                'config',
                'twist_mux_topics.yaml'
            ])
        ],
        remappings=[('cmd_vel_out', 'cmd_twist_teleop')],
        output='screen'
    )

    return LaunchDescription([
        twist_mux_node
    ])

