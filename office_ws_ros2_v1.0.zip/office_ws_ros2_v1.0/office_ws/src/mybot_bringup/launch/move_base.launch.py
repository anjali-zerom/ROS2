#!/usr/bin/env python3

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # Declare launch arguments
    odom_topic_arg = DeclareLaunchArgument(
        'odom_topic',
        default_value='odom',
        description='Odometry topic name'
    )

    # Get package directories
    mybot_bringup_dir = get_package_share_directory('mybot_bringup')

    # Move base node (ROS2 equivalent is nav2_planner + nav2_controller)
    # Note: This is a simplified conversion. Full Nav2 stack requires more configuration
    nav2_planner_node = Node(
        package='nav2_planner',
        executable='planner_server',
        name='planner_server',
        output='screen',
        parameters=[
            PathJoinSubstitution([mybot_bringup_dir, 'param', 'nav2_params.yaml']),
            {
                'use_sim_time': False,
                'planner_plugins': ['GridBased'],
                'GridBased': {
                    'plugin': 'nav2_navfn_planner/NavfnPlanner',
                    'tolerance': 0.5,
                    'use_astar': False,
                    'allow_unknown': True
                }
            }
        ]
    )
    
    nav2_controller_node = Node(
        package='nav2_controller',
        executable='controller_server',
        name='controller_server',
        output='screen',
        parameters=[
            PathJoinSubstitution([mybot_bringup_dir, 'param', 'nav2_params.yaml']),
            {
                'use_sim_time': False,
                'controller_frequency': 5.0,
                'min_x_velocity_threshold': 0.001,
                'min_y_velocity_threshold': 0.5,
                'min_theta_velocity_threshold': 0.001,
                'failure_tolerance': 0.3,
                'progress_checker_plugin': 'progress_checker',
                'goal_checker_plugins': ['general_goal_checker'],
                'controller_plugins': ['FollowPath'],
                'progress_checker': {
                    'plugin': 'nav2_controller::SimpleProgressChecker',
                    'required_movement_radius': 0.5,
                    'movement_time_allowance': 10.0
                },
                'general_goal_checker': {
                    'stateful': True,
                    'plugin': 'nav2_controller::SimpleGoalChecker',
                    'xy_goal_tolerance': 0.25,
                    'yaw_goal_tolerance': 0.25
                },
                'FollowPath': {
                    'plugin': 'nav2_regulated_pure_pursuit_controller::RegulatedPurePursuitController',
                    'desired_linear_vel': 0.5,
                    'lookahead_dist': 0.6,
                    'min_lookahead_dist': 0.3,
                    'max_lookahead_dist': 0.9,
                    'lookahead_time': 1.5,
                    'rotate_to_heading_angular_vel': 1.8,
                    'transform_tolerance': 0.1,
                    'use_velocity_scaled_lookahead_dist': False,
                    'min_approach_linear_velocity': 0.05,
                    'approach_velocity_scaling_dist': 1.0,
                    'use_collision_detection': True,
                    'max_allowed_time_to_collision_up_to_carrot': 1.0,
                    'use_regulated_linear_velocity_scaling': True,
                    'use_cost_regulated_linear_velocity_scaling': False,
                    'regulated_linear_scaling_min_radius': 0.9,
                    'regulated_linear_scaling_min_speed': 0.25,
                    'use_rotate_to_heading': True,
                    'rotate_to_heading_min_angle': 0.785,
                    'max_angular_accel': 3.2,
                    'max_robot_pose_search_dist': 10.0,
                    'use_interpolation': False
                }
            }
        ],
        remappings=[
            ('cmd_vel', '/cmd_vel_mux/input/navigation')
        ]
    )

    return LaunchDescription([
        # Launch arguments
        odom_topic_arg,
        
        # Nodes
        nav2_planner_node,
        nav2_controller_node,
    ])
