#!/usr/bin/env python3

from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    # Conveyor PLC data node
    conveyor_plc_data_node = Node(
        package='mybot_bringup',
        executable='conveyor_plc_data.py',
        name='conveyor_plc_data',
        output='screen'
    )

    return LaunchDescription([
        conveyor_plc_data_node,
    ])
