#!/usr/bin/env python3

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    # Collect laser data nodes
    collect_laser_data_far_node = Node(
        package='mybot_bringup',
        executable='collect_laser_data.py',
        name='collect_laser_data_far',
        output='screen',
        parameters=[{
            'angle_open': 60.0
        }],
        remappings=[
            ('scan_front_laser', 'front_laser_far')
        ]
    )
    
    collect_laser_data_near_node = Node(
        package='mybot_bringup',
        executable='collect_laser_data.py',
        name='collect_laser_data_near',
        output='screen',
        parameters=[{
            'angle_open': 90.0
        }],
        remappings=[
            ('scan_front_laser', 'front_laser_near')
        ]
    )
    
    # Laser line extraction nodes
    laser_line_extraction_far_node = Node(
        package='laser_line_extraction',
        executable='line_extraction_node',
        name='laser_line_extraction_far',
        output='screen',
        parameters=[{
            'frequency': 20.0,
            'frame_id': 'sick_front',
            'scan_topic': '/front_laser_far',
            'publish_markers': True,
            'min_line_points': 3,
            'min_line_length': 0.09,
            'least_sq_angle_thresh': 0.017,
            'least_sq_radius_thresh': 0.01,
            'max_line_gap': 0.1,
            'min_split_dist': 0.02,
            'bearing_std_dev': 0.0015,
            'range_std_dev': 0.01,
            'max_range': 3.5,
            'min_range': 0.2,
            'outlier_dist': 0.05
        }],
        remappings=[
            ('/line_segments', '/line_segments_far'),
            ('/line_markers', '/line_markers_far')
        ]
    )
    
    laser_line_extraction_near_node = Node(
        package='laser_line_extraction',
        executable='line_extraction_node',
        name='laser_line_extraction_near',
        output='screen',
        parameters=[{
            'frequency': 20.0,
            'frame_id': 'sick_front',
            'scan_topic': '/front_laser_near',
            'publish_markers': True,
            'min_line_points': 3,
            'min_line_length': 0.1,
            'least_sq_angle_thresh': 0.017,
            'least_sq_radius_thresh': 0.01,
            'max_line_gap': 0.01,
            'min_split_dist': 0.02,
            'bearing_std_dev': 0.0015,
            'range_std_dev': 0.01,
            'max_range': 1.0,
            'min_range': 0.2,
            'outlier_dist': 0.05
        }],
        remappings=[
            ('/line_segments', '/line_segments_near'),
            ('/line_markers', '/line_markers_near')
        ]
    )
    
    # Line segment switch node
    line_segment_switch_node = Node(
        package='mybot_bringup',
        executable='line_segment_switch.py',
        name='line_segment_switch',
        output='screen'
    )
    
    # Pattern detection node
    pattern_node = Node(
        package='mybot_bringup',
        executable='pattern.py',
        name='pattern_node',
        output='screen',
        parameters=[{
            'pattern_angle1': 3.6652,
            'pattern_angle2': 2.0944,
            'pattern_angle3': 3.6652,
            'detect_angle_tolerance': 0.2,
            'group_dist_tolerance': 0.2,
            'laser_frame_id': 'sick_front'
        }]
    )
    
    # Docker position node
    docker_position_node = Node(
        package='mybot_bringup',
        executable='docker_position.py',
        name='docker_position',
        output='screen'
    )

    return LaunchDescription([
        # Nodes
        collect_laser_data_far_node,
        collect_laser_data_near_node,
        laser_line_extraction_far_node,
        laser_line_extraction_near_node,
        line_segment_switch_node,
        pattern_node,
        docker_position_node,
    ])
