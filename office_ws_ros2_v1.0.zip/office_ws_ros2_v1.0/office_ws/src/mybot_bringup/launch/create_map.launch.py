#!/usr/bin/env python3

import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution, LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    
    # Package directories
    mybot_bringup_dir = get_package_share_directory('mybot_bringup')
    
    simulation_arg = DeclareLaunchArgument(
        'simulation',
        default_value='false',
        description='Whether to run in simulation mode (true/false)'
    )
    
    # Launch configurations
    simulation = LaunchConfiguration('simulation')
    
    # Include SLAM Toolbox launch file
    slam_toolbox_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([mybot_bringup_dir, 'launch', 'slam_toolbox.launch.py'])
        ]),
        launch_arguments={'use_sim_time': simulation}.items()
    )
    
    # RViz node for mapping visualization with use_sim_time parameter
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2_mapping',
        arguments=['-d', PathJoinSubstitution([mybot_bringup_dir, 'rviz', 'create_map_ros2.rviz'])],
        parameters=[{'use_sim_time': simulation}],
        output='screen'
    )

    # Robot pose publisher - publishes robot_pose from TF
    robot_pose_publisher_node = Node(
        package='robot_pose_publisher',
        executable='robot_pose_publisher',
        name='robot_pose_publisher',
        parameters=[{
            'use_sim_time': simulation,
            'is_stamped': True,
            'base_frame': 'base_footprint'
        }],
        output='screen'
    )
    
    return LaunchDescription([
        simulation_arg,
        slam_toolbox_launch,
        rviz_node,
        robot_pose_publisher_node,
    ])
