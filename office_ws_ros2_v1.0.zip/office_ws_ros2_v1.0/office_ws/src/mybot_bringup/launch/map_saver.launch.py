#!/usr/bin/env python3

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    # Declare launch arguments
    map_file_arg = DeclareLaunchArgument(
        'map_file',
        default_value=PathJoinSubstitution([
            FindPackageShare('mybot_bringup'),
            'map',
            'TML_H6_Fence_asrs'
        ]),
        description='Map file path without extension'
    )

    # Map saver node
    map_saver_node = Node(
        package='nav2_map_server',
        executable='map_saver_cli',
        name='map_saver',
        output='screen',
        arguments=[
            '-f', LaunchConfiguration('map_file')
        ]
    )

    return LaunchDescription([
        # Launch arguments
        map_file_arg,
        
        # Nodes
        map_saver_node,
    ])
