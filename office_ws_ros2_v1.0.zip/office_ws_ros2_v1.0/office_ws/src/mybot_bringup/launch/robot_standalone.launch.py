#!/usr/bin/env python3

import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution, Command
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    # Package directories
    mybot_bringup_dir = get_package_share_directory('mybot_bringup')
    mybot_description_dir = get_package_share_directory('mybot_description')

    # Declare launch arguments
    simulation_arg = DeclareLaunchArgument(
        'simulation',
        default_value='false',
        description='Whether to run in simulation mode (true/false)'
    )

    front_sick_ip_arg = DeclareLaunchArgument(
        'front_sick_ip',
        default_value='192.168.88.102',
        description='Front SICK lidar IP address'
    )

    rear_sick_ip_arg = DeclareLaunchArgument(
        'rear_sick_ip',
        default_value='192.168.88.104',
        description='Rear SICK lidar IP address'
    )

    ipc_ip_arg = DeclareLaunchArgument(
        'IPC_ip',
        default_value='192.168.88.110',
        description='IPC IP address'
    )

    plc_ip_arg = DeclareLaunchArgument(
        'plc_ip',
        default_value='192.168.100.211',
        description='PLC IP address'
    )

    left_cam_sn_arg = DeclareLaunchArgument(
        'left_cam_sn',
        default_value='233522076538',
        description='Left camera serial number'
    )

    right_cam_sn_arg = DeclareLaunchArgument(
        'right_cam_sn',
        default_value='233522078056',
        description='Right camera serial number'
    )

    # Launch configurations
    simulation = LaunchConfiguration('simulation')

    # Robot description using xacro
    xacro_file = os.path.join(mybot_description_dir, 'urdf', 'mybot.urdf.xacro')

    robot_description = {
        "robot_description": Command([
            'xacro ', xacro_file, ' simulation:=', simulation
        ])
    }

    # Nodes
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[
            robot_description,
            {'use_sim_time': simulation},
            {'publish_frequency': 100.0}
        ]
    )

    # Python nodes from mybot_bringup
    plc_data_node = Node(
        package='mybot_bringup',
        executable='plc_data.py',
        name='plc_data',
        output='screen',
        parameters=[{
            'plc_ip': LaunchConfiguration('plc_ip'),
            'use_sim_time': LaunchConfiguration('simulation')
        }]
    )

    shutdown_node = Node(
        package='mybot_bringup',
        executable='shutdown.py',
        name='shutdown_button_pushed',
        output='screen',
        parameters=[{'use_sim_time': LaunchConfiguration('simulation')}]
    )
    
    battery_comm_node = Node(
        package='mybot_bringup',
        executable='battery_comm.py',
        name='battery_comm',
        output='screen',
        parameters=[{'use_sim_time': LaunchConfiguration('simulation')}]
    )

    twist_to_motors_node = Node(
        package='mybot_bringup',
        executable='twist_to_motors.py',
        name='twist_to_motors',
        output='screen',
        parameters=[{
            'base_width': 0.718,
            'ticks_meter': 452500,
            'use_sim_time': LaunchConfiguration('simulation')
        }]
    )
    
    moons_emergency_node = Node(
        package='mybot_bringup',
        executable='moons_emergency.py',
        name='moons_emergency',
        output='screen',
        parameters=[{'use_sim_time': LaunchConfiguration('simulation')}]
    )
    
    diff_tf_node = Node(
        package='mybot_bringup',
        executable='diff_tf.py',
        name='diff_tf',
        output='screen',
        parameters=[{'use_sim_time': LaunchConfiguration('simulation'),
                     'publish_tf': False}]  # EKF will publish the TF instead
    )
    
    teleop_filter_node = Node(
        package='mybot_bringup',
        executable='teleop_filter.py',
        name='teleop_filter',
        output='screen',
        parameters=[{'use_sim_time': LaunchConfiguration('simulation')}]
    )
    
    led_color_speaker_node = Node(
        package='mybot_bringup',
        executable='ledstate_speakercontrol.py',
        name='robot_state_led_tone',
        output='screen',
        parameters=[{'use_sim_time': LaunchConfiguration('simulation')}]
    )
    
    twist_mux_node = Node(
        package='twist_mux',
        executable='twist_mux',
        name='twist_mux',
        parameters=[
            PathJoinSubstitution([FindPackageShare('mybot_bringup'), 'config', 'twist_mux_locks.yaml']),
            PathJoinSubstitution([FindPackageShare('mybot_bringup'), 'config', 'twist_mux_topics.yaml'])
        ],
        remappings=[('cmd_vel_out', 'cmd_twist_teleop')],
        output='screen'
    )

    # Include dual SICK lidar launch file (forward IP arguments if needed)
    dual_sick_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('mybot_bringup'),
                'launch',
                'dual_sick.launch.py'
            ])
        ]),
        launch_arguments={
            'front_sick_ip': LaunchConfiguration('front_sick_ip'),
            'rear_sick_ip': LaunchConfiguration('rear_sick_ip')
        }.items()
    )
    
    # Include IMU launch file
    imu_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([mybot_bringup_dir, 'launch', 'imu.launch.py'])
        ]),
        launch_arguments={
            'use_sim_time': LaunchConfiguration('simulation')
        }.items()
    )

    # EKF localization
    ekf_node = Node(
        package='robot_localization',
        executable='ekf_node',
        name='ekf_filter_node',
        output='screen',
        parameters=[
            PathJoinSubstitution([mybot_bringup_dir, 'config', 'ekf_params_imu.yaml']),
            {'use_sim_time': LaunchConfiguration('simulation')}
        ],
        remappings=[
            ('odometry/filtered', 'odom')
        ]
    )
    
    # Return the complete launch description
    return LaunchDescription([
        # Launch arguments
        simulation_arg,
        front_sick_ip_arg,
        rear_sick_ip_arg,
        ipc_ip_arg,
        plc_ip_arg,
        left_cam_sn_arg,
        right_cam_sn_arg,

        # Nodes
        robot_state_publisher_node,
        
        plc_data_node,
        shutdown_node,
        battery_comm_node,
        twist_to_motors_node,
        moons_emergency_node,
        diff_tf_node,  # Publishes /noisy_odom (TF disabled, EKF handles it)
        teleop_filter_node,
        led_color_speaker_node,
        
        twist_mux_node,

        # Included launch files
        dual_sick_launch,
        imu_launch,
        
        # EKF for sensor fusion and TF broadcasting (odom -> base_footprint)
        ekf_node,
    ])