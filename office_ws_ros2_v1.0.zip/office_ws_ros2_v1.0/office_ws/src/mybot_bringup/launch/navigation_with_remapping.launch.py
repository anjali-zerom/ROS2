#!/usr/bin/env python3
"""
Custom navigation launch file that properly remaps cmd_vel to cmd_navigation
for compatibility with twist_mux configuration from ROS1.

This replaces the standard nav2_bringup/navigation_launch.py with proper remapping.
"""

import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, GroupAction, TimerAction
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    # Get package directories
    mybot_bringup_dir = get_package_share_directory('mybot_bringup')
    nav2_bringup_dir = get_package_share_directory('nav2_bringup')

    # Declare launch arguments
    use_sim_time_arg = DeclareLaunchArgument(
        'use_sim_time',
        default_value='false',
        description='Use simulation time'
    )

    params_file_arg = DeclareLaunchArgument(
        'params_file',
        default_value=PathJoinSubstitution([mybot_bringup_dir, 'config', 'nav2_params.yaml']),
        description='Full path to the ROS2 parameters file'
    )

    autostart_arg = DeclareLaunchArgument(
        'autostart',
        default_value='true',
        description='Automatically startup the nav2 stack'
    )

    # Launch configurations
    use_sim_time = LaunchConfiguration('use_sim_time')
    params_file = LaunchConfiguration('params_file')
    autostart = LaunchConfiguration('autostart')

    # Controller Server with remapping
    controller_server_node = Node(
        package='nav2_controller',
        executable='controller_server',
        name='controller_server',
        output='screen',
        parameters=[params_file],
        remappings=[
            ('cmd_vel', 'cmd_navigation'),  # Remap to twist_mux navigation input
        ]
    )

    # Planner Server
    planner_server_node = Node(
        package='nav2_planner',
        executable='planner_server',
        name='planner_server',
        output='screen',
        parameters=[params_file]
    )

    # Behavior Server (formerly recoveries_server)
    behavior_server_node = Node(
        package='nav2_behaviors',
        executable='behavior_server',
        name='behavior_server',
        output='screen',
        parameters=[params_file]
    )

    # BT Navigator
    bt_navigator_node = Node(
        package='nav2_bt_navigator',
        executable='bt_navigator',
        name='bt_navigator',
        output='screen',
        parameters=[params_file]
    )

    # Waypoint Follower
    waypoint_follower_node = Node(
        package='nav2_waypoint_follower',
        executable='waypoint_follower',
        name='waypoint_follower',
        output='screen',
        parameters=[params_file]
    )

    # Lifecycle Manager for Navigation
    # Increased bond_timeout to give nodes more time to start
    lifecycle_manager_navigation_node = Node(
        package='nav2_lifecycle_manager',
        executable='lifecycle_manager',
        name='lifecycle_manager_navigation',
        output='screen',
        parameters=[
            {'use_sim_time': use_sim_time},
            {'autostart': autostart},
            {'node_names': [
                'controller_server',
                'planner_server',
                'behavior_server',
                'bt_navigator',
                'waypoint_follower'
            ]},
            {'bond_timeout': 10.0},  # Increased from 4.0 to 10.0
            {'bond_respawn_max_duration': 10.0},
            {'attempt_respawn_reconnection': True}
        ]
    )

    return LaunchDescription([
        # Launch arguments
        use_sim_time_arg,
        params_file_arg,
        autostart_arg,

        # Nodes - start immediately
        controller_server_node,
        planner_server_node,
        behavior_server_node,
        bt_navigator_node,
        waypoint_follower_node,
        
        # Lifecycle manager - start with a 2 second delay to ensure nodes are ready
        TimerAction(
            period=2.0,
            actions=[lifecycle_manager_navigation_node]
        ),
    ])
