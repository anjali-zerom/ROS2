#!/usr/bin/env python3

import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, GroupAction, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # Left camera arguments
    left_serial_no_arg = DeclareLaunchArgument('left_serial_no', default_value='', description='Left camera serial number')
    left_json_file_path_arg = DeclareLaunchArgument('left_json_file_path', default_value='', description='Left camera JSON config file path')
    
    # Right camera arguments
    right_serial_no_arg = DeclareLaunchArgument('right_serial_no', default_value='', description='Right camera serial number')
    right_json_file_path_arg = DeclareLaunchArgument('right_json_file_path', default_value='', description='Right camera JSON config file path')
    
    # Common camera parameters
    fisheye_width_arg = DeclareLaunchArgument('fisheye_width', default_value='640', description='Fisheye width')
    fisheye_height_arg = DeclareLaunchArgument('fisheye_height', default_value='480', description='Fisheye height')
    enable_fisheye_arg = DeclareLaunchArgument('enable_fisheye', default_value='false', description='Enable fisheye')
    
    depth_width_arg = DeclareLaunchArgument('depth_width', default_value='640', description='Depth width')
    depth_height_arg = DeclareLaunchArgument('depth_height', default_value='480', description='Depth height')
    enable_depth_arg = DeclareLaunchArgument('enable_depth', default_value='true', description='Enable depth')
    
    color_width_arg = DeclareLaunchArgument('color_width', default_value='640', description='Color width')
    color_height_arg = DeclareLaunchArgument('color_height', default_value='480', description='Color height')
    enable_color_arg = DeclareLaunchArgument('enable_color', default_value='true', description='Enable color')
    
    # Left camera node
    left_camera_node = Node(
        package='realsense2_camera',
        executable='realsense2_camera_node',
        name='camera_left',
        namespace='camera_left',
        output='screen',
        parameters=[{
            'serial_no': LaunchConfiguration('left_serial_no'),
            'json_file_path': LaunchConfiguration('left_json_file_path'),
            'camera_name': 'camera_left',
            'tf_prefix': 'camera_left',
            'fisheye_width': LaunchConfiguration('fisheye_width'),
            'fisheye_height': LaunchConfiguration('fisheye_height'),
            'enable_fisheye': LaunchConfiguration('enable_fisheye'),
            'depth_width': LaunchConfiguration('depth_width'),
            'depth_height': LaunchConfiguration('depth_height'),
            'enable_depth': LaunchConfiguration('enable_depth'),
            'color_width': LaunchConfiguration('color_width'),
            'color_height': LaunchConfiguration('color_height'),
            'enable_color': LaunchConfiguration('enable_color'),
            'fisheye_fps': 30,
            'depth_fps': 30,
            'color_fps': 30,
            'enable_sync': False,
            'align_depth': False,
            'enable_pointcloud': False,
            'pointcloud_texture_stream': 'RS2_STREAM_COLOR',
            'pointcloud_texture_index': 0,
            'allow_no_texture_points': True,
            'clip_distance': 5.0,
            'linear_accel_cov': 0.01,
            'initial_reset': False,
            'reconnect_timeout': 6.0,
            'enable_infra1': True,
            'enable_infra2': True,
            'enable_gyro': True,
            'enable_accel': True,
            'gyro_fps': 200,
            'accel_fps': 100,
            'unite_imu_method': 'linear_interpolation',
            'publish_odom_tf': True
        }]
    )
    
    # Right camera node
    right_camera_node = Node(
        package='realsense2_camera',
        executable='realsense2_camera_node',
        name='camera_right',
        namespace='camera_right',
        output='screen',
        parameters=[{
            'serial_no': LaunchConfiguration('right_serial_no'),
            'json_file_path': LaunchConfiguration('right_json_file_path'),
            'camera_name': 'camera_right',
            'tf_prefix': 'camera_right',
            'fisheye_width': LaunchConfiguration('fisheye_width'),
            'fisheye_height': LaunchConfiguration('fisheye_height'),
            'enable_fisheye': LaunchConfiguration('enable_fisheye'),
            'depth_width': LaunchConfiguration('depth_width'),
            'depth_height': LaunchConfiguration('depth_height'),
            'enable_depth': LaunchConfiguration('enable_depth'),
            'color_width': LaunchConfiguration('color_width'),
            'color_height': LaunchConfiguration('color_height'),
            'enable_color': LaunchConfiguration('enable_color'),
            'fisheye_fps': 30,
            'depth_fps': 30,
            'color_fps': 30,
            'enable_sync': False,
            'align_depth': False,
            'enable_pointcloud': False,
            'pointcloud_texture_stream': 'RS2_STREAM_COLOR',
            'pointcloud_texture_index': 0,
            'allow_no_texture_points': True,
            'clip_distance': 5.0,
            'linear_accel_cov': 0.01,
            'initial_reset': False,
            'reconnect_timeout': 6.0,
            'enable_infra1': True,
            'enable_infra2': True,
            'enable_gyro': True,
            'enable_accel': True,
            'gyro_fps': 200,
            'accel_fps': 100,
            'unite_imu_method': 'linear_interpolation',
            'publish_odom_tf': True
        }]
    )

    return LaunchDescription([
        # Launch arguments
        left_serial_no_arg,
        left_json_file_path_arg,
        right_serial_no_arg,
        right_json_file_path_arg,
        fisheye_width_arg,
        fisheye_height_arg,
        enable_fisheye_arg,
        depth_width_arg,
        depth_height_arg,
        enable_depth_arg,
        color_width_arg,
        color_height_arg,
        enable_color_arg,
        
        # Camera nodes
        left_camera_node,
        right_camera_node,
    ])
