#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from geometry_msgs.msg import Twist

class TwistToMotors(Node):
    
    def __init__(self):
        super().__init__('twist_to_motors')
        
        qos_profile_best_effort = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        # --- Parameters ---
        # Declare parameters with default values
        self.declare_parameter('base_width', 0.734)  # MUST match diff_tf.py!
        self.declare_parameter('rate', 50)
        self.declare_parameter('timeout_ticks', 2)

        # Get parameter values
        self.w = self.get_parameter('base_width').value
        self.rate_hz = self.get_parameter('rate').value
        self.timeout_ticks = self.get_parameter('timeout_ticks').value

        self.get_logger().info(f"{self.get_name()} started")
        
        # --- Publishers & Subscribers ---
        self.pub_motor = self.create_publisher(Twist, 'cmd_vel', qos_profile_best_effort)
        self.create_subscription(Twist, 'cmd_teleop_filter', self.twist_callback, qos_profile_best_effort)
        
        # --- Variables ---
        self.left = 0.0
        self.right = 0.0
        self.dx = 0.0
        self.dr = 0.0
        self.dy = 0.0
        
        # Initialize as "timed out" so robot doesn't move on startup until first msg
        self.ticks_since_target = self.timeout_ticks 

        # --- Timer ---
        # Instead of a while loop, we create a timer that runs at 'rate' Hz
        timer_period = 1.0 / self.rate_hz
        self.timer = self.create_timer(timer_period, self.timer_callback)

    def timer_callback(self):
        """
        This replaces the 'spin' and 'while' loops from the ROS 1 script.
        It runs periodically at the defined rate.
        """
        if self.ticks_since_target < self.timeout_ticks:
            self.calc_and_publish()
            self.ticks_since_target += 1
        else:
            # This is the 'idle' state. 
            # We do nothing here, effectively waiting for a new message to reset ticks.
            pass

    def calc_and_publish(self):
        # --- Kinematics Calculation ---
        # Note: Logic preserved from original script (Sumitomo config)
        
        # Calculate Right Wheel
        # self.right = -1*(1.0 * self.dx + self.dr * self.w / 2) # leadshine
        # self.right = 1*(1.0 * self.dx + self.dr * self.w / 2)  # moons
        self.right = 1.0 * (1.0 * self.dx + self.dr * self.w / 2) # sumitomo

        # Calculate Left Wheel
        # self.left = 1*(1.0 * self.dx - self.dr * self.w / 2 )  # leadshine
        # self.left = -1*(1.0 * self.dx - self.dr * self.w / 2 ) # moons
        self.left = -1.0 * (1.0 * self.dx - self.dr * self.w / 2 ) # sumitomo

        # --- Construct Message ---
        # Using Twist to transport individual wheel velocities is non-standard
        # but preserved here to match your specific driver requirements.
        motor_msg = Twist()
        
        motor_msg.linear.x = float(self.left)
        motor_msg.linear.y = 0.0 
        motor_msg.linear.z = 0.0        
        
        motor_msg.angular.x = 0.0
        motor_msg.angular.y = 0.0
        motor_msg.angular.z = float(self.right)
        
        self.pub_motor.publish(motor_msg)

    def twist_callback(self, msg):
        # Reset timeout counter whenever a command is received
        self.ticks_since_target = 0
        
        self.dx = msg.linear.x
        self.dr = msg.angular.z
        self.dy = msg.linear.y

def main(args=None):
    rclpy.init(args=args)
    
    twist_to_motors = TwistToMotors()
    
    try:
        rclpy.spin(twist_to_motors)
    except KeyboardInterrupt:
        pass
    finally:
        twist_to_motors.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()