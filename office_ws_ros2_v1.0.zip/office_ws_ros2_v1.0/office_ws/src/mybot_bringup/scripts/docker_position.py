#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import tf2_ros
import tf2_geometry_msgs
from tf2_ros import LookupException, ConnectivityException, ExtrapolationException
import math
from math import pow, atan2, sqrt, pi
from geometry_msgs.msg import PoseStamped, Pose
from geometry_msgs.msg import PoseWithCovarianceStamped
import numpy as np
from scipy import signal
from tf_transformations import euler_from_quaternion

class DockerPositionNode(Node):
    def __init__(self):
        super().__init__('docker_position_node')  # Fixed typo in node name
        
        self.get_logger().info("docker_position_node initiated")
        
        # Create TF2 buffer and listener
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)
        
        # Create publisher
        self.raw_doc_pos_publisher = self.create_publisher(
            Twist,
            '/raw_docker_pose',
            10
        )
        
        # Initialize pose message
        self.raw_doc_pose = Twist()
        self.raw_doc_pose.linear.x = 0.0
        self.raw_doc_pose.linear.y = 0.0
        self.raw_doc_pose.linear.z = 0.0
        self.raw_doc_pose.angular.x = 0.0
        self.raw_doc_pose.angular.y = 0.0
        self.raw_doc_pose.angular.z = 0.0
        
        # Create timer for 20 Hz operation
        self.timer = self.create_timer(0.05, self.timer_callback)  # 20 Hz = 0.05s
        
    def timer_callback(self):
        try:
            # Look up transform
            transform = self.tf_buffer.lookup_transform(
                'dock_frame',
                'upper_base_link',
                rclpy.time.Time()
            )
            
            # Extract translation
            x = transform.transform.translation.x
            y = transform.transform.translation.y
            
            # Extract rotation and convert to euler
            quaternion = [
                transform.transform.rotation.x,
                transform.transform.rotation.y,
                transform.transform.rotation.z,
                transform.transform.rotation.w
            ]
            rot_to_euler = euler_from_quaternion(quaternion)
            z = (rot_to_euler[2] * 180) / math.pi
            
            # Set pose values
            self.raw_doc_pose.linear.x = -y
            self.raw_doc_pose.linear.y = -x
            self.raw_doc_pose.angular.z = z

            self.raw_doc_pos_publisher.publish(self.raw_doc_pose)

        except (LookupException, ConnectivityException, ExtrapolationException) as e:
            # Transform not available, continue
            pass

def main(args=None):
    rclpy.init(args=args)
    
    docker_position_node = DockerPositionNode()
    
    try:
        rclpy.spin(docker_position_node)
    except KeyboardInterrupt:
        pass
    finally:
        docker_position_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
