#!/usr/bin/env python3
import serial
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from std_msgs.msg import Int16, Float32
import struct
import time

class BatteryCommNode(Node):
    def __init__(self):
        super().__init__('battery_serial_node')
        
        qos_profile_reliable = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=5
        )
        self.get_logger().info("Battery serial communication")
        
        # Declare parameters
        self.declare_parameter('serial_port', '/dev/ttyS1')
        self.declare_parameter('baudrate', 9600)
        self.declare_parameter('bytesize', 8)
        self.declare_parameter('parity', 'N')
        self.declare_parameter('stopbits', 1)
        self.declare_parameter('timeout', 0.5)
        
        # Get parameters
        port = self.get_parameter('serial_port').get_parameter_value().string_value
        baudrate = self.get_parameter('baudrate').get_parameter_value().integer_value
        bytesize = self.get_parameter('bytesize').get_parameter_value().integer_value
        parity = self.get_parameter('parity').get_parameter_value().string_value
        stopbits = self.get_parameter('stopbits').get_parameter_value().integer_value
        timeout = self.get_parameter('timeout').get_parameter_value().double_value
        
        # Set up ROS publishers for battery data
        self.battery_percentage_publisher = self.create_publisher(Int16, '/battery_percentage', qos_profile_reliable)
        self.battery_voltage_publisher = self.create_publisher(Float32, '/battery_voltage', qos_profile_reliable)
        self.battery_current_publisher = self.create_publisher(Float32, '/battery_current', qos_profile_reliable)
        self.battery_temperature_publisher = self.create_publisher(Float32, '/battery_temperature', qos_profile_reliable)
        
        # Configure serial port
        self.com_port = serial.Serial()
        self.com_port.port = port
        self.com_port.baudrate = baudrate
        self.com_port.bytesize = bytesize
        self.com_port.parity = parity
        self.com_port.stopbits = stopbits
        self.com_port.timeout = timeout
        
        # Command to read basic battery information (0x03)
        self.data = bytearray(b'\xDD\xA5\x03\x00\xFF\xFD\x77')
        
        if self.com_port.is_open:
            self.com_port.close()
        time.sleep(0.5)
        
        # Create timer for 1 Hz operation
        self.timer = self.create_timer(1.0, self.battery_communication_loop)
        
    def battery_communication_loop(self):
        try:
            # Open serial port, send command, read response
            self.com_port.open()
            self.com_port.write(self.data)
            time.sleep(0.005)
            data_in = self.com_port.read(49)
            self.com_port.close()
            
            if len(data_in) > 48:
                # Extract data for CRC calculation (from status to end of data)
                data_received = data_in[2:-3]
                
                # Calculate CRC: sum of bytes, invert, add 1
                crc_sum = 0
                for i in range(len(data_received)):
                    crc_sum += data_received[i]  # No need for ord() in Python 3
                
                crc_sum_hex = format(crc_sum, '04x')
                crc_sum_int = int(crc_sum_hex, 16)
                crc_sum_inv = ~crc_sum_int & 0xFFFF
                crc_sum_final = crc_sum_inv + 1
                
                # Extract incoming CRC from response
                crc_incoming_hex_1 = format(data_in[-3], "x")
                crc_incoming_hex_2 = format(data_in[-2], "x")
                crc_incoming_hex = hex(int(crc_incoming_hex_1, 16) << 8 | int(crc_incoming_hex_2, 16))
                crc_incoming = int(crc_incoming_hex, 16)
                
                # Validate CRC
                if crc_incoming == crc_sum_final:
                    # Extract and publish battery percentage (SOC)
                    battery_percentage_msg = Int16()
                    battery_percentage_msg.data = data_in[23]
                    self.battery_percentage_publisher.publish(battery_percentage_msg)
                    
                    # Extract and publish battery voltage (unit: V, from 10mV)
                    data_in_4 = format(data_in[4], "x")
                    data_in_5 = format(data_in[5], "x")
                    battery_voltage_hex = data_in_4 + data_in_5
                    battery_voltage_msg = Float32()
                    battery_voltage_msg.data = float(int(battery_voltage_hex, 16)) / 100
                    self.battery_voltage_publisher.publish(battery_voltage_msg)
                    
                    # Extract and publish battery current (signed, unit: A, from 10mA)
                    battery_current_raw = struct.unpack('>h', data_in[6:8])[0]
                    battery_current_msg = Float32()
                    battery_current_msg.data = battery_current_raw / 100.0
                    self.battery_current_publisher.publish(battery_current_msg)
          
        except Exception as e:
            self.get_logger().error(f"Error in serial communication: {str(e)}")

def main(args=None):
    rclpy.init(args=args)
    
    battery_node = BatteryCommNode()
    
    try:
        rclpy.spin(battery_node)
    except KeyboardInterrupt:
        pass
    finally:
        battery_node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()