#!/usr/bin/env python3
import sys
import time
import math
import os

# ROS 2 Imports
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from std_msgs.msg import Int16, Int32, Int64, Float32, String, UInt64, Bool
from geometry_msgs.msg import Twist

# Custom Message Import
# Note: In ROS 2, message filenames usually compile to PascalCase (e.g., MoonsDrive). 
# Please ensure your mybot_bringup package is compiled for ROS 2.
try:
    from mybot_bringup.msg import MoonsDrive as moons_drive
except ImportError:
    # Fallback if the message generation didn't change the name case
    from mybot_bringup.msg import moons_drive

# Local Imports
try:
    from drive_tables import drive_status_string, drive_error_string, drive_warning_string
except ImportError:
    # Placeholder if file not found in path
    pass

# Modbus Import for pymodbus 3.x
from pymodbus.client import ModbusSerialClient


# --- Helper Functions (Static) ---
def rps_to_ms(rps, wheel_diameter_m, gear_ratio):
    if rps >= 2**15:  # Values >= 32768 represent negative numbers
        rps_signed = rps - 2**16
    else:
        rps_signed = rps
    return ((float(rps_signed) * 3.14 * wheel_diameter_m)/(gear_ratio*240))

def get_alarm_codes(value):
    alarm_codes = {
        0: "Position error overrun",
        1: "Reverse prohibit limit",
        2: "Positive prohibit limit",
        3: "overtemperature",
        4: "internal error",
        5: "Supply voltage out of range",
        7: "Drive overcurrent",
        9: "Motor encoder not connected",
        10: "Communication exception",
        12: "vent failure",
        13: "Motor overload protection",
        15: "Unusual start alarm",
        16: "Drive main circuit power input phase loss",
        17: "Safe torque off(STO)",
        19: "Motor speed exceeds limit",
        20: "Drive undervoltage",
        21: "emergency stop",
        22: "Second encoder not connected",
        23: "Full closed loop hybrid deviation overrun",
        24: "Absolute encoder battery undervoltage",
        25: "Absolute position lost",
        26: "Absolute position overflow",
        27: "RS485orCANopenBus communication interrupted",
        28: "Absolute encoder multi-turn error",
        29: "Abnormal motor action protection",
        30: "EtherCATcommunication error",
        31: "Back-to-origin parameter configuration error"
    }
    
    alarm_result = []
    for bit in range(32):
        if value & (1 << bit):
            if bit in alarm_codes:
                alarm_result.append(alarm_codes[bit])
    
    return "Alarms: " + ", ".join(alarm_result) if alarm_result else "Alarms: None"

def get_status_codes(value):
    status_codes = {
        0: "Servo enable",
        1: "sampling(LunaThe software oscilloscope function is enabled)",
        2: "Drive reports failure",
        3: "Movement in place",
        4: "in motion",
        5: "jogging running",
        6: "decelerating",
        7: "waiting for input signal(e.g. executeWinstruction)",
        8: "parameter saving",
        9: "drive warning",
        10: "back to origin",
        11: "waiting time(e.g. executeWT,WDinstruction)",
        13: "Encoder detection",
        14: "Qprogram is running",
        15: "Servo ready",
        16: "CSPfollow",
        17: "same speed",
        18: "zero speed",
        19: "Torque arrives",
        20: "same torque",
        21: "The second group gain is working",
        22: "The second control mode is working",
        23: "speed to reach",
        24: "back to origin complete"
    }
    
    status_result = []
    for bit in range(32):
        if value & (1 << bit):
            if bit in status_codes:
                status_result.append(status_codes[bit])
    
    return "Status: " + ", ".join(status_result) if status_result else "Status: None"

def read_modbus_input(data, wheel_diameter_m, gear_ratio):
    DEFAULTS = {
        'alarm_code'           : 0,
        'status_code'          : 0,
        'digital_output_status': 0,
        'digital_inputs_status': 0,
        'encoder_position'     : 0,
        'actual_velocity'      : 0.0,
        'drive_temperature'    : 0.0,
        'dsp_temperature'      : 0.0,
        'DC_voltage'           : 0.0,
        'actual_current'       : 0,
        'drive_runtime'        : 0.0,
        'drive_bootcount'      : 0,
        'digital_inputs_bool'  : [False, False, False, False],
        'digital_outputs_bool' : [False, False, False, False],
        'alarm_code_str'       : "",
        'status_code_str'      : ""
    }
    
    if data is None or len(data) != 55:
        # print("length error", len(data))
        return DEFAULTS.copy()

    def get_16(i):
        return data[i]

    out = {}
    out['alarm_code']            = (get_16(0) << 16) | get_16(1)
    out['status_code']           = (get_16(2) << 16) | get_16(3)
    
    # Read digital I/O status as integers
    digital_out_val = get_16(4)
    digital_in_val = get_16(5)
    
    out['digital_output_status'] = digital_out_val
    out['digital_inputs_status'] = digital_in_val
    out['encoder_position']      = (get_16(6) << 16) | get_16(7)
    out['actual_velocity']       = rps_to_ms(get_16(16), wheel_diameter_m, gear_ratio)
    out['drive_temperature']     = get_16(18) / 10.0
    out['dsp_temperature']       = get_16(19) / 10.0
    out['DC_voltage']            = get_16(21) / 10.0
    out['actual_current']        = get_16(30) 
    out['drive_runtime']         = (get_16(51) << 16) | get_16(52)
    out['drive_bootcount']       = (get_16(53) << 16) | get_16(54)

    # Convert to boolean arrays (check first 4 bits)
    out['digital_inputs_bool']   = [bool(digital_in_val & (1 << i)) for i in range(4)]
    out['digital_outputs_bool']  = [bool(digital_out_val & (1 << i)) for i in range(4)]

    out['alarm_code_str']        = get_alarm_codes(out['alarm_code'])
    out['status_code_str']       = get_status_codes(out['status_code'])

    return out

def ms_to_rps(velocity_ms, wheel_diameter_m, gear_ratio):
    wheel_circumference = math.pi * wheel_diameter_m
    wheel_rps = (velocity_ms ) / wheel_circumference
    motor_rps = wheel_rps * gear_ratio * 240
    rps_int = int(round(motor_rps))
    return rps_int 

def get_acceleration(accel_mps2, wheel_diameter_m, gear_ratio):
    if wheel_diameter_m <= 0:
        raise ValueError("wheel_diameter_m must be > 0")
    return int(round(((accel_mps2 * gear_ratio) / (math.pi * wheel_diameter_m))*6))

def set_acceleration(motor_rps2, wheel_diameter_m, gear_ratio):
    if wheel_diameter_m <= 0:
      raise ValueError("wheel_diameter_m must be > 0")
    return ((motor_rps2/6) * math.pi * wheel_diameter_m) / float(gear_ratio)

def split_long(number):
    high_word = (number >> 16) & 0xFFFF 
    low_word = number & 0xFFFF           
    registers = [high_word, low_word]
    return registers

# --- Main Node Class ---
class MoonsControlNode(Node):
    def __init__(self):
        super().__init__('moons_drive_node')
        self.get_logger().info("moons_drive_node initiated")
        
        # QoS Profile for low latency communication 
        qos_profile_best_effort = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        qos_profile_reliable = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=5
        )
        
        # --- Variables ---
        self.my_target = Twist()
        self.release = False
        self.send_start = False
        self.clear_alarm = None
        self.idle_time = 30 #sec
        self.left_id = 1
        self.right_id = 2
        
        self.prev_nonzero_time = time.time()
        self.motor_state = True
        self.run = True
        
        # Data holders
        self.left_data_in = None
        self.right_data_in = None
        self.left_acc_val = None
        self.left_dec_val = None
        self.right_acc_val = None
        self.right_dec_val = None

        # --- Parameters ---
        self.declare_parameter('T_acceleration', 0.25)
        self.declare_parameter('T_deceleration', 0.50)
        self.declare_parameter('T_wheel_diameter', 0.175)
        self.declare_parameter('T_gear_ratio', 25)
        self.declare_parameter('ComPort', '/dev/ttyS0')
        self.declare_parameter('baudrate', 115200)
        self.declare_parameter('bytesize', 8)
        self.declare_parameter('parity', 'N')
        self.declare_parameter('stopbits', 1)
        self.declare_parameter('timeout', 0.04)  # Increased from 0.040 to 0.5 seconds

        self.T_acceleration = self.get_parameter('T_acceleration').value
        self.T_deceleration = self.get_parameter('T_deceleration').value
        self.T_wheel_diameter = self.get_parameter('T_wheel_diameter').value
        self.T_gear_ratio = self.get_parameter('T_gear_ratio').value
        
        self.Port = self.get_parameter('ComPort').value
        self.baudrate = self.get_parameter('baudrate').value
        self.bytesize = self.get_parameter('bytesize').value
        self.parity = self.get_parameter('parity').value
        self.stopbits = self.get_parameter('stopbits').value
        self.timeout = self.get_parameter('timeout').value

        # --- Publishers ---
        self.pub_left_data = self.create_publisher(moons_drive, 'moons_left', qos_profile_best_effort)
        self.pub_right_data = self.create_publisher(moons_drive, 'moons_right', qos_profile_best_effort)

        self.moons_left_speed_pub = self.create_publisher(Float32, '/moons_left_speed', qos_profile_best_effort)
        self.moons_left_pos_pub = self.create_publisher(Int64, '/moons_left_position', qos_profile_best_effort)
        self.moons_left_curr_pub = self.create_publisher(Float32, '/moons_left_current', qos_profile_best_effort)

        self.moons_right_speed_pub = self.create_publisher(Float32, '/moons_right_speed', qos_profile_best_effort)
        self.moons_right_pos_pub = self.create_publisher(Int64, '/moons_right_position', qos_profile_best_effort)
        self.moons_right_curr_pub = self.create_publisher(Float32, '/moons_right_current', qos_profile_best_effort)

        self.moons_left_alarm_pub = self.create_publisher(String, '/moons_left_alarm', qos_profile_reliable)
        self.moons_right_alarm_pub = self.create_publisher(String, '/moons_right_alarm', qos_profile_reliable)


        # --- Subscribers ---
        self.create_subscription(Int16, "/safety_clear", self.safety_clear_callback, qos_profile_best_effort)
        self.create_subscription(Twist, "/cmd_vel", self.cmd_to_ms_callback, qos_profile_best_effort)
        self.create_subscription(Bool, "/moons_reset_alarm", self.moons_clearalarm_callback, qos_profile_best_effort)

        # --- Modbus Client Setup for pymodbus 3.x ---
        # In pymodbus 3.x, the client connects automatically when used
        self.client = ModbusSerialClient(
            port     = self.Port,
            baudrate = self.baudrate,
            bytesize = self.bytesize,
            parity   = self.parity,
            stopbits = self.stopbits,
            timeout  = self.timeout,
            retries  = 3,
            retry_on_empty = True
        )
        
        self.get_logger().info(f"Modbus client initialized on {self.Port} at {self.baudrate} baud")

        # --- Initial Setup Routine ---
        self.perform_initial_setup()

        # --- Main Loop Timer (20Hz = 0.05s) ---
        self.timer = self.create_timer(0.05, self.control_loop)

    def perform_initial_setup(self):
        self.get_logger().info(f"Starting initial setup on {self.Port} at {self.baudrate} baud")
        
        # In pymodbus 3.x, connect() is called automatically, but we can call it explicitly
        self.client.connect()
        
        # Test read to verify communication
        test_read_left = self.client.read_holding_registers(0, 1, slave=self.left_id)
        test_read_right = self.client.read_holding_registers(0, 1, slave=self.right_id)
        if test_read_left.isError() or test_read_right.isError():
            if test_read_left.isError():
                self.get_logger().error(f"Test read failed for left motor (ID {self.left_id}): {test_read}")
                self.get_logger().error("Check: 1) Motor power, 2) RS485 wiring, 3) Baud rate, 4) Motor unit ID")
                return
            if test_read_right.isError():
                self.get_logger().error(f"Test read failed for right motor (ID {self.right_id}): {test_read}")
                self.get_logger().error("Check: 1) Motor power, 2) RS485 wiring, 3) Baud rate, 4) Motor unit ID")
                return
        else:
            self.get_logger().info(f"Successfully communicated with left motor (ID {self.left_id}) and right motor (ID {self.right_id})")
            
            # Sequence of register writes (left: slave=1, right: slave=2)
            # In pymodbus 3.x, 'unit' parameter is renamed to 'slave'
            for slave_id in [self.left_id, self.right_id]:
                
                resp = self.client.write_registers(342, [0, 0], slave=slave_id)  # write speed 0 rpm 
                if resp.isError(): continue

                resp = self.client.write_register(124, 0x00E2, slave=slave_id)   # write stop 
                if resp.isError(): continue
                
                resp = self.client.write_register(124, 0x0098, slave=slave_id)   # reset encoder
                if resp.isError(): continue
                
                acc_val = split_long(get_acceleration(self.T_acceleration, self.T_wheel_diameter, self.T_gear_ratio))
                resp = self.client.write_registers(338, acc_val, slave=slave_id) # acceleration
                if resp.isError():
                    self.get_logger().error(f"Error writing acceleration to drive {slave_id}")
                    continue
                
                dec_val = split_long(get_acceleration(self.T_deceleration, self.T_wheel_diameter, self.T_gear_ratio))
                resp = self.client.write_registers(340, dec_val, slave=slave_id) # deceleration 
                if resp.isError():
                    self.get_logger().error(f"Error writing deceleration to drive {slave_id}")
                    continue
                
                resp = self.client.write_register(124, 0x00BA, slave=slave_id) # Write reset alarm
                if resp.isError(): continue

                resp = self.client.write_register(124, 0x009F, slave=slave_id) # enable drive
                if resp.isError(): continue
                
                resp = self.client.write_register(124, 0x0096, slave=slave_id) # start drive
                if resp.isError(): continue

            self.get_logger().info("Initial setup complete: zero, stop motor, reset encoder, set acc/dec, alarm reset, enable, start")

    # --- Callbacks ---
    def cmd_to_ms_callback(self, msg):
        self.my_target = msg
      
    def safety_clear_callback(self, msg):
        safety_trigger = msg.data
        if safety_trigger == 1 and self.send_start == False and self.release == True:
            self.send_start = True
        
        if safety_trigger == 0:
            self.release = True

    def moons_clearalarm_callback(self, msg):
        self.clear_alarm = msg.data

    # --- Main Loop ---
    def control_loop(self):
        now_time = time.time()
        
        # In pymodbus 3.x, connection is managed automatically
        if not self.client.connected:
            self.get_logger().warn("Modbus not connected, attempting reconnect...")
            self.client.connect()
        
        # convert cmd_vel in met/sec into rpm 
        left_velocity = self.my_target.linear.x           # m/s
        left_rps = split_long(ms_to_rps(left_velocity, self.T_wheel_diameter, self.T_gear_ratio))

        right_velocity = self.my_target.angular.z         # m/s
        right_rps = split_long(ms_to_rps(right_velocity, self.T_wheel_diameter, self.T_gear_ratio))

        try:

            if self.send_start == True:
                for slave_id in [self.left_id, self.right_id]:
                    resp = self.client.write_registers(342, [0, 0], slave=slave_id)
                    if resp.isError(): continue
                    
                    resp = self.client.write_register(124, 0x00E2, slave=slave_id) # stop
                    if resp.isError(): continue

                    time.sleep(0.005)
                    
                    resp = self.client.write_register(124, 0x00BA, slave=slave_id) # reset alarm
                    if resp.isError(): continue
                    time.sleep(0.005)

                    resp = self.client.write_register(124, 0x009F, slave=slave_id) # enable
                    if resp.isError(): continue
                    
                    resp = self.client.write_register(124, 0x0096, slave=slave_id) # start
                    if resp.isError(): continue

                time.sleep(0.2) 
                self.send_start = False
                self.release    = False
                self.get_logger().info("sent start after Safety healthy") 
                
            
            if self.clear_alarm:
                for slave_id in [self.left_id, self.right_id]:
                    resp = self.client.write_register(124, 0x00BA, slave=slave_id) # reset alarm
                    if resp.isError(): continue

                    resp = self.client.write_register(124, 0x009F, slave=slave_id) # enable
                    if resp.isError(): continue
                    
                    resp = self.client.write_register(124, 0x0096, slave=slave_id) # start
                    if resp.isError(): continue
                
                time.sleep(1.0) 
                self.get_logger().info("clear_alarm after command") 
                self.clear_alarm = False

            # Write Speeds (using 'slave' instead of 'unit')
            resp_left = self.client.write_registers(342, left_rps, slave=self.left_id)
            if resp_left.isError():
                self.get_logger().debug(f"Failed to write left speed: {resp_left}")

            resp_right = self.client.write_registers(342, right_rps, slave=self.right_id)
            if resp_right.isError():
                self.get_logger().debug(f"Failed to write right speed: {resp_right}")
            
            # Read Data (using 'slave' instead of 'unit')
            self.left_data_in = self.client.read_holding_registers(0, 55, slave=self.left_id)
            if self.left_data_in.isError():
                self.get_logger().error(f"Failed to read left motor data: {self.left_data_in}")
            else:
                self.get_logger().debug(f"Left motor data read successfully: {len(self.left_data_in.registers)} registers")
            
            self.right_data_in = self.client.read_holding_registers(0, 55, slave=self.right_id)
            if self.right_data_in.isError():
                self.get_logger().error(f"Failed to read right motor data: {self.right_data_in}")
            else:
                self.get_logger().debug(f"Right motor data read successfully: {len(self.right_data_in.registers)} registers")

            # Read Acc/Dec Params (Left)
            left_acc = self.client.read_input_registers(338, 2, slave=self.left_id)
            if not left_acc.isError():
                self.left_acc_val = set_acceleration(((left_acc.registers[0] << 16) | left_acc.registers[1]), self.T_wheel_diameter, self.T_gear_ratio)
            
            left_dec = self.client.read_input_registers(340, 2, slave=self.left_id)
            if not left_dec.isError():
                self.left_dec_val = set_acceleration(((left_dec.registers[0] << 16) | left_dec.registers[1]), self.T_wheel_diameter, self.T_gear_ratio)

            # Read Acc/Dec Params (Right)
            right_acc = self.client.read_input_registers(338, 2, slave=self.right_id)
            if not right_acc.isError():
                # print("acceleration",right_acc.registers[0])
                self.right_acc_val = set_acceleration(((right_acc.registers[0] << 16) | right_acc.registers[1]), self.T_wheel_diameter, self.T_gear_ratio)

            right_dec = self.client.read_input_registers(340, 2, slave=self.right_id)
            if not right_dec.isError():
                self.right_dec_val = set_acceleration(((right_dec.registers[0] << 16) | right_dec.registers[1]), self.T_wheel_diameter, self.T_gear_ratio)

        except Exception as e:
            self.get_logger().error(f"An error occurred in control loop: {e}")
            import traceback
            self.get_logger().error(traceback.format_exc())
        
        # --- Processing and Publishing (if data valid) ---
        if self.left_data_in and not self.left_data_in.isError():
            self.get_logger().debug("Processing left motor data...")
            left_data = read_modbus_input(self.left_data_in.registers, self.T_wheel_diameter, self.T_gear_ratio)
            
            left_msg = moons_drive()
            left_msg.stamp = self.get_clock().now().to_msg()
            left_msg.alarm_code = str(left_data['alarm_code_str'])
            left_msg.status_code = str(left_data['status_code_str'])
            left_msg.digital_output_status = left_data['digital_outputs_bool']
            left_msg.digital_inputs_status = left_data['digital_inputs_bool']
            left_msg.encoder_position = int(left_data['encoder_position'])
            left_msg.actual_velocity = float(left_data['actual_velocity'])
            left_msg.drive_temperature = float(left_data['drive_temperature'])
            left_msg.dsp_temperature = float(left_data['dsp_temperature'])
            left_msg.dc_voltage = float(left_data['DC_voltage'])
            left_msg.actual_current = float(left_data['actual_current'])
            left_msg.drive_runtime = float(left_data['drive_runtime'])
            left_msg.drive_bootcount = float(left_data['drive_bootcount'])  # Message expects float32
            left_msg.acceleration = float(self.left_acc_val) if self.left_acc_val is not None else 0.0
            left_msg.deceleration = float(self.left_dec_val) if self.left_dec_val is not None else 0.0

            moons_left_alarm = "L"+"{:032b}".format(left_data['alarm_code'])

            self.pub_left_data.publish(left_msg)
            self.moons_left_speed_pub.publish(Float32(data=float(left_msg.actual_velocity)))     
            self.moons_left_pos_pub.publish(Int64(data=int(left_msg.encoder_position))) 
            self.moons_left_curr_pub.publish(Float32(data=float(left_msg.actual_current)))
            self.moons_left_alarm_pub.publish(String(data=moons_left_alarm))

        else:
            self.get_logger().warn("Left motor data not available or has errors")
        
        if self.right_data_in and not self.right_data_in.isError():
            self.get_logger().debug("Processing right motor data...")
            right_data = read_modbus_input(self.right_data_in.registers, self.T_wheel_diameter, self.T_gear_ratio)
            
            right_msg = moons_drive()
            right_msg.stamp = self.get_clock().now().to_msg()
            right_msg.alarm_code = str(right_data['alarm_code_str'])
            right_msg.status_code = str(right_data['status_code_str'])
            right_msg.digital_output_status = right_data['digital_outputs_bool']
            right_msg.digital_inputs_status = right_data['digital_inputs_bool']
            right_msg.encoder_position = int(right_data['encoder_position'])
            right_msg.actual_velocity = float(right_data['actual_velocity'])
            right_msg.drive_temperature = float(right_data['drive_temperature'])
            right_msg.dsp_temperature = float(right_data['dsp_temperature'])
            right_msg.dc_voltage = float(right_data['DC_voltage'])
            right_msg.actual_current = float(right_data['actual_current'])
            right_msg.drive_runtime = float(right_data['drive_runtime'])
            right_msg.drive_bootcount = float(right_data['drive_bootcount'])  # Message expects float32
            right_msg.acceleration = float(self.right_acc_val) if self.right_acc_val is not None else 0.0
            right_msg.deceleration = float(self.right_dec_val) if self.right_dec_val is not None else 0.0

            moons_right_alarm = "R"+"{:032b}".format(right_data['alarm_code'])

            self.pub_right_data.publish(right_msg)
            self.moons_right_speed_pub.publish(Float32(data=float(right_msg.actual_velocity)))     
            self.moons_right_pos_pub.publish(Int64(data=int(right_msg.encoder_position))) 
            self.moons_right_curr_pub.publish(Float32(data=float(right_msg.actual_current)))
            self.moons_right_alarm_pub.publish(String(data=moons_right_alarm))
        else:
            self.get_logger().warn("Right motor data not available or has errors")

def main(args=None):
    rclpy.init(args=args)
    node = MoonsControlNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        print("Shutting down Moons Drive Node")
    finally:
        # Close Modbus connection on shutdown
        if node.client.connected:
            node.client.close()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()