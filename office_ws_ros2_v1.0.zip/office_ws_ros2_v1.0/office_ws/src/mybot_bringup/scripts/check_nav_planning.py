#!/usr/bin/env python3
"""
Comprehensive diagnostic tool for Nav2 path planning issues.
Checks lifecycle states, topics, transforms, and provides actionable feedback.
"""

import rclpy
from rclpy.node import Node
from lifecycle_msgs.srv import GetState
import time
import sys

class NavPlanningDiagnostic(Node):
    def __init__(self):
        super().__init__('nav_planning_diagnostic')
        self.issues_found = []
        self.warnings = []
        
    def check_lifecycle_node(self, node_name):
        """Check if a lifecycle node is active"""
        client = self.create_client(GetState, f'{node_name}/get_state')
        
        if not client.wait_for_service(timeout_sec=2.0):
            return None, f"Service {node_name}/get_state not available"
            
        request = GetState.Request()
        future = client.call_async(request)
        
        try:
            rclpy.spin_until_future_complete(self, future, timeout_sec=2.0)
            if future.result() is not None:
                state_id = future.result().current_state.id
                state_names = {
                    0: 'UNKNOWN',
                    1: 'UNCONFIGURED',
                    2: 'INACTIVE',
                    3: 'ACTIVE',
                    4: 'FINALIZED'
                }
                return state_id, state_names.get(state_id, 'UNKNOWN')
            return None, "No response"
        except Exception as e:
            return None, str(e)
    
    def check_topic(self, topic_name):
        """Check if a topic exists and has publishers"""
        topic_list = self.get_topic_names_and_types()
        topic_exists = any(topic_name == t[0] for t in topic_list)
        
        if not topic_exists:
            return False, 0, 0
        
        # Get publisher and subscriber counts
        info = self.get_publishers_info_by_topic(topic_name)
        pub_count = len(info)
        
        info = self.get_subscriptions_info_by_topic(topic_name)
        sub_count = len(info)
        
        return True, pub_count, sub_count
    
    def run_diagnostics(self):
        """Run all diagnostic checks"""
        print("\n" + "="*60)
        print("Nav2 Path Planning Diagnostic Tool")
        print("="*60 + "\n")
        
        # Check 1: Lifecycle Nodes
        print("1. LIFECYCLE NODE STATES")
        print("-" * 60)
        
        critical_nodes = {
            '/map_server': 'Provides the map for planning',
            '/amcl': 'Localizes robot on the map',
            '/controller_server': 'Executes path following',
            '/planner_server': 'Computes paths',
            '/behavior_server': 'Handles recovery behaviors',
            '/bt_navigator': 'Coordinates navigation',
            '/waypoint_follower': 'Follows waypoint sequences'
        }
        
        all_active = True
        for node_name, description in critical_nodes.items():
            state_id, state_name = self.check_lifecycle_node(node_name)
            
            if state_id == 3:
                print(f"  ✓ {node_name:25s} ACTIVE")
            elif state_id is None:
                print(f"  ✗ {node_name:25s} NOT FOUND")
                self.issues_found.append(f"{node_name} not found - {description}")
                all_active = False
            else:
                print(f"  ✗ {node_name:25s} {state_name}")
                self.issues_found.append(f"{node_name} is {state_name}, needs to be ACTIVE - {description}")
                all_active = False
        
        if all_active:
            print("\n  ✓ All lifecycle nodes are ACTIVE\n")
        else:
            print("\n  ✗ Some nodes are not active!\n")
        
        # Check 2: Critical Topics
        print("2. CRITICAL TOPICS")
        print("-" * 60)
        
        critical_topics = {
            '/scan': 'Laser scan data for obstacle detection',
            '/odom': 'Odometry for robot position',
            '/map': 'Map for global planning',
            '/tf': 'Transform tree',
            '/tf_static': 'Static transforms',
            '/cmd_navigation': 'Controller velocity output',
            '/cmd_twist_teleop': 'Motor control input',
            '/local_costmap/costmap': 'Local obstacle map',
            '/global_costmap/costmap': 'Global planning map',
            '/plan': 'Computed path',
            '/particle_cloud': 'AMCL localization particles',
            '/amcl_pose': 'Robot pose estimate'
        }
        
        all_topics_ok = True
        for topic_name, description in critical_topics.items():
            exists, pub_count, sub_count = self.check_topic(topic_name)
            
            if exists and pub_count > 0:
                print(f"  ✓ {topic_name:35s} ({pub_count} pub, {sub_count} sub)")
            elif exists and pub_count == 0:
                print(f"  ⚠ {topic_name:35s} (no publishers!)")
                self.warnings.append(f"{topic_name} exists but has no publishers - {description}")
                all_topics_ok = False
            else:
                print(f"  ✗ {topic_name:35s} NOT FOUND")
                self.issues_found.append(f"{topic_name} not found - {description}")
                all_topics_ok = False
        
        if all_topics_ok:
            print("\n  ✓ All critical topics are publishing\n")
        else:
            print("\n  ✗ Some topics are missing or not publishing!\n")
        
        # Check 3: Navigation Action Servers
        print("3. NAVIGATION ACTION SERVERS")
        print("-" * 60)
        
        action_servers = [
            '/navigate_to_pose',
            '/navigate_through_poses',
            '/compute_path_to_pose',
            '/follow_path'
        ]
        
        # Get all action servers (skip this check as it requires rclpy.action)
        # Just check if the action topics exist
        topic_list = [t[0] for t in self.get_topic_names_and_types()]
        
        for action_name in action_servers:
            # Action servers create topics like /action_name/_action/status
            action_topic = f"{action_name}/_action/status"
            exists = action_topic in topic_list
            if exists:
                print(f"  ✓ {action_name}")
            else:
                print(f"  ✗ {action_name} NOT FOUND")
                self.issues_found.append(f"Action server {action_name} not available")
        
        print()
        
        # Summary
        print("="*60)
        print("DIAGNOSTIC SUMMARY")
        print("="*60 + "\n")
        
        if not self.issues_found and not self.warnings:
            print("✓ ALL CHECKS PASSED!")
            print("\nYour navigation stack appears to be configured correctly.")
            print("\nIf path planning still doesn't work:")
            print("  1. Set initial pose in RViz using '2D Pose Estimate'")
            print("  2. Wait for particle cloud to converge (particles should cluster)")
            print("  3. Set navigation goal using '2D Goal Pose'")
            print("  4. Check RViz console for error messages")
            print("  5. Monitor: ros2 topic echo /cmd_navigation")
            return True
        
        if self.issues_found:
            print("✗ CRITICAL ISSUES FOUND:\n")
            for i, issue in enumerate(self.issues_found, 1):
                print(f"  {i}. {issue}")
            print()
        
        if self.warnings:
            print("⚠ WARNINGS:\n")
            for i, warning in enumerate(self.warnings, 1):
                print(f"  {i}. {warning}")
            print()
        
        # Provide solutions
        print("="*60)
        print("RECOMMENDED ACTIONS")
        print("="*60 + "\n")
        
        if any('not found' in issue.lower() or 'not active' in issue.lower() for issue in self.issues_found):
            print("1. Restart navigation with lifecycle activation:")
            print("   Terminal 1: ros2 launch mybot_bringup robot_standalone.launch.py")
            print("   Terminal 2: ros2 launch mybot_bringup view_navigation.launch.py")
            print("   Wait 10 seconds for automatic activation\n")
        
        if any('cmd_navigation' in issue or 'cmd_twist_teleop' in issue for issue in self.issues_found):
            print("2. Check twist_mux configuration:")
            print("   ros2 node list | grep twist_mux")
            print("   ros2 topic info /cmd_navigation")
            print("   ros2 topic info /cmd_twist_teleop\n")
        
        if any('amcl' in issue.lower() or 'particle' in issue.lower() for issue in self.issues_found):
            print("3. Check localization:")
            print("   - Set initial pose in RViz")
            print("   - Verify: ros2 topic echo /amcl_pose")
            print("   - Verify: ros2 topic hz /particle_cloud\n")
        
        if any('costmap' in issue.lower() for issue in self.issues_found):
            print("4. Check costmap configuration:")
            print("   - Verify laser scan: ros2 topic hz /scan")
            print("   - Check QoS settings in nav2_params.yaml")
            print("   - Verify costmaps in RViz\n")
        
        return False

def main(args=None):
    rclpy.init(args=args)
    diagnostic = NavPlanningDiagnostic()
    
    try:
        success = diagnostic.run_diagnostics()
        diagnostic.destroy_node()
        rclpy.shutdown()
        
        sys.exit(0 if success else 1)
        
    except KeyboardInterrupt:
        diagnostic.destroy_node()
        rclpy.shutdown()
        sys.exit(1)

if __name__ == '__main__':
    main()
