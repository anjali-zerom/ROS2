#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from geometry_msgs.msg import Twist

class TwistMuxQoSBridge(Node):
    def __init__(self):
        super().__init__('twist_mux_qos_bridge')
        
        # Best effort QoS profile for subscribing to external topics
        best_effort_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )
        
        # Reliable QoS profile for publishing to twist_mux
        reliable_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )
        
        # Define input topics that need QoS conversion (best_effort -> reliable)
        input_topics = [
            ('cmd_navigation_best_effort', 'cmd_navigation'),
            ('cmd_joystick_best_effort', 'cmd_joystick'),
            ('cmd_keyboard_best_effort', 'cmd_keyboard'),
            ('cmd_web_joy_best_effort', 'cmd_web_joy'),
            ('cmd_docker_best_effort', 'cmd_docker')
        ]
        
        # Create subscribers (best_effort) and publishers (reliable) for inputs
        self.input_relays = []
        for sub_topic, pub_topic in input_topics:
            subscriber = self.create_subscription(
                Twist,
                sub_topic,
                lambda msg, topic=pub_topic: self.input_callback(msg, topic),
                best_effort_qos
            )
            publisher = self.create_publisher(
                Twist,
                pub_topic,
                reliable_qos
            )
            self.input_relays.append((subscriber, publisher, sub_topic, pub_topic))
            self.get_logger().info(f'Input relay: {sub_topic} (best_effort) -> {pub_topic} (reliable)')
        
        # Create output relay: twist_mux output (reliable) -> final output (best_effort)
        self.output_subscription = self.create_subscription(
            Twist,
            'cmd_twist_teleop',
            self.output_callback,
            reliable_qos
        )
        
        self.output_publisher = self.create_publisher(
            Twist,
            'cmd_vel',
            best_effort_qos
        )
        
        self.get_logger().info('Output relay: cmd_twist_teleop (reliable) -> cmd_vel (best_effort)')
        self.get_logger().info('Twist Mux QoS Bridge is ready!')
    
    def input_callback(self, msg, pub_topic):
        # Find the corresponding publisher and publish
        for _, publisher, _, topic in self.input_relays:
            if topic == pub_topic:
                publisher.publish(msg)
                break
    
    def output_callback(self, msg):
        self.output_publisher.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = TwistMuxQoSBridge()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
