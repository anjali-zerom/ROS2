#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Int16, Int32, Int64, Float32, String, UInt64

class ResendGoalNode(Node):
    def __init__(self):
        super().__init__('send_goal_cont')
        
        self.get_logger().info("waiting for action server")
        
        self.mygoal = None
        self.trigger = 0  # 0 go, 1 stop
        
        # Create action client for nav2
        self.nav_to_pose_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        
        # Create subscribers
        self.goal_sub = self.create_subscription(
            PoseStamped,
            "/goal_pose",
            self.receive_goal_callback,
            10
        )
        
        self.continuous_goal_sub = self.create_subscription(
            Int16,
            "send_continuous_goal",
            self.continuous_goal_callback,
            10
        )
        
        # Wait for action server
        self.nav_to_pose_client.wait_for_server()
        self.get_logger().info("Received from resend goal")
        
        # Create timer for 0.1 Hz operation (10 seconds)
        self.timer = self.create_timer(10.0, self.timer_callback)
        
    def receive_goal_callback(self, data):
        self.mygoal = data
        
    def continuous_goal_callback(self, data):
        self.trigger = data.data
        
    def timer_callback(self):
        if self.mygoal is not None and self.trigger == 0:
            # Create NavigateToPose goal
            goal_msg = NavigateToPose.Goal()
            goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
            goal_msg.pose.header.frame_id = "map"
            goal_msg.pose.pose.position.x = self.mygoal.pose.position.x
            goal_msg.pose.pose.position.y = self.mygoal.pose.position.y
            goal_msg.pose.pose.position.z = self.mygoal.pose.position.z
            goal_msg.pose.pose.orientation.w = self.mygoal.pose.orientation.w
            goal_msg.pose.pose.orientation.x = self.mygoal.pose.orientation.x
            goal_msg.pose.pose.orientation.y = self.mygoal.pose.orientation.y
            goal_msg.pose.pose.orientation.z = self.mygoal.pose.orientation.z
            
            # Send goal
            self.nav_to_pose_client.send_goal_async(goal_msg)
            self.get_logger().info("Sent navigation goal")

def main(args=None):
    rclpy.init(args=args)
    
    resend_goal_node = ResendGoalNode()
    
    try:
        rclpy.spin(resend_goal_node)
    except KeyboardInterrupt:
        pass
    finally:
        resend_goal_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
