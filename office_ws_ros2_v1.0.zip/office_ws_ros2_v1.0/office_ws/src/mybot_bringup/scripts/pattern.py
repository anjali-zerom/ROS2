#!/usr/bin/env python3
import os
import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Bool
import tf2_ros
from tf2_ros import TransformBroadcaster
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point, TransformStamped
from laser_line_extraction.msg import LineSegmentList
from geometry_msgs.msg import Twist
import math
import time
from tf_transformations import quaternion_from_euler

class PatternNode(Node):
    def __init__(self):
        super().__init__('pattern_node')
        
        # Initialize variables
        self.check_angle = False
        self.point_temp = [[], [], [], []]
        self.point_set = [[], [], [], []]
        self.dock_vector = [0, 0, 0, 0]
        self.temp_point_1 = [0.0, 0.0]
        self.temp_point_2 = [0.0, 0.0]
        
        # Declare parameters
        self.declare_parameter('pattern_angle1', 3.9)
        self.declare_parameter('pattern_angle2', 1.57)
        self.declare_parameter('pattern_angle3', 3.9)
        self.declare_parameter('detect_angle_tolerance', 0.2)
        self.declare_parameter('group_dist_tolerance', 0.2)
        self.declare_parameter('laser_frame_id', 'laser_frame')
        
        # Get parameters
        self.pattern_angle1 = self.get_parameter('pattern_angle1').get_parameter_value().double_value
        self.pattern_angle2 = self.get_parameter('pattern_angle2').get_parameter_value().double_value
        self.pattern_angle3 = self.get_parameter('pattern_angle3').get_parameter_value().double_value
        self.detect_angle_tolerance = self.get_parameter('detect_angle_tolerance').get_parameter_value().double_value
        self.group_dist_tolerance = self.get_parameter('group_dist_tolerance').get_parameter_value().double_value
        self.laser_frame_id = self.get_parameter('laser_frame_id').get_parameter_value().string_value
        
        # Create subscriber
        self.robot_pose_sub = self.create_subscription(
            LineSegmentList,
            '/line_segments_final',
            self.pattern_callback,
            10
        )
        
        # Create publisher
        self.doc_pos_publisher = self.create_publisher(
            Twist,
            '/docker_pos',
            10
        )
        
        # Create TF broadcaster
        self.pattern_broadcaster = TransformBroadcaster(self)
        
    def dist(self, vector_i, vector_j):
        distance = math.sqrt(
            math.pow(math.fabs(vector_i[0] - vector_j[0]), 2) +
            math.pow(math.fabs(vector_i[1] - vector_j[1]), 2)
        )
        return distance
        
    def mid_point(self, vector):
        mid = [0.0, 0.0]
        mid[0] = (vector.start[0] + vector.end[0]) / 2
        mid[1] = (vector.start[1] + vector.end[1]) / 2
        return mid
        
    def mid_two_point(self, array_a, array_b):
        mid = [0.0, 0.0]
        mid[0] = (array_a[0] + array_b[0]) / 2
        mid[1] = (array_a[1] + array_b[1]) / 2
        return mid
        
    def mid_dist(self, vector_i, vector_j):
        mid_i = self.mid_point(vector_i)
        mid_j = self.mid_point(vector_j)
        distance = math.sqrt(
            math.pow(math.fabs(mid_i[0] - mid_j[0]), 2) +
            math.pow(math.fabs(mid_i[1] - mid_j[1]), 2)
        )
        return distance
        
    def cal_angle(self, a, b, angle_ab, detect_angle_tolerance):
        angle = 0.0
        angle = math.fabs(a - b)
        
        if angle < math.pi and angle > 1.7:
            angle = angle - (math.pi / 2)
        elif angle > ((math.pi / 2) + math.pi):
            angle = angle - math.pi - (math.pi / 2)
        elif angle > math.pi and angle < ((math.pi / 2) + math.pi):
            angle = angle - math.pi
            
        if math.fabs(angle_ab - angle) <= detect_angle_tolerance:
            return True
        else:
            return False
            
    def check_center(self, vectors):
        for i in range(0, 3):
            for j in range(i + 1, 4):
                if self.cal_angle(
                    vectors[self.dock_vector[i]].angle,
                    vectors[self.dock_vector[j]].angle,
                    math.pi - self.pattern_angle2,
                    self.detect_angle_tolerance
                ):
                    return True
        return False
        
    def populate_tf(self, x, y, theta, name):
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = self.laser_frame_id
        t.child_frame_id = name
        t.transform.translation.x = x
        t.transform.translation.y = y
        t.transform.translation.z = 0.0
        
        q = quaternion_from_euler(0, 0, theta)
        t.transform.rotation.x = q[0]
        t.transform.rotation.y = q[1]
        t.transform.rotation.z = q[2]
        t.transform.rotation.w = q[3]
        
        self.pattern_broadcaster.sendTransform(t)
        
    def pattern_callback(self, data):
        pos_msg = Twist()
        pos_msg.linear.x = 0.0
        pos_msg.linear.y = 0.0
        pos_msg.linear.z = 0.0
        pos_msg.angular.x = 0.0
        pos_msg.angular.y = 0.0
        pos_msg.angular.z = 0.0
        
        vectors = data.line_segments
        line_num = len(vectors)
        angle_count = 0
        check_vec_size = True
        self.check_angle = False
        
        if line_num < 4:
            self.get_logger().warn("There isn't enough line in the laser field!")
            check_vec_size = False
            
        if check_vec_size:
            for i in range(0, line_num):
                for j in range(i + 1, line_num + 1):
                    if j < line_num:
                        if self.mid_dist(vectors[i], vectors[j]) <= self.group_dist_tolerance:
                            if self.cal_angle(
                                vectors[i].angle,
                                vectors[j].angle,
                                self.pattern_angle1 - 3.14,
                                self.detect_angle_tolerance
                            ):
                                angle_count += 1
                                if angle_count == 1:
                                    self.point_temp[0] = self.mid_point(vectors[i])
                                    self.point_temp[1] = self.mid_point(vectors[j])
                                    self.dock_vector[0] = i
                                    self.dock_vector[1] = j
                                else:
                                    self.dock_vector[2] = i
                                    self.dock_vector[3] = j
                                    self.point_temp[3] = self.mid_point(vectors[i])
                                    self.point_temp[2] = self.mid_point(vectors[j])
                                    
                                    self.temp_point_1 = self.mid_two_point(
                                        self.point_temp[0], self.point_temp[1]
                                    )
                                    self.temp_point_2 = self.mid_two_point(
                                        self.point_temp[2], self.point_temp[3]
                                    )
                                    
                                    if (self.dist(self.temp_point_1, self.temp_point_2) <= 0.3 and
                                        self.check_center(vectors)):
                                        self.point_set = self.point_temp
                                        self.check_angle = True
                                        
                                        if self.check_angle:
                                            theta_point_1 = self.mid_two_point(
                                                self.point_set[0], self.point_set[1]
                                            )
                                            theta_point_2 = self.mid_two_point(
                                                self.point_set[2], self.point_set[3]
                                            )
                                            goal_point = self.mid_two_point(
                                                theta_point_1, theta_point_2
                                            )
                                            
                                            theta = math.atan2(
                                                (theta_point_1[1] - theta_point_2[1]),
                                                (theta_point_1[0] - theta_point_2[0])
                                            )
                                            
                                            self.populate_tf(
                                                goal_point[0], goal_point[1], theta, "dock_frame"
                                            )
                                            
                                            pos_msg.linear.x = goal_point[0]
                                            pos_msg.linear.y = goal_point[1]
                                            pos_msg.linear.z = 0.0
                                            pos_msg.angular.x = 0.0
                                            pos_msg.angular.y = 0.0
                                            pos_msg.angular.z = theta
                                            
                                            self.doc_pos_publisher.publish(pos_msg)

def main(args=None):
    rclpy.init(args=args)
    
    pattern_node = PatternNode()
    
    try:
        rclpy.spin(pattern_node)
    except KeyboardInterrupt:
        pass
    finally:
        pattern_node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()