#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
import os
import threading
from std_msgs.msg import String, Int16
from geometry_msgs.msg import Twist
# from playsound import playsound
import time

class LEDSpeakerControlNode(Node):
    def __init__(self):
        super().__init__('robot_state')
        
        # QoS Profile for low latency communication (matching ticks_based_move_wrap.py)
        qos_profile_best_effort = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )

        qos_profile_reliable = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=5
        )

        # Initialize variables
        self.safety_clear = False
        self.manual_brake = False
        self.shutdown = False
        self.run = False
        self.dock = False
        self.led_cmd = None
        self.play_tone_moving = False
        self.play_tone_unsafe = False
        self.play_tone_idle = False
        self.play_tone_no_dock = False
        self.play_tone_dock = False
        self.default_volume = 35  # Default base volume
        self.last_volume = None  # To track last set volume
        self.last_play_time = self.get_clock().now()
        self.last_led_cmd = None
        
        self.get_logger().info("LED color and speaker node running")
        
        # Create publisher
        self.led_cmd_publisher = self.create_publisher(String, '/robot_status', qos_profile_best_effort)
        
        # Create subscribers
        self.create_subscription(Int16, "/volume", self.volume_callback, qos_profile_reliable)
        self.create_subscription(Twist, "/cmd_teleop_filter", self.run_command, qos_profile_best_effort)
        self.create_subscription(Int16, "/safety_clear", self.safety_clear_func, qos_profile_best_effort)
        self.create_subscription(String, "/docking_state", self.docking_state, qos_profile_best_effort)
        self.create_subscription(Twist, "/cmd_vel", self.run_dock, qos_profile_best_effort)
        self.create_subscription(Int16, "/manual_break_engaged", self.manual_break_engaged, qos_profile_best_effort)
        self.create_subscription(Int16, "/shutdown_button_pushed", self.shutdown_button_pushed, qos_profile_reliable)
        
        # Create timer for main loop (20 Hz)
        self.timer = self.create_timer(0.05, self.main_loop)
        
    def clamp(self, value, min_val, max_val):
        """Ensures value is within min and max limits."""
        return max(min_val, min(value, max_val))

    def volume_callback(self, data):
        """Callback to receive volume data from /volume topic."""
        received_volume = self.clamp(data.data, 0, 100)  # Ensure within 0-100 range
        self.default_volume = received_volume
        self.get_logger().info(f"Updated base volume: {self.default_volume}%")

    def set_volume(self, volume):
        """Sets system volume if it's different from the last set value."""
        volume = self.clamp(volume, 0, 100)  # Ensure within 0-100 range
        if self.last_volume != volume:
            os.system(f'amixer -D pulse sset Master {volume}%')
            self.last_volume = volume
            self.get_logger().info(f"Volume set to: {volume}%")

    def get_adjusted_volume(self, event_type):
        """Returns adjusted volume based on the event type."""
        # Compute adjusted values dynamically
        volume_increase_20 = int((0.2 * self.default_volume))  # 20% of received volume
        volume_decrease_10 = int((0.1 * self.default_volume))  # 10% of received volume

        if event_type == "state_1":
            return self.clamp(self.default_volume + volume_increase_20, 0, 100)  # +20%
        elif event_type == "play_tone_dock":
            return self.default_volume  # Same as received value
        elif event_type == "play_tone_no_dock":
            return self.default_volume  # Same as received value
        elif event_type == "state_4":
            return self.clamp(self.default_volume + volume_increase_20, 0, 100)  # +20%
        elif event_type == "state_2":
            return self.default_volume  # Same as received value
        elif event_type == "state_3":
            return self.clamp(self.default_volume - volume_decrease_10, 0, 100)  # -10%

        return self.default_volume  # Default case

    def play_sound_async(self, file_path, event_type):
        """Plays a sound asynchronously with adjusted volume."""
        self.set_volume(self.get_adjusted_volume(event_type))  # Adjust volume before playing
        thread = threading.Thread(target=playsound, args=(file_path,))
        thread.daemon = True
        thread.start()

    def safety_clear_func(self, data):
        self.safety_clear = True if data.data == 1 else False

    def manual_break_engaged(self, data):
        self.manual_brake = True if data.data == 1 else False

    def shutdown_button_pushed(self, data):
        self.shutdown = True if data.data == 200 else False

    def run_command(self, data):
        self.run = data.linear.x != 0 or data.angular.z != 0

    def run_dock(self, data):
        self.dock = data.linear.x != 0 or data.angular.z != 0

    def docking_state(self, data):
        if data.data == "successful_dock":
            self.play_tone_dock = True
        else:
            self.play_tone_no_dock = True


    def main_loop(self):
        """Main loop to handle LED state and audio cues."""
        # Determine LED state
        if self.shutdown:
            self.led_cmd = "RSHUT"
            state = 1
        elif self.manual_brake:
            self.led_cmd = "BRAKE"
            state = 1
        elif not self.safety_clear:
            self.led_cmd = "EMERF"
            state = 1
        elif self.run and self.safety_clear:
            self.led_cmd = "DTDST"
            state = 2
        elif self.dock and self.safety_clear:
            self.led_cmd = "RDOCK"
            state = 4
        else:
            self.led_cmd = "RIDLE"
            state = 3

        # Publish LED state only if it changes
        if self.led_cmd != self.last_led_cmd:
            msg = String()
            msg.data = self.led_cmd
            self.led_cmd_publisher.publish(msg)
            self.last_led_cmd = self.led_cmd

        # Check if at least 1.5 seconds have passed before playing a sound
        current_time = self.get_clock().now()
        if (current_time - self.last_play_time).nanoseconds / 1e9 >= 1.5:
            self.last_play_time = current_time  # Update last played time
            
            # Play sound based on state (commented out for now)
            # if state == 1:
            #     self.play_sound_async('/home/amr-wipro/office_ws/src/mybot_bringup/tones/warning.mp3', "state_1")
            # elif self.play_tone_dock:
            #     self.play_sound_async('/home/amr-wipro/office_ws/src/mybot_bringup/tones/docking_successful.mp3', "play_tone_dock")
            #     self.play_tone_dock = False
            # elif self.play_tone_no_dock:
            #     self.play_sound_async('/home/amr-wipro/office_ws/src/mybot_bringup/tones/docking_aborted.mp3', "play_tone_no_dock")
            #     self.play_tone_no_dock = False
            # elif state == 4:
            #     self.play_sound_async('/home/amr-wipro/office_ws/src/mybot_bringup/tones/moving.wav', "state_4")
            # elif state == 2:
            #     self.play_sound_async('/home/amr-wipro/office_ws/src/mybot_bringup/tones/moving.wav', "state_2")
            # elif state == 3:
            #     self.play_sound_async('/home/amr-wipro/office_ws/src/mybot_bringup/tones/idle.mp3', "state_3")

def main(args=None):
    rclpy.init(args=args)
    
    led_speaker_node = LEDSpeakerControlNode()
    
    try:
        rclpy.spin(led_speaker_node)
    except KeyboardInterrupt:
        pass
    finally:
        led_speaker_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()