#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
import os
from geometry_msgs.msg import Twist
from std_msgs.msg import Int16,Int32, Int64, Float32, String, UInt64
from math import pow, atan2, sqrt, pi
import time

class TicksBasedTurnWrap(Node):
	def __init__(self):
		super().__init__('turning_ticks_node')
		
		self.left_position  = 0.0
		self.right_position = 0.0
		self.left_received = False
		self.right_received = False

		# QoS Profile for instant data reflection with low latency
		qos_profile = QoSProfile(
			reliability=ReliabilityPolicy.BEST_EFFORT,  # Low latency, no retransmission
			durability=DurabilityPolicy.VOLATILE,       # No historical data
			history=HistoryPolicy.KEEP_LAST,
			depth=1                                      # Only keep latest message
		)

		# Create publisher and subscribers with QoS
		self.velocity_publisher = self.create_publisher(Twist, '/cmd_vel', qos_profile)
		self.create_subscription(Int64, "/moons_left_position", self.get_left_position, qos_profile)
		self.create_subscription(Int64, "/moons_right_position", self.get_right_position, qos_profile)
		
		self.turning   = False  # Start false, enable after encoder init
		self.direction = 0  
		self.change_in_turning = float(input("Enter turning in degrees: "))
		self.get_logger().info(f"Change in turning: {self.change_in_turning}")
		
		# turning parameters
		self.ticks_per_meter = 452500.00
		self.base_width 	 = 0.718 #0.734
		self.dist_break 	 = 0.001  # Stop when within 5mm of target
		self.diff 			 = 0.0005
		self.max_wheel_vel 	 = 0.15
		self.min_wheel_vel 	 = 0.015625
		
		# PID parameters
		self.kp 			 = 1.0
		self.prev_pid_time   = self.get_clock().now()
		self.left_stop 		 = False
		self.right_stop 	 = False
		
		# Track initial error direction to prevent oscillation
		self.left_error_sign  = None
		self.right_error_sign = None
		
		# Overshoot prevention threshold - stop before crossing zero
		self.overshoot_margin = 0.015  # Stop if within 15mm and approaching zero
		
		if self.change_in_turning > 0:
			self.direction = 1
		elif self.change_in_turning < 0 :
			self.direction = -1

		self.change_in_position = abs(self.change_in_turning * (pi *self.base_width/360))

		# Acceleration parameters
		self.initial_accel_dist_per = 50.0
		self.accel_step = 0.02
		self.initial_accel_dist = (self.initial_accel_dist_per / 100.0) * abs(self.change_in_position)
		self.get_logger().info(f"Initial accel dist: {self.initial_accel_dist}")
		self.max_vel = 0.0
		
		# Encoder wrap parameters
		self.encoder_min = 0
		self.encoder_max = 4294967295
		self.encoder_low_wrap = (self.encoder_max - self.encoder_min) * 0.3 + self.encoder_min
		self.encoder_high_wrap = (self.encoder_max - self.encoder_min) * 0.7 + self.encoder_min
		
		# Will be initialized after encoder data received
		self.initial_left_position = 0.0
		self.initial_right_position = 0.0
		self.left_distance_travelled = 0.0
		self.right_distance_travelled = 0.0
		self.left_previous = 0.0
		self.right_previous = 0.0
		self.left_increment = 0.0
		self.right_increment = 0.0
		self.positions_initialized = False

		self.change_in_left  = -1 * self.direction * self.change_in_position
		self.change_in_right = self.direction * self.change_in_position

		self.final_left_position = float((self.initial_left_position - self.change_in_left) * self.ticks_per_meter)     #in ticks
		self.final_right_position = float((self.initial_right_position + self.change_in_right) * self.ticks_per_meter)  #in ticks
				
	
		# Create timer for main loop (20 Hz)
		self.timer = self.create_timer(0.05, self.main_loop)
		
		self.vel_msg = Twist()

	def get_left_position(self, data):
		self.left_position = float(data.data)
		self.left_received = True	

	def get_right_position(self, data):
		self.right_position = float(data.data)
		self.right_received = True

	def clamp_velocity(self, velocity, min_velocity, max_velocity):
		min_velocity = abs(min_velocity)
		max_velocity = abs(max_velocity)
		if velocity >= 0:
			return float(min(max_velocity, max(min_velocity, velocity)))
		else:
			return float(max(-max_velocity, min(-min_velocity, velocity)))

	def add_offset(self, input_value, offset):
		if input_value > 0:
			return float(input_value + offset)
		elif input_value < 0:
			return float(input_value - offset)
		else:
			return 0.0
	
	def main_loop(self):
		# Wait for encoder data before initializing
		if not self.positions_initialized:
			if self.left_received and self.right_received:
				self.initial_left_position = self.left_position
				self.initial_right_position = self.right_position
				self.left_previous = self.left_position
				self.right_previous = self.right_position

				self.positions_initialized = True
				self.turning = True
				self.get_logger().info(f"Encoder init: L={self.initial_left_position}, R={self.initial_right_position}")
				self.get_logger().info(f"Target ticks: L={self.final_left_position}, R={self.final_right_position}")
			return

		# Calculate encoder wrapping for left
		if self.left_position < self.encoder_low_wrap and self.left_previous > self.encoder_high_wrap:
			ticks_travelled_left = float((self.left_position - self.encoder_min) + (self.encoder_max - self.left_previous + 1))
		
		elif self.left_position > self.encoder_high_wrap and self.left_previous < self.encoder_low_wrap:
			ticks_travelled_left = float(-1 * ((self.left_previous - self.encoder_min) + (self.encoder_max - self.left_position + 1)))
		
		else:
			ticks_travelled_left = float(self.left_previous - self.left_position)
		
		self.left_previous = self.left_position
		self.left_increment = ticks_travelled_left

		# Calculate encoder wrapping for right
		if self.right_position < self.encoder_low_wrap and self.right_previous > self.encoder_high_wrap:
			ticks_travelled_right = float((self.right_position - self.encoder_min) + (self.encoder_max - self.right_previous))
		
		elif self.right_position > self.encoder_high_wrap and self.right_previous < self.encoder_low_wrap:
			ticks_travelled_right = float(-1 * ((self.right_previous - self.encoder_min) + (self.encoder_max - self.right_position)))
		
		else:
			ticks_travelled_right = float(self.right_position - self.right_previous)

		self.right_previous = self.right_position
		self.right_increment = ticks_travelled_right

		if self.turning:
			self.prev_pid_time = self.get_clock().now()

			self.left_distance_travelled = self.left_distance_travelled - self.left_increment     #in ticks
			self.right_distance_travelled = self.right_distance_travelled + self.right_increment  #in ticks
 
			left_error  = (self.final_left_position - self.left_distance_travelled) / self.ticks_per_meter       #in meter
			right_error = (self.final_right_position - self.right_distance_travelled) / self.ticks_per_meter     #in meter

			# Store initial error direction on first iteration
			if self.left_error_sign is None:
				self.left_error_sign = 1 if left_error > 0 else -1
			if self.right_error_sign is None:
				self.right_error_sign = 1 if right_error > 0 else -1
			
			# Check stopping conditions FIRST before any velocity calculations
			# Stop if within threshold OR if sign changed (overshoot)
			if not self.left_stop:
				if abs(left_error) <= self.dist_break or (left_error * self.left_error_sign) <= 0:
					self.vel_msg.linear.x = 0.0
					self.left_stop = True
				
			if not self.right_stop:
				if abs(right_error) <= self.dist_break or (right_error * self.right_error_sign) <= 0:
					self.vel_msg.angular.z = 0.0
					self.right_stop = True
			
			# If both stopped, exit early
			if self.left_stop and self.right_stop:
				self.turning = False
				stop_msg = Twist()
				stop_msg.linear.x = 0.0
				stop_msg.linear.y = 0.0
				stop_msg.linear.z = 0.0
				stop_msg.angular.x = 0.0
				stop_msg.angular.y = 0.0
				stop_msg.angular.z = 0.0
				self.velocity_publisher.publish(stop_msg)

				time.sleep(0.2)

				self.get_logger().info(f"Left error: {left_error}, Right error: {right_error}")
				self.get_logger().info(f"Target Reached! ")
				os._exit(0)

			# self.get_logger().info(f"left_increment: {int(self.left_increment)}, right_increment: {int(self.right_increment)}")
			# self.get_logger().info(f"L_err: {left_error:.4f}, R_err: {right_error:.4f}")
			# print("left_distance_travelled",self.left_distance_travelled,"right_distance_travelled",self.right_distance_travelled)  
			# print("left_error",left_error,"right_error",right_error)

			# Acceleration logic with aggressive deceleration zone to prevent overshoot
			decel_zone 			= 0.08  # Start decelerating at 8cm from target
			final_approach_zone = 0.02  # Extra slow in final 2cm
			
			if abs(left_error)  > self.initial_accel_dist:
				self.max_vel    = self.max_vel + self.accel_step
			else:
				self.max_vel    = self.max_wheel_vel
			
			if abs(right_error) > self.initial_accel_dist:
				self.max_vel 	= self.max_vel + self.accel_step
			else:
				self.max_vel 	= self.max_wheel_vel

			if not self.left_stop:
				self.vel_msg.linear.x = float(left_error * self.kp)
				
				# Apply aggressive deceleration scaling near target to prevent overshoot
				if abs(left_error) < final_approach_zone:
					# Final approach - very slow, proportional to error
					decel_factor = abs(left_error) / final_approach_zone
					target_max_vel = self.min_wheel_vel * 0.5 + (self.min_wheel_vel * 0.5) * decel_factor
					self.vel_msg.linear.x = self.clamp_velocity(self.vel_msg.linear.x, 0.0, target_max_vel)
				
				elif abs(left_error) < decel_zone:
					# Deceleration zone
					decel_factor = abs(left_error) / decel_zone
					target_max_vel = self.min_wheel_vel + (self.max_wheel_vel - self.min_wheel_vel) * decel_factor
					self.vel_msg.linear.x = self.clamp_velocity(self.vel_msg.linear.x, self.min_wheel_vel, target_max_vel)
				
				else:
					self.vel_msg.linear.x = self.clamp_velocity(self.vel_msg.linear.x, self.min_wheel_vel, self.max_vel)
					self.vel_msg.linear.x = self.clamp_velocity(self.vel_msg.linear.x, self.min_wheel_vel, self.max_wheel_vel)

			if not self.right_stop:
				self.vel_msg.angular.z = float(right_error * self.kp)
				
				# Apply aggressive deceleration scaling near target to prevent overshoot
				if abs(right_error) < final_approach_zone:
					# Final approach - very slow, proportional to error
					decel_factor = abs(right_error) / final_approach_zone
					target_max_vel = self.min_wheel_vel * 0.5 + (self.min_wheel_vel * 0.5) * decel_factor
					self.vel_msg.angular.z = self.clamp_velocity(self.vel_msg.angular.z, 0.0, target_max_vel)
				elif abs(right_error) < decel_zone:
					# Deceleration zone
					decel_factor = abs(right_error) / decel_zone
					target_max_vel = self.min_wheel_vel + (self.max_wheel_vel - self.min_wheel_vel) * decel_factor
					self.vel_msg.angular.z = self.clamp_velocity(self.vel_msg.angular.z, self.min_wheel_vel, target_max_vel)
				else:
					self.vel_msg.angular.z = self.clamp_velocity(self.vel_msg.angular.z, self.min_wheel_vel, self.max_vel)
					self.vel_msg.angular.z = self.clamp_velocity(self.vel_msg.angular.z, self.min_wheel_vel, self.max_wheel_vel)
				
			# Differential correction with distance-based scaling for smooth motion
			diff_error = abs(left_error) - abs(right_error)
			avg_error = (abs(left_error) + abs(right_error)) / 2.0
			
			# Scale diff_kp based on distance to target - reduce aggressiveness near target
			if avg_error > 0.05:  # Far from target
				diff_kp = 3.0
			elif avg_error > 0.01:  # Medium distance
				diff_kp = 1.5
			else:  # Close to target - minimal correction to avoid oscillation
				diff_kp = 0.5
			
			diff_addup = abs(diff_error * diff_kp)
			
			# Increase deadband near target to prevent oscillation
			diff_threshold = self.diff if avg_error > 0.01 else self.diff * 3.0

			# self.get_logger().info(f"L_vel: {self.vel_msg.linear.x:.4f} R_vel: {self.vel_msg.angular.z:.4f}")

			if abs(diff_error) > diff_threshold:
				
				if abs(left_error) < abs(right_error):
					self.vel_msg.linear.x = self.add_offset(self.vel_msg.linear.x, -diff_addup)
					self.vel_msg.angular.z = self.add_offset(self.vel_msg.angular.z, diff_addup)
				elif abs(left_error) > abs(right_error):
					self.vel_msg.linear.x = self.add_offset(self.vel_msg.linear.x, diff_addup)
					self.vel_msg.angular.z = self.add_offset(self.vel_msg.angular.z, -diff_addup)
			
			# Debug output enabled
			print(f"L_err: {left_error:.4f}m, R_err: {right_error:.4f}m, diff_err: {diff_error:.4f}m, L_vel: {self.vel_msg.linear.x:.4f}, R_vel: {self.vel_msg.angular.z:.4f}")
			
			if not self.left_stop:
				self.vel_msg.linear.x = self.clamp_velocity(self.vel_msg.linear.x, self.min_wheel_vel / 2, self.max_wheel_vel)

			if not self.right_stop:
				self.vel_msg.angular.z = self.clamp_velocity(self.vel_msg.angular.z, self.min_wheel_vel / 2, self.max_wheel_vel)
		
		# Publish velocity command
		self.velocity_publisher.publish(self.vel_msg)

def main(args=None):
	rclpy.init(args=args)
	ticks_move_node = TicksBasedTurnWrap()
	try:
		rclpy.spin(ticks_move_node)
	except KeyboardInterrupt:
		pass
	finally:
		ticks_move_node.destroy_node()
		rclpy.shutdown()

if __name__ == '__main__':
	main()