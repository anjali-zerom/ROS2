#!/usr/bin/env python3
"""
Check QoS settings of critical topics
Helps diagnose QoS mismatch issues
"""
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy

class QoSChecker(Node):
    def __init__(self):
        super().__init__('qos_checker')
        self.get_logger().info('=== QoS Settings Checker ===\n')
        
        # Topics to check
        topics_to_check = [
            '/scan',
            '/scan_front',
            '/scan_rear',
            '/odom',
            '/noisy_odom',
            '/map',
            '/local_costmap/costmap',
            '/global_costmap/costmap',
            '/tf',
            '/particle_cloud'
        ]
        
        self.check_topics(topics_to_check)
        
        self.get_logger().info('\n=== QoS Check Complete ===')
    
    def check_topics(self, topics):
        """Check QoS settings for given topics"""
        
        # Get all topics with their types and QoS
        topic_list = self.get_publishers_info_by_topic('')
        
        reliability_map = {
            ReliabilityPolicy.RELIABLE: 'RELIABLE',
            ReliabilityPolicy.BEST_EFFORT: 'BEST_EFFORT',
            ReliabilityPolicy.SYSTEM_DEFAULT: 'SYSTEM_DEFAULT',
            ReliabilityPolicy.UNKNOWN: 'UNKNOWN'
        }
        
        durability_map = {
            DurabilityPolicy.TRANSIENT_LOCAL: 'TRANSIENT_LOCAL',
            DurabilityPolicy.VOLATILE: 'VOLATILE',
            DurabilityPolicy.SYSTEM_DEFAULT: 'SYSTEM_DEFAULT',
            DurabilityPolicy.UNKNOWN: 'UNKNOWN'
        }
        
        for topic in topics:
            self.get_logger().info(f'\n--- {topic} ---')
            
            if topic not in topic_list:
                self.get_logger().info('  ✗ Topic not found')
                continue
            
            publishers = topic_list[topic]
            
            if not publishers:
                self.get_logger().info('  ✗ No publishers')
                continue
            
            for i, pub_info in enumerate(publishers):
                qos = pub_info.qos_profile
                
                reliability = reliability_map.get(qos.reliability, 'UNKNOWN')
                durability = durability_map.get(qos.durability, 'UNKNOWN')
                
                self.get_logger().info(f'  Publisher {i+1}:')
                self.get_logger().info(f'    Reliability: {reliability}')
                self.get_logger().info(f'    Durability:  {durability}')
                self.get_logger().info(f'    Depth:       {qos.depth}')
            
            # Also check subscribers
            subscribers = self.get_subscriptions_info_by_topic(topic)
            if subscribers:
                self.get_logger().info(f'  Subscribers: {len(subscribers)}')
                for i, sub_info in enumerate(subscribers[:3]):  # Show first 3
                    qos = sub_info.qos_profile
                    reliability = reliability_map.get(qos.reliability, 'UNKNOWN')
                    self.get_logger().info(f'    Sub {i+1}: {reliability}')

def main(args=None):
    rclpy.init(args=args)
    checker = QoSChecker()
    
    # Don't spin, just run once
    import time
    time.sleep(1.0)
    
    checker.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
