#!/usr/bin/env python3
"""
Simple angular filter for laser scan data
Filters /scan_front to keep only data between -135° and -100°
"""
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan
import math
import numpy as np

class AngularFilter(Node):
    def __init__(self):
        super().__init__('angular_filter_front')
        
        # Define angular ranges directly (ROS 2 parameters don't handle nested lists well)
        # Multiple ranges as requested: -135° to -100°, -90° to +90°, +100° to +135°
        self.declare_parameter('range_1_start', -135.0)
        self.declare_parameter('range_1_end'  , -105.0)
        self.declare_parameter('range_2_start', -90.0)
        self.declare_parameter('range_2_end'  ,  90.0)
        self.declare_parameter('range_3_start',  100.0)
        self.declare_parameter('range_3_end'  ,  135.0)
        
        # Use standard sensor_data QoS profile (BEST_EFFORT, depth=5)
        # Subscribe to raw scan
        self.subscription = self.create_subscription(
            LaserScan,
            '/scan_front',
            self.scan_callback,
            qos_profile_sensor_data)
        
        # Publisher for filtered scan
        self.publisher = self.create_publisher(
            LaserScan, 
            '/scan_front_filtered', 
            qos_profile_sensor_data)
        
        # Build angular ranges from parameters
        self.angular_ranges = []
        ranges_deg = []
        
        # Add ranges that are defined (non-zero)
        for i in range(1, 4):  # Support up to 3 ranges
            try:
                start = self.get_parameter(f'range_{i}_start').value
                end = self.get_parameter(f'range_{i}_end').value
                if start != end:  # Only add if range is valid
                    self.angular_ranges.append((math.radians(start), math.radians(end)))
                    ranges_deg.append(f"{start:.0f}° to {end:.0f}°")
            except:
                break  # Stop if parameter doesn't exist
        
        range_str = ", ".join(ranges_deg)
        self.get_logger().info(f'Angular filter started with ranges: {range_str}')
    
    def scan_callback(self, msg):
        # Create filtered message - maintain exact same structure as input for stability
        filtered_msg = LaserScan()
        filtered_msg.header = msg.header
        filtered_msg.angle_min = msg.angle_min
        filtered_msg.angle_max = msg.angle_max
        filtered_msg.angle_increment = msg.angle_increment
        filtered_msg.time_increment = msg.time_increment
        filtered_msg.scan_time = msg.scan_time
        filtered_msg.range_min = msg.range_min
        filtered_msg.range_max = msg.range_max
        
        # Pre-calculate for maximum efficiency
        start_angle = msg.angle_min
        angle_increment = msg.angle_increment
        num_points = len(msg.ranges)
        invalid_value = msg.range_max  # More stable than inf for RViz
        
        # Copy original data
        filtered_ranges = list(msg.ranges)
        filtered_intensities = list(msg.intensities) if msg.intensities else [0.0] * num_points
        
        # Optimized filtering for exactly 3 ranges
        # Pre-extract bounds for speed
        r1_min, r1_max = self.angular_ranges[0]
        r2_min, r2_max = self.angular_ranges[1] 
        r3_min, r3_max = self.angular_ranges[2]
        
        # Single pass through data with optimized range checking
        angle = start_angle
        for i in range(num_points):
            # Fast triple range check - no loops
            if not ((r1_min <= angle <= r1_max) or 
                    (r2_min <= angle <= r2_max) or 
                    (r3_min <= angle <= r3_max)):
                # Point not in any range - invalidate
                filtered_ranges[i] = invalid_value
                filtered_intensities[i] = 0.0
            
            angle += angle_increment
        
        filtered_msg.ranges = filtered_ranges
        filtered_msg.intensities = filtered_intensities
        
        # Publish filtered scan
        self.publisher.publish(filtered_msg)

def main(args=None):
    rclpy.init(args=args)
    angular_filter = AngularFilter()
    
    try:
        rclpy.spin(angular_filter)
    except KeyboardInterrupt:
        pass
    finally:
        angular_filter.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()