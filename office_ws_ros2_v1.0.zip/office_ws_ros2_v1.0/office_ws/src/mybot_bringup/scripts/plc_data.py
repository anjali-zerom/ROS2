#!/usr/bin/env python3
from pymodbus.client import ModbusTcpClient
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
import time
from std_msgs.msg import Int16, Float32, String
# from sick_safetyscanners.srv import StatusOverview, StatusOverviewRequest  # Replace with actual package and service

try:
    from mybot_bringup.msg import SafetyData as safety_data
except ImportError:
    # Fallback if the message generation didn't change the name case
    from mybot_bringup.msg import SafetyData

class PLCDataNode(Node):
    def __init__(self):
        super().__init__('plc_data_node')
        
        # QoS Profile for low latency communication (matching ticks_based_move_wrap.py)
        qos_profile_best_effort = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )

        qos_profile_reliable = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=5
        )
        # Declare parameters
        self.declare_parameter('plc_ip', '192.168.100.211')
        
        # Initialize variables
        self.acknowledgement_wait_status = None
        self.front_zone = 0
        self.rear_zone  = 0
        self.convyor_state = None
        
        self.left_wheel_velocity  = 0.0
        self.right_wheel_velocity = 0.0
        
        self.batt_per = 0.0
        self.batt_cur = 0.0
        self.batt_vol = 0.0
        
        self.software_sto_signal = 0
        self.left_alarm   = "L00000000000000000000000000000000"
        self.right_alarm  = "R00000000000000000000000000000000"
        
        self.convyor_cmd  = None
        self.shutdown_cmd = 0

        # Get PLC IP
        self.ip_address = self.get_parameter('plc_ip').get_parameter_value().string_value
        self.client     = ModbusTcpClient(self.ip_address)
        
        # Connect to PLC
        self.connect_to_plc()
        
        
        # Publishers
        self.pub_shutdown = self.create_publisher(Int16, '/shutdown_button_pushed', qos_profile_reliable)
        self.pub_acknowledgement = self.create_publisher(Int16, '/acknowledgement_white', qos_profile_reliable )
        self.pub_safety_clear = self.create_publisher(Int16, '/safety_clear', qos_profile_best_effort )
        self.pub_manual_break_engaged = self.create_publisher(Int16, '/manual_break_engaged', qos_profile_best_effort)
        self.pub_safety_data = self.create_publisher(safety_data, '/safety_data', qos_profile_best_effort)

        # Subscribers (using QoS for topics that need low latency)
        self.create_subscription(Int16, "/battery_percentage", self.battery_percentage_callback, qos_profile_reliable)
        self.create_subscription(Float32, "/battery_current", self.battery_current_callback, qos_profile_reliable)
        self.create_subscription(Float32, "/battery_voltage", self.battery_voltage_callback, qos_profile_reliable)
        self.create_subscription(Int16, "/front_zone_switch", self.front_zone_switching_callback, qos_profile_best_effort)
        self.create_subscription(Int16, "/rear_zone_switch", self.rear_zone_switching_callback, qos_profile_best_effort)
        self.create_subscription(Int16, "/acknowledgement_wait", self.acknowledgement_wait_callback, qos_profile_reliable)
        self.create_subscription(Float32, "/moons_left_speed", self.moons_left_speed_callback, qos_profile_best_effort)
        self.create_subscription(Float32, "/moons_right_speed", self.moons_right_speed_callback, qos_profile_best_effort)
        self.create_subscription(Int16, "/software_sto", self.software_sto_callback, qos_profile_best_effort)
        self.create_subscription(String, "/moons_left_alarm", self.left_alarm_callback, qos_profile_reliable)
        self.create_subscription(String, "/moons_right_alarm", self.right_alarm_callback, qos_profile_reliable)
        self.create_subscription(String, "/conveyor_command", self.conveyor_command, qos_profile_reliable)
        self.create_subscription(Int16, "/shutdown_command", self.shutdown_cmd_func, qos_profile_reliable)
        

        # Initialize counters
        self.heartbeat = 0
        self.rt = 0
        self.seq =0
        
        # Create timer for main loop (20 Hz)
        self.timer = self.create_timer(0.05, self.main_loop)
        
        self.get_logger().info(f"PLC Data Node started, connected to PLC at {self.ip_address}")

    def connect_to_plc(self):
        """Connect to PLC with retry logic"""
        while rclpy.ok():
            if self.client.connect():
                self.get_logger().info(f"Connected to PLC at {self.ip_address}")
                break
            self.get_logger().warn("Cannot connect to PLC. Retrying...")
            time.sleep(1)

    # Callback functions
    def battery_percentage_callback(self, msg):
        self.batt_per = msg.data

    def battery_current_callback(self, msg):
        self.batt_cur = msg.data

    def battery_voltage_callback(self, msg):
        self.batt_vol = msg.data

    def front_zone_switching_callback(self, msg):
        self.front_zone = msg.data

    def rear_zone_switching_callback(self, msg):
        self.rear_zone = msg.data
    
    def acknowledgement_wait_callback(self, msg):
        self.acknowledgement_wait_status = msg.data

    def moons_left_speed_callback(self, msg):
        self.left_wheel_velocity = msg.data

    def moons_right_speed_callback(self, msg):
        self.right_wheel_velocity = msg.data

    def software_sto_callback(self, msg):
        self.software_sto_signal = msg.data

    def left_alarm_callback(self, msg):
        self.left_alarm = msg.data

    def right_alarm_callback(self, msg):
        self.right_alarm = msg.data

    def conveyor_command(self, msg):
        self.convyor_cmd = msg.data

    def shutdown_cmd_func(self, msg):
        self.shutdown_cmd = msg.data
    
    # Utility Functions
    def get_dummy_register(self):
        return [0]

    def safe_read(self, addr, count=1, unit=1):
        if not self.client.connect():
            self.get_logger().warn("Modbus client disconnected. Trying to reconnect...")
            self.client.connect()
        try:
            result = self.client.read_holding_registers(addr, count, unit=unit)
            if result is None or not hasattr(result, 'registers'):
                raise Exception("Invalid response")
            return result.registers
        except Exception as e:
            self.get_logger().error(f"Read error at address {addr}: {e}")
            return self.get_dummy_register()

    def safe_write(self, addr, value, unit=1):
        if not self.client.connect():
            self.get_logger().warn("Modbus client disconnected. Trying to reconnect...")
            self.client.connect()
        try:
            self.client.write_registers(addr, value, unit=unit)
        except Exception as e:
            self.get_logger().error(f"Write error at address {addr}: {e}")

    def parse_binary_string(self, binary_string):
        """
        Converts a 32-bit binary string (with 'L/R' prefix) into two 16-bit integers,
        stores them in a list, and returns the list.
        """
        # Remove the 'L/R' prefix
        clean_string = binary_string[1:]

        # Validate length
        if len(clean_string) != 32:
            raise ValueError("The binary string must be exactly 32 bits (excluding the 'L/R').")

        # Reverse the entire string
        reversed_string = clean_string#[::-1]

        # Split into two 16-bit parts and convert
        result = [
            int(reversed_string[16:], 2),   # First 16 bits
            int(reversed_string[:16], 2)    # Last 16 bits
        ]

        return result

    def main_loop(self):
        """Main PLC communication loop"""
        try:
            shutdown = Int16()
            shutdown.data = self.safe_read(1)[0]
            self.pub_shutdown.publish(shutdown)
            
            acknowledgement = Int16()
            acknowledgement.data = self.safe_read(2)[0]
            self.pub_acknowledgement.publish(acknowledgement)
            
            batt_charging = self.safe_read(3)[0]
            front_scanner_contamination = self.safe_read(4)[0]
            front_scanner_warning = self.safe_read(5)[0]
            front_scanner_error = self.safe_read(6)[0]

            rear_scanner_contamination = self.safe_read(7)[0]
            rear_scanner_warning = self.safe_read(8)[0]
            rear_scanner_error = self.safe_read(9)[0]

            safety_clear = self.safe_read(10)[0]
            safety_clear_msg = Int16()
            safety_clear_msg.data = safety_clear
            self.pub_safety_clear.publish(safety_clear_msg)
            
            # lifter_status = self.safe_read(11)[0]
            conveyor_status = self.safe_read(11)[0]

            #----12 and 13 spare ----

            safety_msg = safety_data()
            safety_msg.seq = self.seq
            safety_msg.stamp = self.get_clock().now().to_msg()

            safety_msg.front_emergency             = bool(self.safe_read(14)[0])
            safety_msg.rear_emergency              = bool(self.safe_read(15)[0])
            safety_msg.front_scanner               = bool(self.safe_read(16)[0])
            safety_msg.rear_scanner                = bool(self.safe_read(17)[0])
            safety_msg.reset_pending               = bool(self.safe_read(18)[0])
            safety_msg.manual_break_engaged        = bool(self.safe_read(19)[0])

            safety_msg.safety_clear                = bool(safety_clear)
            # safety_msg.lifter_status               = bool(lifter_status)
            safety_msg.conveyor_status             = bool(conveyor_status)
            safety_msg.front_scanner_warning       = bool(front_scanner_warning)
            safety_msg.rear_scanner_warning        = bool(rear_scanner_warning)
            safety_msg.front_scanner_error         = bool(front_scanner_error)
            safety_msg.rear_scanner_error          = bool(rear_scanner_error)
            safety_msg.front_scanner_contamination = bool(front_scanner_contamination)
            safety_msg.rear_scanner_contamination  = bool(rear_scanner_contamination)
            
            safety_msg.software_stop_from_ros      = bool(self.safe_read(60)[0])

            self.seq = self.seq + 1
            self.pub_safety_data.publish(safety_msg)

            # --------- Write Outputs --------- #
            
            # Heartbeat , connection established with plc
            if self.rt == 9:
                self.heartbeat = 1 - self.heartbeat
                self.safe_write(50, self.heartbeat)
                self.rt = 0
            self.rt += 1

            # if self.acknowledgement_wait_status is not None:
            #     self.safe_write(52, self.acknowledgement_wait_status)
            #     self.acknowledgement_wait_status = None

            self.safe_write(53, abs(int(self.batt_per * 10)))
            self.safe_write(54, int(self.batt_vol * 100))

            current = int(self.batt_cur * 100)
            if current < 0:
                current += 2 ** 16
            self.safe_write(55, current)

            self.safe_write(56, self.front_zone)
            self.safe_write(57, self.rear_zone)

            left_wheel_velocity_mm = (self.left_wheel_velocity * 1000)
            if left_wheel_velocity_mm < 0:
                left_wheel_velocity_mm += 2**16
            self.safe_write(58, int(left_wheel_velocity_mm))
            
            right_wheel_velocity_mm = (self.right_wheel_velocity * 1000)
            if right_wheel_velocity_mm < 0:
                right_wheel_velocity_mm += 2**16
            self.safe_write(59, int(right_wheel_velocity_mm))
            
            self.safe_write(60, self.software_sto_signal)

            left_alarm_error = self.parse_binary_string(self.left_alarm)
            self.safe_write(66, left_alarm_error[0])
            self.safe_write(67, left_alarm_error[1])

            right_alarm_error = self.parse_binary_string(self.right_alarm)
            self.safe_write(68, right_alarm_error[0])
            self.safe_write(69, right_alarm_error[1])
            
            self.safe_write(71, self.shutdown_cmd)
            
            self.safe_write(100, 100) #ros initialise for first time

        except Exception as e:
            self.get_logger().error(f"Main loop exception: {e}")


def main(args=None):
    rclpy.init(args=args)
    
    plc_node = PLCDataNode()
    
    try:
        rclpy.spin(plc_node)
    except KeyboardInterrupt:
        pass
    finally:
        plc_node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
