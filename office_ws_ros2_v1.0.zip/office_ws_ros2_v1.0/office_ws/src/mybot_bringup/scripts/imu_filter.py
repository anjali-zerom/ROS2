#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Imu
import os
from std_msgs.msg import Int16, Int32, Int64, Float32, String, UInt64

class ImuFilterNode(Node):
    def __init__(self):
        super().__init__('imu_filter_node')
        
        # QoS Profile for low latency communication (matching ticks_based_move_wrap.py)
        qos_profile_best_effort = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )

        self.get_logger().info("imu filter Running...")
        
        # Initialize variables
        self.imu_msg = Imu()
        self.right_speed = 0.0
        self.left_speed = 0.0
        self.count = 0
        
        # Declare parameter
        self.declare_parameter('stop_vel', 0.001)
        self.stop_vel = self.get_parameter('stop_vel').get_parameter_value().double_value
        
        # Create subscribers
        self.imu_sub = self.create_subscription(
            Imu,
            '/imu/imu_raw',
            self.imu_callback,
            qos_profile_best_effort
        )
        
        self.left_speed_sub = self.create_subscription(
            Float32,
            '/moons_left_speed',
            self.left_callback,
            qos_profile_best_effort
        )
        
        self.right_speed_sub = self.create_subscription(
            Float32,
            '/moons_right_speed',
            self.right_callback,
            qos_profile_best_effort
        )
        
        # Create publisher
        self.imu_pub = self.create_publisher(
            Imu,
            '/imu/imu_filter',
            qos_profile_best_effort
        )
        
        self.imu_final = Imu()
        
        # Create timer for 20 Hz operation
        self.timer = self.create_timer(0.05, self.timer_callback)  # 20 Hz = 0.05s
        
    def imu_callback(self, data):
        self.imu_msg = data
        
    def left_callback(self, data):
        self.left_speed = data.data
        
    def right_callback(self, data):
        self.right_speed = data.data
        
    def timer_callback(self):
        if abs(self.left_speed) > self.stop_vel or abs(self.right_speed) > self.stop_vel:
            self.count = 0
            self.imu_final = self.imu_msg
            
        elif abs(self.left_speed) < self.stop_vel and abs(self.right_speed) < self.stop_vel:
            self.count += 1
            if self.count > 1:
                self.imu_final = self.imu_msg

                self.imu_final.angular_velocity.x = 0.0
                self.imu_final.angular_velocity.y = 0.0
                self.imu_final.angular_velocity.z = 0.0

                self.imu_final.linear_acceleration.x = 0.0
                self.imu_final.linear_acceleration.y = 0.0

                if self.count > 100:
                    self.count = 2
                    
            else:
                self.imu_final = self.imu_msg

        self.imu_pub.publish(self.imu_final)

def main(args=None):
    rclpy.init(args=args)
    
    imu_filter_node = ImuFilterNode()
    
    try:
        rclpy.spin(imu_filter_node)
    except KeyboardInterrupt:
        pass
    finally:
        imu_filter_node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()



