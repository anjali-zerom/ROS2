#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.duration import Duration
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from math import sin, cos, pi
from geometry_msgs.msg import Quaternion
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from tf2_ros import TransformBroadcaster
from std_msgs.msg import Int16, Int64

class DiffTf(Node):
    def __init__(self):
        super().__init__("diff_tf")
        
        # QoS Profile for low latency communication (matching ticks_based_move_wrap.py)
        qos_profile_best_effort = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        self.get_logger().info(f"-I- {self.get_name()} started")
        
        #### parameters #######
        self.declare_parameter('publish_tf', True)
        self.publish_tf = self.get_parameter('publish_tf').get_parameter_value().bool_value
        
        self.declare_parameter('rate', 20.0)
        self.declare_parameter('ticks_meter', 452500)
        self.declare_parameter('base_width', 0.734)
        self.declare_parameter('base_frame_id', 'base_footprint')
        self.declare_parameter('odom_frame_id', 'odom')
        self.declare_parameter('encoder_min', 0)
        self.declare_parameter('encoder_max', 4294967295)
        self.declare_parameter('wheel_low_wrap', 0.0)
        self.declare_parameter('wheel_high_wrap', 0.0)        
        self.rate = self.get_parameter('rate').get_parameter_value().double_value
        self.ticks_meter = float(self.get_parameter('ticks_meter').get_parameter_value().integer_value)
        self.base_width = float(self.get_parameter('base_width').get_parameter_value().double_value)
        
        self.base_frame_id = self.get_parameter('base_frame_id').get_parameter_value().string_value
        self.odom_frame_id = self.get_parameter('odom_frame_id').get_parameter_value().string_value
        
        self.encoder_min = self.get_parameter('encoder_min').get_parameter_value().integer_value
        self.encoder_max = self.get_parameter('encoder_max').get_parameter_value().integer_value
        
        # Calculate wrap values if not set
        wheel_low_wrap = self.get_parameter('wheel_low_wrap').get_parameter_value().double_value
        wheel_high_wrap = self.get_parameter('wheel_high_wrap').get_parameter_value().double_value
        
        if wheel_low_wrap == 0.0:
            self.encoder_low_wrap = (self.encoder_max - self.encoder_min) * 0.3 + self.encoder_min
        else:
            self.encoder_low_wrap = wheel_low_wrap
            
        if wheel_high_wrap == 0.0:
            self.encoder_high_wrap = (self.encoder_max - self.encoder_min) * 0.7 + self.encoder_min
        else:
            self.encoder_high_wrap = wheel_high_wrap
 
        self.t_delta = Duration(seconds=1.0/self.rate)
        self.t_next = self.get_clock().now() + self.t_delta
        
        # internal data
        self.enc_left = None        # wheel encoder readings
        self.enc_right = None
        self.left = 0               # actual values coming back from robot
        self.right = 0
        self.lmult = 0
        self.rmult = 0
        self.prev_lencoder = 0
        self.prev_rencoder = 0
        self.x = 0.0                # position in xy plane 
        self.y = 0.0
        self.th = 0.0
        self.dx = 0.0               # speeds in x/rotation
        self.dr = 0.0
        self.then = self.get_clock().now()
        
        # subscriptions
        self.left_sub = self.create_subscription(
            Int64, 
            "moons_left_position", 
            self.lwheel_callback, 
            qos_profile_best_effort)
        self.right_sub = self.create_subscription(
            Int64, 
            "moons_right_position", 
            self.rwheel_callback, 
            qos_profile_best_effort)
        
        self.odom_pub = self.create_publisher(Odometry, "noisy_odom", qos_profile_best_effort)

        self.odom_broadcaster = TransformBroadcaster(self)
        
        # Create timer for update loop
        self.timer = self.create_timer(1.0/self.rate, self.update)

    def update(self):
        try:
            now = self.get_clock().now()
            # Calculate elapsed time
            elapsed_duration = now - self.then
            self.then = now
            elapsed = elapsed_duration.nanoseconds / 1e9

            if elapsed == 0:
                return # Avoid division by zero

            # calculate odometry
            d_left = 0
            d_right = 0
            if self.enc_left is None:
                # self.get_logger().info('Waiting for encoders...')
                pass
            else:
                d_left = (self.left - self.enc_left) / self.ticks_meter
                d_right = (self.right - self.enc_right) / self.ticks_meter

            self.enc_left = self.left
            self.enc_right = self.right
           
            # distance traveled is the average of the two wheels 
            d = ( d_left + d_right ) / 2
            # this approximation works (in radians) for small angles
            th = ( d_right - d_left ) / self.base_width
            # calculate velocities
            self.dx = d / elapsed
            self.dr = th / elapsed
           
            if (d != 0):
                # calculate distance traveled in x and y
                x = cos( th ) * d
                y = -sin( th ) * d
                # calculate the final position of the robot
                self.x = self.x + ( cos( self.th ) * x - sin( self.th ) * y )
                self.y = self.y + ( sin( self.th ) * x + cos( self.th ) * y )
            if( th != 0):
                self.th = self.th + th
                
            # publish the odom information
            quaternion = Quaternion()
            quaternion.x = 0.0
            quaternion.y = 0.0
            quaternion.z = sin( self.th / 2 )
            quaternion.w = cos( self.th / 2 )
            
            # Broadcast TF transform only if enabled
            if self.publish_tf:
                from geometry_msgs.msg import TransformStamped
                t = TransformStamped()
                t.header.stamp = now.to_msg()
                t.header.frame_id = self.odom_frame_id
                t.child_frame_id = self.base_frame_id
                t.transform.translation.x = self.x
                t.transform.translation.y = self.y
                t.transform.translation.z = 0.0
                t.transform.rotation = quaternion
                self.odom_broadcaster.sendTransform(t)

            # Publish odometry message
            odom = Odometry()
            odom.header.stamp = now.to_msg()
            odom.header.frame_id = self.odom_frame_id
            odom.pose.pose.position.x = self.x
            odom.pose.pose.position.y = self.y
            odom.pose.pose.position.z = 0.0
            odom.pose.pose.orientation = quaternion
            odom.child_frame_id = self.base_frame_id
            odom.twist.twist.linear.x = self.dx
            odom.twist.twist.linear.y = 0.0
            odom.twist.twist.angular.z = self.dr
            
            odom.pose.covariance = [1e-3, 0.0, 0.0, 0.0, 0.0, 0.0,
                                   0.0, 1e-3, 0.0, 0.0, 0.0, 0.0, 
                                   0.0, 0.0, 1e6, 0.0, 0.0, 0.0, 
                                   0.0, 0.0, 0.0, 1e6, 0.0, 0.0, 
                                   0.0, 0.0, 0.0, 0.0, 1e6, 0.0, 
                                   0.0, 0.0, 0.0, 0.0, 0.0, 1e3]
            self.odom_pub.publish(odom)

        except Exception as e:
             self.get_logger().error(f'Error in update loop: {e}')

    def lwheel_callback(self, msg):
        enc = msg.data
        if (enc < self.encoder_low_wrap and self.prev_lencoder > self.encoder_high_wrap):
            self.lmult = self.lmult + 1
            
        if (enc > self.encoder_high_wrap and self.prev_lencoder < self.encoder_low_wrap):
            self.lmult = self.lmult - 1
            
        # self.left = 1.0 * (enc + self.lmult * (self.encoder_max - self.encoder_min)) #leadshine
        self.left = -1.0 * (enc + self.lmult * (self.encoder_max - self.encoder_min))  #moons

        self.prev_lencoder = enc
        
    def rwheel_callback(self, msg):
        enc = msg.data
        if(enc < self.encoder_low_wrap and self.prev_rencoder > self.encoder_high_wrap):
            self.rmult = self.rmult + 1
        
        if(enc > self.encoder_high_wrap and self.prev_rencoder < self.encoder_low_wrap):
            self.rmult = self.rmult - 1
            
        # self.right = -1.0 * (enc + self.rmult * (self.encoder_max - self.encoder_min)) #leadshine
        self.right = 1.0 * (enc + self.rmult * (self.encoder_max - self.encoder_min)) #moons
        self.prev_rencoder = enc

def main(args=None):
    rclpy.init(args=args)
    
    diff_tf = DiffTf()
    
    try:
        rclpy.spin(diff_tf)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        diff_tf.get_logger().error(f'Crash in spin: {e}')
        import traceback
        traceback.print_exc()
    finally:
        diff_tf.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()