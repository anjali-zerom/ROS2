#!/usr/bin/env python3
import os
import tf2_ros
import time
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist,PoseStamped,Pose,PoseWithCovarianceStamped
from std_msgs.msg import Int16,Int32, Int64, Float32, String, UInt64,Bool
from nav_msgs.msg import Odometry
from math import pow, atan, sqrt, pi,cos,sin,acos
import math 

class TicksBasedDockingPatternWrap(Node):
	def __init__(self):
		super().__init__('dockerhalt_docker_node')
		
		# Initialize global variables as instance variables
		self.doc_position_x = []
		self.doc_position_y = []
		self.doc_position_z = []
		self.dock_count = 0
		self.docker_pose = Twist()
		self.right_position = 0
		self.left_position = 0
		self.right_vel = 0
		self.left_vel = 0
		self.max_count = 35
		self.y_offset = 0.0
		self.docking_command = "False"
		self.start_time = time.time()
		
		# Publishers
		self.docking_state_publisher = self.create_publisher(String, '/docking_state', 10)
		self.velocity_publisher = self.create_publisher(Twist, '/cmd_vel', 10)
		self.zone_publisher = self.create_publisher(Int16, '/front_zone_switch', 10)
		self.docking_log_publisher = self.create_publisher(String, 'docking_logger', 10)
		self.docking_command_ack_publisher = self.create_publisher(String, '/docking_command_ack', 10)
		self.change_angle_publisher = self.create_publisher(String, '/change_angle', 10)
		
		# Subscribers
		self.create_subscription(Twist, "raw_docker_pose", self.get_docker_pose, 10)
		self.create_subscription(Int64, "moons_left_position", self.get_left_position, 10)
		self.create_subscription(Int64, "moons_right_position", self.get_right_position, 10)
		self.create_subscription(String, "start_docking", self.start_docking, 10)
		self.create_subscription(Float32, "moons_left_speed", self.get_left_vel, 10)
		self.create_subscription(Float32, "moons_right_speed", self.get_right_vel, 10)
		self.create_subscription(Float32, "y_offset", self.get_y_offset, 10)
		
		self.approach()

	def get_left_position(self, data):
		self.left_position = data.data

	def get_right_position(self, data):
		self.right_position = data.data
		
	def get_docker_pose(self, data):
		self.docker_pose = data

		self.doc_position_x.append(round(self.docker_pose.linear.x ,4))
		self.doc_position_y.append(round(self.docker_pose.linear.y ,4))
		self.doc_position_z.append(round(self.docker_pose.angular.z ,4))
		
		self.dock_count += 1
		
		if len(self.doc_position_x) >= self.max_count:
			self.doc_position_x.pop(0)
			self.doc_position_y.pop(0)
			self.doc_position_z.pop(0)

	def get_left_vel(self, data):
		self.left_vel = data.data

	def get_right_vel(self, data):
		self.right_vel = data.data

	def get_y_offset(self, data):
		self.y_offset = data.data

	def start_docking(self, data):
		self.docking_command = data.data

		self.doc_position_x = []
		self.doc_position_y = []
		self.doc_position_z = []
		self.dock_count = 0
		self.start_time = time.time()

	def clamp_velocity(self, velocity, min_velocity, max_velocity):
		min_velocity = abs(min_velocity)  # Ensure min_velocity is positive
		max_velocity = abs(max_velocity)  # Ensure max_velocity is positive
		
		if velocity >= 0:
			return min(max_velocity, max(min_velocity, velocity))
		else:
			return max(-max_velocity, min(-min_velocity, velocity))

	def add_offset(self, input_value, offset):
		if input_value > 0:
			return input_value + offset
		elif input_value < 0:
			return input_value - offset
		else:
			return 0

	def approach(self):
		self.right_vel = 0
		self.left_vel = 0
		self.max_count = 35
		self.y_offset = 0.0
		self.docking_command = "False"
		self.start_time = time.time()
		
		# Publishers
		self.docking_state_publisher = self.create_publisher(String, '/docking_state', 10)
		self.velocity_publisher = self.create_publisher(Twist, '/cmd_vel', 10)
		self.zone_publisher = self.create_publisher(Int16, '/front_zone_switch', 10)
		self.docking_log_publisher = self.create_publisher(String, 'docking_logger', 10)
		self.docking_command_ack_publisher = self.create_publisher(String, '/docking_command_ack', 10)
		self.change_angle_publisher = self.create_publisher(String, '/change_angle', 10)
		
		# Subscribers
		self.create_subscription(Twist, "raw_docker_pose", self.get_docker_pose, 10)
		self.create_subscription(Int64, "moons_left_position", self.get_left_position, 10)
		self.create_subscription(Int64, "moons_right_position", self.get_right_position, 10)
		self.create_subscription(String, "start_docking", self.start_docking, 10)
		self.create_subscription(Float32, "moons_left_speed", self.get_left_vel, 10)
		self.create_subscription(Float32, "moons_right_speed", self.get_right_vel, 10)
		self.create_subscription(Float32, "y_offset", self.get_y_offset, 10)
		
		self.approach()

	
	vel_msg = Twist()
	vel_msg.linear.x  = 0
	vel_msg.linear.y  = 0
	vel_msg.linear.z  = 0
	vel_msg.angular.x = 0
	vel_msg.angular.y = 0
	vel_msg.angular.z = 0
	
	lowest_speed    = 0.001   #m/sec
	robot_stop 		= False
	
	wait_time 		= 5
	trigger         = None

	target_found    = False
	dist_charger 	= 0.75 
	dist_straight 	= 0.112
	distance_to_doc = dist_charger 
	state           = None

	active          = False
	turning_tolerance = 0.25     #degrees

	direction 			= 0			
	dist_break  		= 0.0015		#mm
	diff_dist			= 0.0005		#mm
	max_turn_wheel_vel	= 0.1      	#0.2 #m/sec
	max_move_wheel_vel	= 0.25      #m/sec
	min_wheel_vel   	= 0.03      #0.015625  #m/sec
	
	initial_accel_dist_per 	= 50.0
	accel_step      		= 0.02

	# angle_tolerance = 0.1
	# y_offset 		=  0.015
	

	ticks_per_meter = 452500.00 #339204.00
	base_width      = 0.734 
	
	left_previous   = left_position
	right_previous  = right_position
	left_increment  = 0
	right_increment = 0

	encoder_min	   	  = 0
	encoder_max 	  = 4294967295
	encoder_low_wrap  = (encoder_max - encoder_min) * 0.3 + encoder_min 
	encoder_high_wrap = (encoder_max - encoder_min) * 0.7 + encoder_min 

	print("approach node started , waiting for dock command")
	change_angle_publisher.publish("False")  

	timer = self.create_timer(0.05, self.approach_timer_callback)  # 20 Hz
		
	def approach_timer_callback(self):
		if True:  # Main loop logic

		if left_position < encoder_low_wrap and left_previous > encoder_high_wrap :
			ticks_travelled_left = (left_position - encoder_min) + (encoder_max - left_previous + 1)
		elif left_position  > encoder_high_wrap and left_previous < encoder_low_wrap :
			ticks_travelled_left = -1 * ((left_previous - encoder_min) + (encoder_max - left_position + 1))
		else :
			ticks_travelled_left = (left_previous - left_position)
		
		left_previous = left_position
		left_increment = ticks_travelled_left

		if right_position < encoder_low_wrap and right_previous > encoder_high_wrap :
			ticks_travelled_right = (right_position - encoder_min) + (encoder_max - right_previous)
			
		elif right_position  > encoder_high_wrap and right_previous < encoder_low_wrap :
			ticks_travelled_right = -1 * ((right_previous - encoder_min) + (encoder_max - right_position))
		else :
			ticks_travelled_right = (right_position-right_previous)

		right_previous  = right_position
		right_increment = ticks_travelled_right

		while docking_command == "True":
			
			if left_position < encoder_low_wrap and left_previous > encoder_high_wrap :
				ticks_travelled_left = (left_position - encoder_min) + (encoder_max - left_previous + 1)
			elif left_position  > encoder_high_wrap and left_previous < encoder_low_wrap :
				ticks_travelled_left = -1 * ((left_previous - encoder_min) + (encoder_max - left_position + 1))
			else :
				ticks_travelled_left = (left_previous - left_position)
			
			left_previous = left_position
			left_increment = ticks_travelled_left

			if right_position < encoder_low_wrap and right_previous > encoder_high_wrap :
				ticks_travelled_right = (right_position - encoder_min) + (encoder_max - right_previous)
				
			elif right_position  > encoder_high_wrap and right_previous < encoder_low_wrap :
				ticks_travelled_right = -1 * ((right_previous - encoder_min) + (encoder_max - right_position))
			else :
				ticks_travelled_right = (right_position-right_previous)

			right_previous  = right_position
			right_increment = ticks_travelled_right

			docking_command_ack_publisher.publish("Received")

			
			if left_vel < lowest_speed and right_vel < lowest_speed and robot_stop == False :
				
				start_time = time.time()
				robot_stop = True

				dock_count     = 0
				doc_position_x = []
				doc_position_y = []
				doc_position_z = []

				print("robot stopped start taking docker data ----")

			if dock_count < max_count and robot_stop == True :
				diff_time = time.time() - start_time
				
				if diff_time > wait_time :
					print(" ###################### pattern not found ")
					docking_state_publisher.publish("unsuccessful_home")
					time.sleep(1)
					trigger = None
					os._exit(0)
			
			elif dock_count >= max_count and target_found == False and robot_stop == True:
				
				zone_publisher.publish(4)
				print("entered zone 4")
				
				doc_position_x.sort()
				doc_position_y.sort()
				doc_position_z.sort()

				start_index = int(len(doc_position_x)*0.25)
				end_index   = len(doc_position_x) - start_index

				fine_doc_position_x = doc_position_x[start_index:end_index]
				fine_doc_position_y = doc_position_y[start_index:end_index]
				fine_doc_position_z = doc_position_z[start_index:end_index]

				doc_x      = abs(sum(fine_doc_position_x)/len(fine_doc_position_x))      #meter
				doc_y      = (sum(fine_doc_position_y)/len(fine_doc_position_y))         #meter
				doc_th     = (sum(fine_doc_position_z)/len(fine_doc_position_z))         # deg
				doc_th_rad = (doc_th*pi/180)         				   	   	   # rad
				
				print("y_offset is ",y_offset)
				print("1st docker_pose",round(doc_x,3),round(doc_y,3),round(doc_th,2),round(doc_th_rad,2))
				dock_log_first = str(round(doc_x,3)) +" , "+ str(round(doc_y,3)) +"  ,"+ str(round(doc_th,2))
				change_angle_publisher.publish("True")				  
				target_x  = doc_x - distance_to_doc
				target_y  = doc_y + y_offset
				target_th = 0
								
				target_th = atan(target_y/target_x)
				target_th_deg = (target_th*180/math.pi)

				turning_th= ((pi/2 - doc_th_rad) - target_th)
				turning_th_deg = (turning_th*180/math.pi)
				
				first_turning_deg = turning_th_deg
				print("first_turning_deg",first_turning_deg,"target_th_deg",target_th_deg)
				
				distance_staright 	= sqrt(pow(target_x,2)+pow(target_y,2))
							
				target_found = True
				state 		 = "first_turning" 

			if state == "first_turning" and not active :
				trigger = "turning"
				active = True
				
				print("change_in_first_turning",first_turning_deg)
				
				# if first_turning_deg <= -0.85:
				# 	change_in_turning = first_turning_deg + angle_tolerance
				
				# elif -0.85 < first_turning_deg < -0.6 :
				# 	change_in_turning = -0.40

				# elif -0.6 < first_turning_deg < -0.25 :
				# 	change_in_turning = -0.30
				
				# elif abs(first_turning_deg) <= 0.25 :
				# 	change_in_turning = 0
				
				# elif 0.25 < first_turning_deg < 0.6 :
				# 	change_in_turning = 0.30
				 
				# elif 0.6 < first_turning_deg < 0.85 :
				# 	change_in_turning = 0.40

				# elif first_turning_deg >= 0.85:
				# 	change_in_turning = first_turning_deg - angle_tolerance

				change_in_turning = first_turning_deg

				print("change_in_first_turning",change_in_turning)

				if change_in_turning > 0:
					direction = 1
				elif change_in_turning < 0 :
					direction = -1

				change_in_position = abs(change_in_turning * (pi *base_width/360))
	
				initial_left_position  = 0
				initial_right_position = 0

				left_distance_travelled  = 0
				right_distance_travelled = 0
				
				change_in_left  = -1 * direction * change_in_position
				change_in_right = direction * change_in_position

				final_left_position  = (initial_left_position - change_in_left)* ticks_per_meter   #in ticks
				final_right_position = (initial_right_position + change_in_right)* ticks_per_meter   #in ticks

				kp = 1.0;ki = 0.000
				prev_pid_time = self.get_clock().now()
				integral = 0.0
				previous_error = 0.0
				
				left_stop = False
				right_stop = False
				
				initial_accel_dist = (initial_accel_dist_per/100.0)*abs(change_in_position)
				max_vel = 0.0

			elif state == "last_turning" and not active and robot_stop == True and dock_count >= max_count :
				trigger = "turning"
				active = True
				
				doc_x  = abs(sum(doc_position_x)/len(doc_position_x))      #meter
				doc_y  = (sum(doc_position_y)/len(doc_position_y))         #meter
				doc_th = (sum(doc_position_z)/len(doc_position_z))         # deg
				
				print("second docker_pose",round(doc_x,3),round(doc_y,3),round(doc_th,2))

				last_turning_deg =  90 - doc_th   
				print("change_in_fine_turning",last_turning_deg)
				dock_log_fine = str(round(doc_x,3)) +" , "+ str(round(doc_y,3)) +"  ,"+ str(round(doc_th,2))
				
				# if last_turning_deg <= -0.85:
				# 	change_in_turning = last_turning_deg + angle_tolerance
				
				# elif -0.85 < last_turning_deg < -0.6 :
				# 	change_in_turning = -0.40

				# elif -0.6 < last_turning_deg < -0.25 :
				# 	change_in_turning = -0.30
				
				# elif abs(last_turning_deg) <= 0.25 :
				# 	change_in_turning = 0
				
				# elif 0.25 < last_turning_deg < 0.6 :
				# 	change_in_turning = 0.30
				 
				# elif 0.6 < last_turning_deg < 0.85 :
				# 	change_in_turning = 0.40

				# elif last_turning_deg >= 0.85:
				# 	change_in_turning = last_turning_deg - angle_tolerance

				change_in_turning = last_turning_deg
				print("change_in_last_turning",change_in_turning)
				
				if change_in_turning > 0:
					direction = 1
				elif change_in_turning < 0 :
					direction = -1

				change_in_position = abs(change_in_turning * (pi *base_width/360))
	
				initial_left_position  = 0
				initial_right_position = 0

				left_distance_travelled  = 0
				right_distance_travelled = 0
				
				change_in_left  = -1 * direction * change_in_position
				change_in_right = direction * change_in_position

				final_left_position  = (initial_left_position - change_in_left)* ticks_per_meter   #in ticks
				final_right_position = (initial_right_position + change_in_right)* ticks_per_meter   #in ticks

				kp = 1.0;ki = 0.000
				prev_pid_time = self.get_clock().now()
				integral = 0.0
				previous_error = 0.0
				
				left_stop = False
				right_stop = False
				
				initial_accel_dist = (initial_accel_dist_per/100.0)*abs(change_in_position)
				max_vel = 0.0
				min_wheel_vel = 0.01

			elif state == "straight_moving" and not active:
				trigger = "straight" 
				active = True
				
				change_in_position  = distance_staright
				print("change_in_distance ",change_in_position)
				
				initial_left_position  = 0
				initial_right_position = 0

				left_distance_travelled  = 0
				right_distance_travelled = 0

				final_left_position  = (initial_left_position  - change_in_position) * ticks_per_meter   #in ticks
				final_right_position = (initial_right_position + change_in_position) * ticks_per_meter	 #in ticks
				print("final_left_position",final_left_position,"final_right_position",final_right_position)

				kp = 1.0;ki = 0.000
				prev_pid_time = self.get_clock().now()
				integral = 0.0
				previous_error = 0.0
				left_stop = False
				right_stop = False

				initial_accel_dist = (initial_accel_dist_per/100.0)*abs(change_in_position)
				max_vel = 0.0
			
			elif state == "second_straight_moving" and not active:
			
				trigger = "straight" 
				active = True
				
				change_in_position  = dist_straight
				print("in second straight moving change_in_distance ",change_in_position)
				
				initial_left_position  = 0
				initial_right_position = 0

				left_distance_travelled  = 0
				right_distance_travelled = 0

				final_left_position  = (initial_left_position  - change_in_position) * ticks_per_meter   #in ticks
				final_right_position = (initial_right_position + change_in_position) * ticks_per_meter	 #in ticks
				print("final_left_position",final_left_position,"final_right_position",final_right_position)

				kp = 1.0;ki = 0.000
				prev_pid_time = self.get_clock().now()
				integral = 0.0
				previous_error = 0.0
				left_stop = False
				right_stop = False

				initial_accel_dist = (initial_accel_dist_per/100.0)*abs(change_in_position)
				max_vel = 0.0
				min_wheel_vel = 0.03
			
			elif state == "last_data" and robot_stop == True and dock_count >= max_count :

				state  = None
				doc_x  = abs(sum(doc_position_x)/len(doc_position_x))      #meter
				doc_y  = (sum(doc_position_y)/len(doc_position_y))         #meter
				doc_th = (sum(doc_position_z)/len(doc_position_z))         # deg				
				dock_log_last = str(round(doc_x,3)) +" , "+ str(round(doc_y,3)) +"  ,"+ str(round(doc_th,2))
				print("last dock position ",dock_log_last)

				# dock_log= dock_log_first  + " , " +dock_log_last+ " , " + str(round(actual_change_in_turning,2))+ " , "+ str(round(first_turning_final_diff,2))
				dock_log= dock_log_first  + " , " + dock_log_fine +" , " + dock_log_last+ " , " + str(round(first_turning_deg,2))+ " , " + str(round(distance_staright,3))+ " , " +str(round(last_turning_deg,2))
				docking_state_publisher.publish("successful_dock")
				change_angle_publisher.publish("False")  
				
				zone_publisher.publish(1)
				print("brake after docking , entered zone 1")

				docking_log_publisher.publish(dock_log)
				docking_command = "False"
				time.sleep(1)
				os._exit(0)

			if trigger == "turning":

				pid_dt_duration = self.get_clock().now() - prev_pid_time
				pid_dt = pid_dt_duration.to_sec()
				prev_pid_time = self.get_clock().now()

				left_distance_travelled  = left_distance_travelled  - left_increment
				right_distance_travelled = right_distance_travelled + right_increment

				# print("left_distance_travelled",left_distance_travelled,"right_distance_travelled",right_distance_travelled)

				left_error  	= (final_left_position-left_distance_travelled)/ ticks_per_meter 	 #in meter
				right_error 	= (final_right_position-right_distance_travelled)/ ticks_per_meter 	 #in meter
				
				if abs(left_error) > initial_accel_dist:
					max_vel = max_vel + accel_step
				else:
					max_vel = max_turn_wheel_vel
				
				if abs(right_error) > initial_accel_dist:
					max_vel = max_vel + accel_step
				else:
					max_vel = max_turn_wheel_vel

				if left_stop == False:
					vel_msg.linear.x    =   (left_error*kp)
					vel_msg.linear.x    = clamp_velocity(vel_msg.linear.x,min_wheel_vel,max_vel)
					vel_msg.linear.x    = clamp_velocity(vel_msg.linear.x,min_wheel_vel,max_turn_wheel_vel)

				if right_stop == False:
					vel_msg.angular.z   =   (right_error*kp)
					vel_msg.angular.z   = clamp_velocity(vel_msg.angular.z,min_wheel_vel,max_vel)
					vel_msg.angular.z   = clamp_velocity(vel_msg.angular.z,min_wheel_vel,max_turn_wheel_vel)
				
				diff_kp 	= 3.0
				diff_error  = abs(abs(left_error)-abs(right_error))
				diff_addup  = abs(diff_error*diff_kp)
				# diff_addup    =   min_wheel_vel/2
				
				if abs(diff_error)> diff_dist:
					if abs(left_error)<abs(right_error):
						vel_msg.linear.x = add_offset(vel_msg.linear.x,-diff_addup)
						vel_msg.angular.z = add_offset(vel_msg.angular.z,diff_addup)
				
					elif abs(left_error)>abs(right_error):
						vel_msg.linear.x = add_offset(vel_msg.linear.x,diff_addup)
						vel_msg.angular.z = add_offset(vel_msg.angular.z,-diff_addup)							
				
				if left_stop == False:
					vel_msg.linear.x    = clamp_velocity(vel_msg.linear.x,min_wheel_vel/2,max_turn_wheel_vel)

				if right_stop == False:
					vel_msg.angular.z   = clamp_velocity(vel_msg.angular.z,min_wheel_vel/2,max_turn_wheel_vel)
			
				if  abs(left_error) <= dist_break:				
					vel_msg.linear.x    = 0
					left_stop = True

				if abs(right_error) <= dist_break:					
					vel_msg.angular.z   = 0
					right_stop = True

				if left_stop == True and right_stop == True:					
					left_stop = False
					right_stop = False
					turning = False
					velocity_publisher.publish(vel_msg)

					trigger = None
					active = False
					time.sleep(0.5)
					# print(" left_error ",left_error/ticks_per_meter,"right_error",right_error/ticks_per_meter)								
					
					if state == "first_turning" :  
						state = "straight_moving" 

					elif state == "last_turning" :  
						state = "second_straight_moving"
						# os._exit(0)
						
						# state  = "last_data"
						# robot_stop = False	
				
			elif trigger == "straight" :

				pid_dt_duration = self.get_clock().now() - prev_pid_time
				pid_dt = pid_dt_duration.to_sec()
				prev_pid_time = self.get_clock().now()

				left_distance_travelled  = left_distance_travelled  - left_increment
				right_distance_travelled = right_distance_travelled + right_increment

				# print("left_distance_travelled",left_distance_travelled,"right_distance_travelled",right_distance_travelled)

				left_error  	= (final_left_position-left_distance_travelled)/ ticks_per_meter 	 #in meter
				right_error 	= (final_right_position-right_distance_travelled)/ticks_per_meter	 #in meter
				
				if abs(left_error) > initial_accel_dist:
					max_vel = max_vel + accel_step
				else:
					max_vel = max_move_wheel_vel
				
				if abs(right_error) > initial_accel_dist:
					max_vel = max_vel + accel_step
				else:
					max_vel = max_move_wheel_vel

				if left_stop == False:
					vel_msg.linear.x    = (left_error*kp)
					vel_msg.linear.x    = clamp_velocity(vel_msg.linear.x,min_wheel_vel,max_vel)
					vel_msg.linear.x    = clamp_velocity(vel_msg.linear.x,min_wheel_vel,max_move_wheel_vel)

				if right_stop == False:
					vel_msg.angular.z   = (right_error*kp)
					vel_msg.angular.z   = clamp_velocity(vel_msg.angular.z,min_wheel_vel,max_vel)
					vel_msg.angular.z   = clamp_velocity(vel_msg.angular.z,min_wheel_vel,max_move_wheel_vel)
				
				diff_kp 	= 1.5
				diff_error  = abs(left_error)-abs(right_error)
				diff_addup  = abs(diff_error*diff_kp)
				# diff_addup    =   min_wheel_vel/2	
					
				if abs(diff_error) > diff_dist:
					if abs(left_error)<abs(right_error):
						vel_msg.linear.x = add_offset(vel_msg.linear.x,-diff_addup)
						vel_msg.angular.z = add_offset(vel_msg.angular.z,diff_addup)
					
					elif abs(left_error)>abs(right_error):
						vel_msg.linear.x = add_offset(vel_msg.linear.x,diff_addup)
						vel_msg.angular.z = add_offset(vel_msg.angular.z,-diff_addup)						

					# print("difference in distance",round(abs(abs(left_error)-abs(right_error)),4),"velocity comm",round(vel_msg.linear.x,4),round(vel_msg.angular.z,4))

				if left_stop == False:
					vel_msg.linear.x    = clamp_velocity(vel_msg.linear.x,min_wheel_vel/2,max_move_wheel_vel)

				if right_stop == False:
					vel_msg.angular.z   = clamp_velocity(vel_msg.angular.z,min_wheel_vel/2,max_move_wheel_vel)
			
				if  abs(left_error) <= dist_break:
					
					vel_msg.linear.x    = 0
					left_stop = True

				if abs(right_error) <= dist_break:
					
					vel_msg.angular.z   = 0
					right_stop = True

				if left_stop == True and right_stop == True:
					
					velocity_publisher.publish(vel_msg)
					left_stop 	= False
					right_stop 	= False
					robot_stop  = False	
					trigger 	= None
					active 		= False  
					max_count 	= 10
					

					if state == "straight_moving" :  
						state = "last_turning"  

					elif state == "second_straight_moving" :  
						state  = "last_data"
						robot_stop = False	
					
					time.sleep(0.5)
					# os._exit(0)

			velocity_publisher.publish(vel_msg)
				# Timer callback handles the rate automatically
			pass


def main(args=None):
	rclpy.init(args=args)
	node = TicksBasedDockingPatternWrap()
	try:
		rclpy.spin(node)
	except KeyboardInterrupt:
		pass
	finally:
		node.destroy_node()
		rclpy.shutdown()

if __name__ == '__main__':
	main()