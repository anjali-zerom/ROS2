#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from lifecycle_msgs.srv import ChangeState, GetState
from lifecycle_msgs.msg import Transition
import time

class LifecycleActivator(Node):
    def __init__(self):
        super().__init__('lifecycle_activator')
        self.get_logger().info('Lifecycle Activator started')
        
        # Wait longer for lifecycle managers to do their job first
        self.get_logger().info('Waiting 10 seconds for lifecycle managers to auto-activate nodes...')
        time.sleep(10.0)
        
        # List of all Nav2 lifecycle nodes to check/activate
        localization_nodes = [
            '/map_server',
            '/amcl'
        ]
        
        navigation_nodes = [
            '/controller_server',
            '/planner_server', 
            '/behavior_server',
            '/bt_navigator',
            '/waypoint_follower'
        ]
        
        # Check and activate localization nodes if needed
        self.get_logger().info('=== Checking Localization Nodes ===')
        for node_name in localization_nodes:
            self.check_and_activate(node_name)
        
        # Wait a bit between groups
        time.sleep(2.0)
        
        # Check and activate navigation nodes if needed
        self.get_logger().info('=== Checking Navigation Nodes ===')
        for node_name in navigation_nodes:
            self.check_and_activate(node_name)
        
        self.get_logger().info('=== Lifecycle check complete! ===')
        
    def get_state(self, node_name):
        """Get current state of a lifecycle node"""
        client = self.create_client(GetState, f'{node_name}/get_state')
        
        if not client.wait_for_service(timeout_sec=5.0):
            self.get_logger().warn(f'Service {node_name}/get_state not available')
            return None
            
        request = GetState.Request()
        future = client.call_async(request)
        rclpy.spin_until_future_complete(self, future, timeout_sec=5.0)
        
        if future.result() is not None:
            return future.result().current_state.id
        return None
    
    def change_state(self, node_name, transition_id):
        """Change state of a lifecycle node"""
        client = self.create_client(ChangeState, f'{node_name}/change_state')
        
        if not client.wait_for_service(timeout_sec=5.0):
            self.get_logger().warn(f'Service {node_name}/change_state not available')
            return False
            
        request = ChangeState.Request()
        request.transition = Transition()
        request.transition.id = transition_id
        
        future = client.call_async(request)
        rclpy.spin_until_future_complete(self, future, timeout_sec=5.0)
        
        if future.result() is not None:
            return future.result().success
        return False
    
    def check_and_activate(self, node_name):
        """Check node state and activate if not already active"""
        current_state = self.get_state(node_name)
        
        state_names = {
            0: 'UNKNOWN',
            1: 'UNCONFIGURED',
            2: 'INACTIVE',
            3: 'ACTIVE',
            4: 'FINALIZED'
        }
        
        state_name = state_names.get(current_state, 'UNKNOWN')
        self.get_logger().info(f'{node_name}: {state_name}')
        
        if current_state == 3:  # Already active
            self.get_logger().info(f'  ✓ {node_name} already active')
            return True
        
        if current_state == 1:  # Unconfigured - need to configure first
            self.get_logger().info(f'  Configuring {node_name}...')
            if self.change_state(node_name, Transition.TRANSITION_CONFIGURE):
                self.get_logger().info(f'  ✓ Configured')
                time.sleep(0.5)
                current_state = 2  # Now inactive
            else:
                self.get_logger().error(f'  ✗ Failed to configure')
                return False
        
        if current_state == 2:  # Inactive - need to activate
            self.get_logger().info(f'  Activating {node_name}...')
            if self.change_state(node_name, Transition.TRANSITION_ACTIVATE):
                self.get_logger().info(f'  ✓ Activated')
                return True
            else:
                self.get_logger().error(f'  ✗ Failed to activate')
                return False
        
        return False

def main(args=None):
    rclpy.init(args=args)
    activator = LifecycleActivator()
    
    try:
        rclpy.spin(activator)
    except KeyboardInterrupt:
        pass
    
    activator.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
