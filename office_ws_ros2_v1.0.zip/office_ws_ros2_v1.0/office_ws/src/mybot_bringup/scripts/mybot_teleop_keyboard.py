#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from geometry_msgs.msg import Twist
import sys
import select
import termios
import tty

class TurtleBotTeleop(Node):
    def __init__(self):
        super().__init__('mybot_teleop')
        
        # QoS Profile for low latency communication 
        qos_profile_best_effort = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        # Check if stdin is a TTY
        if not sys.stdin.isatty():
            self.get_logger().error('This node requires a TTY. Please run with: ros2 run mybot_bringup mybot_teleop_keyboard.py')
            raise RuntimeError('No TTY available')
        
        # ROS 2 Publisher
        self.pub = self.create_publisher(Twist, 'cmd_keyboard', qos_profile_best_effort)

        # Initial State
        self.settings = termios.tcgetattr(sys.stdin)
        self.speed = 0.5
        self.turn = 0.5
        self.status = 0
        
        self.msg = """
Control Your Turtlebot! (ROS 2 Version)
---------------------------
Moving around:
   u    i    o
   j    k    l
   m    ,    .

q/z : increase/decrease max speeds by 10%
w/x : increase/decrease only linear speed by 10%
e/c : increase/decrease only angular speed by 10%
space key, k : force stop
anything else : stop smoothly

CTRL-C to quit
"""
        self.moveBindings = {
            'i': (1, 0), 'o': (1, -1), 'j': (0, 1),
            'l': (0, -1), 'u': (1, 1), ',': (-1, 0),
            '.': (-1, 1), 'm': (-1, -1),
        }

        self.speedBindings = {
            'q': (1.1, 1.1), 'z': (0.9, 0.9), 'w': (1.1, 1),
            'x': (0.9, 1), 'e': (1, 1.1), 'c': (1, 0.9),
        }

    def get_key(self):
        tty.setraw(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
        if rlist:
            key = sys.stdin.read(1)
        else:
            key = ''
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
        return key

    def format_vels(self):
        return f"currently:\tspeed {self.speed:.2f}\tturn {self.turn:.2f}"

    def run(self):
        x = 0
        th = 0
        count = 0
        control_speed = 0.0
        control_turn = 0.0

        try:
            print(self.msg)
            print(self.format_vels())

            while rclpy.ok():
                key = self.get_key()

                if key in self.moveBindings.keys():
                    x = self.moveBindings[key][0]
                    th = self.moveBindings[key][1]
                    count = 0
                elif key in self.speedBindings.keys():
                    self.speed *= self.speedBindings[key][0]
                    self.turn *= self.speedBindings[key][1]
                    count = 0
                    print(self.format_vels())
                    if self.status == 14:
                        print(self.msg)
                    self.status = (self.status + 1) % 15
                elif key == ' ' or key == 'k':
                    x = 0
                    th = 0
                    control_speed = 0.0
                    control_turn = 0.0
                else:
                    count += 1
                    if count > 4:
                        x = 0
                        th = 0
                    if key == '\x03':  # CTRL-C
                        break

                target_speed = self.speed * x
                target_turn = self.turn * th

                # Ramping logic
                if target_speed > control_speed:
                    control_speed = min(target_speed, control_speed + 0.02)
                elif target_speed < control_speed:
                    control_speed = max(target_speed, control_speed - 0.02)
                else:
                    control_speed = target_speed

                if target_turn > control_turn:
                    control_turn = min(target_turn, control_turn + 0.05)
                elif target_turn < control_turn:
                    control_turn = max(target_turn, control_turn - 0.05)
                else:
                    control_turn = target_turn

                # Publish
                twist = Twist()
                twist.linear.x = float(control_speed)
                twist.angular.z = float(control_turn)
                self.pub.publish(twist)

        except Exception as e:
            print(e)

        finally:
            # Stop robot on shutdown
            twist = Twist()
            twist.linear.x = 0.0
            twist.angular.z = 0.0
            self.pub.publish(twist)
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)

def main(args=None):
    rclpy.init(args=args)
    node = TurtleBotTeleop()
    node.run()
    rclpy.shutdown()

if __name__ == '__main__':
    main()