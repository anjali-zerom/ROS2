#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import os
import time
import subprocess
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Int16, Bool, Float32
from geometry_msgs.msg import Twist

class SafetyEmergencyNode(Node):
    def __init__(self):
        super().__init__('hardware_emergency')
        
        self.get_logger().info("emergency node running...")
        
        # Initialize variables
        self.my_status_s = None
        self.safety_trigger = 0
        self.safety = False
        self.release = False
        self.mygoal = None
        self.right_speed = 0.0
        self.left_speed = 0.0
        self.stop_vel = 0.001
        self.count = 0
        self.init = False
        self.pub_zero = False
        
        # Create subscribers
        self.goal_sub = self.create_subscription(
            PoseStamped,
            "/goal_pose",
            self.receive_goal_callback,
            10
        )
        
        self.safety_clear_sub = self.create_subscription(
            Int16,
            "/safety_clear",
            self.safety_clear_callback,
            10
        )
        
        self.left_speed_sub = self.create_subscription(
            Float32,
            '/moons_left_speed',
            self.left_callback,
            10
        )
        
        self.right_speed_sub = self.create_subscription(
            Float32,
            '/moons_right_speed',
            self.right_callback,
            10
        )
        
        # Create publishers
        self.pub_pause = self.create_publisher(
            Bool,
            '/pause_navigation',
            10
        )
        
        self.pub_emer_stop = self.create_publisher(
            Twist,
            '~/cmd_vel_mux/input/keyboard',
            5
        )
        
        # Initialize emergency stop message
        self.twist_emer_stop = Twist()
        self.twist_emer_stop.linear.x = 0.0
        self.twist_emer_stop.linear.y = 0.0
        self.twist_emer_stop.linear.z = 0.0
        self.twist_emer_stop.angular.x = 0.0
        self.twist_emer_stop.angular.y = 0.0
        self.twist_emer_stop.angular.z = 0.0
        
        # Create timer for 20 Hz operation
        self.timer = self.create_timer(0.05, self.timer_callback)  # 20 Hz = 0.05s
        
    def receive_goal_callback(self, data):
        self.mygoal = data
        
    def left_callback(self, data):
        self.left_speed = data.data
        
    def right_callback(self, data):
        self.right_speed = data.data
        
    def safety_clear_callback(self, data):
        safety_trigger = data.data
        
        if safety_trigger == 1 and not self.safety:
            self.safety = True
            
        if safety_trigger == 0 and self.safety:
            self.safety = False
            
    def clear_costmaps(self):
        """Clear costmaps using ROS2 service call"""
        try:
            subprocess.run([
                'ros2', 'service', 'call', '/global_costmap/clear_entirely_global_costmap',
                'nav2_msgs/srv/ClearEntireCostmap', '{}'
            ], check=True, capture_output=True)
        except subprocess.CalledProcessError:
            self.get_logger().warn("Failed to clear costmaps")
            
    def timer_callback(self):
        self.count += 1
        
        if self.count > 400 and not self.init:
            self.init = True
            self.count = 0
            
        if self.count > 450 and self.init:
            self.count = 450
            
        if (self.count > 100 and self.init and 
            abs(self.left_speed) < self.stop_vel and abs(self.right_speed) < self.stop_vel):
            self.clear_costmaps()
            self.count = 0
            self.get_logger().info("clear")
            
        if not self.safety and self.release:
            self.get_logger().error("safety triggered")
            self.release = False
            pause_msg = Bool()
            pause_msg.data = True
            self.pub_pause.publish(pause_msg)
            self.pub_zero = True
            
        if self.safety and not self.release and self.mygoal is not None:
            self.clear_costmaps()
            self.get_logger().warn("safety released")
            self.release = True
            self.pub_zero = False
            
            pause_msg = Bool()
            pause_msg.data = False
            self.pub_pause.publish(pause_msg)
            
        if self.pub_zero:
            self.pub_emer_stop.publish(self.twist_emer_stop)

def main(args=None):
    rclpy.init(args=args)
    
    safety_emergency_node = SafetyEmergencyNode()
    
    try:
        rclpy.spin(safety_emergency_node)
    except KeyboardInterrupt:
        pass
    finally:
        safety_emergency_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
