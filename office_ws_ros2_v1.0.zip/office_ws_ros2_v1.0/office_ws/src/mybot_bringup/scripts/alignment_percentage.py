#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseWithCovarianceStamped
from std_msgs.msg import Float32
import numpy as np

class AlignmentMonitorNode(Node):
    def __init__(self):
        super().__init__('alignment_monitor')
        
        self.get_logger().info('alignment_monitor node running...')
        
        self.alignment_score = -1.0
        
        # Create subscriber
        self.pose_sub = self.create_subscription(
            PoseWithCovarianceStamped,
            '/amcl_pose',
            self.pose_callback,
            10
        )
        
        # Create publisher
        self.pub_alignment = self.create_publisher(
            Float32,
            '/alignment_score',
            10
        )
        
        # Create timer for 20 Hz operation
        self.timer = self.create_timer(0.05, self.timer_callback)  # 20 Hz = 0.05s
        
    def pose_callback(self, msg):
        cov = msg.pose.covariance
        var_x = cov[0]
        var_y = cov[7]
        var_yaw = cov[35]

        # Adjusted thresholds for typical AMCL setups
        max_var = 0.05  # 5cm^2 for position
        max_var_yaw = 0.01  # ~5.7 degrees^2 for yaw

        # Compute alignment score with a softer penalty
        pos_score = min(1.0, max_var / max(var_x, var_y, 1e-6))  # Avoid division by zero
        yaw_score = min(1.0, max_var_yaw / max(var_yaw, 1e-6))
        self.alignment_score = pos_score * yaw_score * 100

    def timer_callback(self):
        if self.alignment_score >= 0.0:
            msg = Float32()
            msg.data = self.alignment_score
            self.pub_alignment.publish(msg)
            self.alignment_score = -1.0

def main(args=None):
    rclpy.init(args=args)
    
    alignment_node = AlignmentMonitorNode()
    
    try:
        rclpy.spin(alignment_node)
    except KeyboardInterrupt:
        pass
    finally:
        alignment_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()


