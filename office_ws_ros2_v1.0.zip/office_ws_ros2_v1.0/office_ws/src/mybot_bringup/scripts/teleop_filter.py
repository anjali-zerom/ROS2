#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from geometry_msgs.msg import Twist

class TeleopFilterNode(Node):
    def __init__(self):
        super().__init__('teleop_filter')
        
        # QoS Profile for low latency communication (matching ticks_based_move_wrap.py)
        qos_profile_best_effort = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        self.get_logger().info("Teleop filter Running...")
        
        # Initialize state variables
        self.control_speed = 0.0
        self.control_turn = 0.0
        self.max_linear_vel = 1.5
        self.max_angular_vel = 0.5
        self.flag = "publish_zero"
        self.check_command = 0
        
        # Create subscribers
        self.teleop_sub = self.create_subscription(
            Twist,
            'cmd_twist_teleop',
            self.teleop_callback,
            qos_profile_best_effort
        )
        
        self.wheel_vel_sub = self.create_subscription(
            Twist,
            'cmd_vel',
            self.wheel_vel_callback,
            qos_profile_best_effort
        )
        
        self.speed_limit_sub = self.create_subscription(
            Twist,
            'speed_limit',
            self.speed_limit_callback,
            qos_profile_best_effort
        )
        
        # Create publisher
        self.pub = self.create_publisher(
            Twist,
            'cmd_teleop_filter',
            qos_profile_best_effort
        )
        
        # Create timer for 20 Hz operation
        self.timer = self.create_timer(0.05, self.timer_callback)  # 20 Hz = 0.05s
        
    def teleop_callback(self, msg):
        self.control_speed = msg.linear.x
        self.control_turn = msg.angular.z
        self.flag = "publish_teleop"
        self.check_command = 35
        
    def wheel_vel_callback(self, msg):
        # NOTE: This callback was blocking navigation commands.
        # The original logic set flag="publish_nothing" when cmd_vel had data,
        # but since twist_to_motors publishes to cmd_vel, it created a deadlock.
        # Now we just ignore this callback for navigation to work.
        pass
            
    def speed_limit_callback(self, data):
        self.max_linear_vel = data.linear.x
        self.max_angular_vel = data.angular.z
        
    def timer_callback(self):
        if self.flag == "publish_teleop":
            # Apply speed limits
            if self.control_speed < 0:
                self.control_speed = max(self.control_speed, -1 * self.max_linear_vel)
            elif self.control_speed > 0:
                self.control_speed = min(self.control_speed, 1 * self.max_linear_vel)
            
            if self.control_turn < 0:
                self.control_turn = max(self.control_turn, -1 * self.max_angular_vel)
            elif self.control_turn > 0:
                self.control_turn = min(self.control_turn, 1 * self.max_angular_vel)

            twist = Twist()
            twist.linear.x = self.control_speed
            twist.linear.y = 0.0
            twist.linear.z = 0.0
            twist.angular.x = 0.0
            twist.angular.y = 0.0
            twist.angular.z = self.control_turn
            self.pub.publish(twist)
            self.flag = "publish_zero"

        elif self.flag == "publish_zero":
            if self.check_command > 0:
                self.check_command = self.check_command - 1
            
            if self.check_command <= 0:
                twist = Twist()
                twist.linear.x = 0.0
                twist.linear.y = 0.0
                twist.linear.z = 0.0
                twist.angular.x = 0.0
                twist.angular.y = 0.0
                twist.angular.z = 0.0
                self.pub.publish(twist)
                
            self.flag = "publish_zero"

        elif self.flag == "publish_nothing":
            self.flag = "publish_zero"

def main(args=None):
    rclpy.init(args=args)
    
    teleop_filter_node = TeleopFilterNode()
    
    try:
        rclpy.spin(teleop_filter_node)
    except KeyboardInterrupt:
        pass
    finally:
        teleop_filter_node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()



