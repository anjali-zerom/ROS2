#!/usr/bin/env python3

import json
import csv
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseWithCovarianceStamped, PoseStamped, Pose
from std_msgs.msg import Header, String, Int16, Float32
import time
import os

class InitialPoseNode(Node):
    def __init__(self):
        super().__init__('set_initial_pose')
        
        self.get_logger().info('set_initial_pose node running...')
        
        # Initialize variables
        self.name_station = None
        self.pushed = 0
        self.robot_pose = Pose()
        self.alignment_score = -1.0
        self.reverse_complete = None
        self.init = False
        self.init_reverse = False
        self.newstation = False
        self.reverse = False
        self.config = None
        
        # Create publishers
        self.pub_initialpose = self.create_publisher(
            PoseWithCovarianceStamped,
            '/initialpose',
            1
        )
        
        self.pub_reverse_dist = self.create_publisher(
            Float32,
            '/reverse_dist',
            10
        )
        
        self.pub_localization = self.create_publisher(
            String,
            '/localization_status',
            10
        )
        
        # Create subscribers
        self.button_sub = self.create_subscription(
            Int16,
            'shutdown_button_pushed',
            self.button_pushed_callback,
            10
        )
        
        self.station_sub = self.create_subscription(
            String,
            '/station',
            self.station_pose_callback,
            10
        )
        
        self.pose_sub = self.create_subscription(
            PoseStamped,
            '/pose',
            self.my_pose_callback,
            10
        )
        
        self.alignment_sub = self.create_subscription(
            Float32,
            '/alignment_score',
            self.alignment_callback,
            10
        )
        
        self.reverse_sub = self.create_subscription(
            String,
            '/reverse_complete',
            self.reverse_callback,
            10
        )
        
        # File paths
        self.json_file = '/home/fleet-wipro/office_ws/src/mybot_bringup/config/stations.json'
        self.csv_file = '/home/fleet-wipro/office_ws/src/mybot_bringup/config/lastpose.csv'
        
        # Load initial pose and publish it
        self.load_and_publish_initial_pose()
        
        # Create timer for 20 Hz operation
        self.timer = self.create_timer(0.05, self.timer_callback)  # 20 Hz = 0.05s
        
    def load_station_pose_from_csv(self, csv_file):
        try:
            with open(csv_file, 'r') as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                if not rows:
                    raise ValueError(f"No stations found in {csv_file}")
                # Try the second row (index 1), fall back to first row if only one exists
                station_data = rows[1] if len(rows) > 1 else rows[0]
                return {
                    'x': float(station_data['position_x']),
                    'y': float(station_data['position_y']),
                    'z': float(station_data['position_z'])
                }, {
                    'x': float(station_data['orientation_x']),
                    'y': float(station_data['orientation_y']),
                    'z': float(station_data['orientation_z']),
                    'w': float(station_data['orientation_w'])
                }
        except Exception as e:
            raise ValueError(f"Error loading CSV: {str(e)}")

    def load_station_pose(self, json_file, station_name):
        with open(json_file, 'r') as f:
            data = json.load(f)
        
        if 'stations' not in data or station_name not in data['stations']:
            raise ValueError(f"Station '{station_name}' not found in {json_file}")
        
        station = data['stations'][station_name]
        return station['position'], station['orientation'], station['config']

    def station_pose_callback(self, data):
        self.name_station = data.data

    def button_pushed_callback(self, data):
        self.pushed = data.data

    def my_pose_callback(self, data):
        self.robot_pose = data.pose

    def alignment_callback(self, data):
        self.alignment_score = data.data

    def reverse_callback(self, data):
        self.reverse_complete = data.data
        
    def load_and_publish_initial_pose(self):
        # Try to load initial pose from CSV
        try:
            position, orientation = self.load_station_pose_from_csv(self.csv_file)
        except Exception as e:
            self.get_logger().error(f"Error loading CSV: {str(e)}")
            # Write default pose to CSV if loading fails
            default_data = [['station', 'position_x', 'position_y', 'position_z', 
                             'orientation_x', 'orientation_y', 'orientation_z', 'orientation_w'],
                            ['last_pose', 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0]]
            try:
                os.makedirs(os.path.dirname(self.csv_file), exist_ok=True)
                with open(self.csv_file, 'w') as file:
                    writer = csv.writer(file)
                    writer.writerows(default_data)
                position, orientation = self.load_station_pose_from_csv(self.csv_file)
            except Exception as e:
                self.get_logger().error(f"Error writing/reading default CSV: {str(e)}")
                return

        msg = PoseWithCovarianceStamped()
        msg.header = Header()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'map'

        msg.pose.pose.position.x = position['x']
        msg.pose.pose.position.y = position['y']
        msg.pose.pose.position.z = position['z']
        msg.pose.pose.orientation.x = orientation['x']
        msg.pose.pose.orientation.y = orientation['y']
        msg.pose.pose.orientation.z = orientation['z']
        msg.pose.pose.orientation.w = orientation['w']

        msg.pose.covariance = [0.25, 0.0, 0.0, 0.0, 0.0, 0.0,
                               0.0, 0.25, 0.0, 0.0, 0.0, 0.0,
                               0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                               0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                               0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                               0.0, 0.0, 0.0, 0.0, 0.0, 0.0685389190917633]

        # Wait a bit before publishing
        time.sleep(2)
        self.pub_initialpose.publish(msg)
        self.get_logger().info("Published initial pose from lastpose.csv to /initialpose topic")
        self.init = True
        self.init_reverse = True
        
    def timer_callback(self):
        if self.pushed == 200 or self.pushed == 100:  # 100 means manually saving current pose
            self.get_logger().info("shutdown pushed saving last pose")
            default_data = [['station', 'position_x', 'position_y', 'position_z', 
                             'orientation_x', 'orientation_y', 'orientation_z', 'orientation_w'],
                            ['last_pose', self.robot_pose.position.x, self.robot_pose.position.y, self.robot_pose.position.z, 
                            self.robot_pose.orientation.x, self.robot_pose.orientation.y, self.robot_pose.orientation.z, self.robot_pose.orientation.w]]
            self.pushed = 0
            try:
                with open(self.csv_file, 'w') as file:
                    writer = csv.writer(file)
                    writer.writerows(default_data)
            except Exception as e:
                self.get_logger().error(f"Error writing CSV: {str(e)}")

        if 0 < self.alignment_score < 95 and self.init_reverse:
            self.get_logger().info("reversing 0.1 meter")
            
            reverse_msg = Float32()
            reverse_msg.data = -0.1
            self.pub_reverse_dist.publish(reverse_msg)
            time.sleep(2)
            
            self.alignment_score = -1.0
            self.init_reverse = False
            self.reverse = True

        if self.name_station is not None:
            try:
                position, orientation, self.config = self.load_station_pose(self.json_file, self.name_station)
                msg = PoseWithCovarianceStamped()
                msg.header.stamp = self.get_clock().now().to_msg()
                msg.header.frame_id = 'map'

                msg.pose.pose.position.x = position['x']
                msg.pose.pose.position.y = position['y']
                msg.pose.pose.position.z = position['z']
                msg.pose.pose.orientation.x = orientation['x']
                msg.pose.pose.orientation.y = orientation['y']
                msg.pose.pose.orientation.z = orientation['z']
                msg.pose.pose.orientation.w = orientation['w']

                msg.pose.covariance = [0.25, 0.0, 0.0, 0.0, 0.0, 0.0,
                                       0.0, 0.25, 0.0, 0.0, 0.0, 0.0,
                                       0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                       0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                       0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                       0.0, 0.0, 0.0, 0.0, 0.0, 0.0685389190917633]

                self.pub_initialpose.publish(msg)
                self.get_logger().info(f"Published pose for station {self.name_station} to /initialpose")
                time.sleep(2)
                self.newstation = True
                self.name_station = None

            except Exception as e:
                self.get_logger().error(f"Error loading station {self.name_station}: {str(e)}")

        if 0 < self.alignment_score < 95 and self.newstation:
            self.get_logger().info("reversing as per station config")
            reverse_msg = Float32()
            if self.config and self.config['type'] == "conveyor":
                reverse_msg.data = self.config['reverse_dist']
            else:
                reverse_msg.data = -0.1
            self.pub_reverse_dist.publish(reverse_msg)

            time.sleep(2)
            self.newstation = False
            self.alignment_score = -1.0
            self.reverse = True

        if self.reverse and self.reverse_complete == "True":
            localization_msg = String()
            localization_msg.data = "complete"
            self.pub_localization.publish(localization_msg)
            self.get_logger().info("localized--------")
            self.reverse = False

def main(args=None):
    rclpy.init(args=args)
    
    initial_pose_node = InitialPoseNode()
    
    try:
        rclpy.spin(initial_pose_node)
    except KeyboardInterrupt:
        pass
    finally:
        initial_pose_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()