#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import subprocess
import os

class DockingInitializationNode(Node):
    def __init__(self):
        super().__init__('docking_initialization_node_started')
        
        self.get_logger().info("docking initialization node started")
        
        self.docking_sequence = None
        self.docking_state = None
        self.sequence_running = False
        self.line_pattern_process = None
        self.docking_process = None
        
        # Create subscribers
        self.docking_sequence_sub = self.create_subscription(
            String,
            "/docking_sequence_node",
            self.docking_sequence_callback,
            10
        )
        
        self.docking_state_sub = self.create_subscription(
            String,
            "/docking_state",
            self.docking_state_callback,
            10
        )
        
        # Create timer for 20 Hz operation
        self.timer = self.create_timer(0.05, self.timer_callback)  # 20 Hz = 0.05s
        
    def docking_sequence_callback(self, data):
        self.docking_sequence = data.data
        
    def docking_state_callback(self, data):
        self.docking_state = data.data
        
    def timer_callback(self):
        if (self.docking_sequence == "True" and not self.sequence_running):
            self.docking_sequence = None
            self.get_logger().info("launching line pattern position and docking file")
            
            # Launch line pattern position launch file
            try:
                self.line_pattern_process = subprocess.Popen([
                    'ros2', 'launch', 'mybot_bringup', 'line_pattern_position.launch.py'
                ])
                
                # Launch docking launch file
                self.docking_process = subprocess.Popen([
                    'ros2', 'launch', 'mybot_bringup', 'docking.launch.py'
                ])
                
                self.sequence_running = True
                
            except Exception as e:
                self.get_logger().error(f"Failed to launch processes: {str(e)}")

        elif (self.docking_state == "successful_dock" and self.sequence_running):
            self.docking_state = None
            self.get_logger().info("closing line pattern position and docking file")
            
            # Terminate launched processes
            if self.line_pattern_process:
                self.line_pattern_process.terminate()
                self.line_pattern_process = None
                
            if self.docking_process:
                self.docking_process.terminate()
                self.docking_process = None
                
            self.sequence_running = False

        else:
            self.docking_sequence = None
            self.docking_state = None

def main(args=None):
    rclpy.init(args=args)
    
    docking_init_node = DockingInitializationNode()
    
    try:
        rclpy.spin(docking_init_node)
    except KeyboardInterrupt:
        pass
    finally:
        # Clean up any running processes
        if docking_init_node.line_pattern_process:
            docking_init_node.line_pattern_process.terminate()
        if docking_init_node.docking_process:
            docking_init_node.docking_process.terminate()
            
        docking_init_node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()