#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from rcl_interfaces.srv import SetParameters
from rcl_interfaces.msg import Parameter, ParameterValue, ParameterType
import yaml
import os
import csv
from datetime import datetime
from std_msgs.msg import Bool, Float32, Int16
from sensor_msgs.msg import Imu, Temperature
from geometry_msgs.msg import Twist
import sys
import time

class IMUCalibrationNode(Node):
    def __init__(self):
        super().__init__('imu_calibration_node')
        
        # QoS Profile for low latency communication (matching ticks_based_move_wrap.py)
        qos_profile_best_effort = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )

        # Initialize variables
        self.required_samples = 40
        self.wheel_moved = False
        self.collecting_data = False
        self.front_zone_blocked = False
        self.last_temperature = -270.0  # deg celsius
        self.current_temperature = -270.0  # deg celsius
        self.left_speed_data = []
        self.right_speed_data = []
        self.yaw_data = []
        self.calibration_reason = "unknown"
        self.vz_offset = 0.0
        self.prev_time = time.time()
        
        # Declare parameters
        self.declare_parameter('stop_vel', 0.001)
        self.declare_parameter('temperature_variation', 1.0)
        self.declare_parameter('calibration_delay', 30)
        self.declare_parameter('normal_speed_linear', 1.5)
        self.declare_parameter('normal_speed_angular', 0.5)
        self.declare_parameter('rate', 20)
        
        # Get parameters
        self.stop_vel = self.get_parameter('stop_vel').get_parameter_value().double_value
        self.temperature_variation = self.get_parameter('temperature_variation').get_parameter_value().double_value
        self.calib_delay = self.get_parameter('calibration_delay').get_parameter_value().integer_value
        normal_speed_linear = self.get_parameter('normal_speed_linear').get_parameter_value().double_value
        normal_speed_angular = self.get_parameter('normal_speed_angular').get_parameter_value().double_value
        self.rate_hz = self.get_parameter('rate').get_parameter_value().integer_value
        
        # Set file paths
        home_dir = os.path.expanduser("~")
        config_dir = os.path.join(home_dir, "office_ws/src/mybot_bringup/config")
        log_dir = os.path.join(home_dir, "office_ws/src/mybot_bringup/log_data")
        self.yaml_file = os.path.join(config_dir, "imu.yaml")
        self.csv_file = os.path.join(log_dir, "imu_calibration_log.csv")
        
        # Ensure directories exist
        if not os.path.exists(config_dir):
            os.makedirs(config_dir)
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
            
        # Create speed messages
        self.normal_speed = Twist()
        self.normal_speed.linear.x = normal_speed_linear
        self.normal_speed.linear.y = 0.0
        self.normal_speed.linear.z = 0.0
        self.normal_speed.angular.x = 0.0
        self.normal_speed.angular.y = 0.0
        self.normal_speed.angular.z = normal_speed_angular
        
        self.stop_speed = Twist()
        self.stop_speed.linear.x = 0.0
        self.stop_speed.linear.y = 0.0
        self.stop_speed.linear.z = 0.0
        self.stop_speed.angular.x = 0.0
        self.stop_speed.angular.y = 0.0
        self.stop_speed.angular.z = 0.0
        
        # Create CSV file and load vz_offset
        self.create_csv_file()
        self.vz_offset = self.load_vz_offset()
        
        # Create subscribers
        self.create_subscription(Bool, "/do_caliberation", self.calibration_callback, qos_profile_best_effort)
        self.create_subscription(Float32, "/moons_left_speed", self.left_speed_callback, qos_profile_best_effort)
        self.create_subscription(Float32, "/moons_right_speed", self.right_speed_callback, qos_profile_best_effort)
        self.create_subscription(Imu, "/imu/imu_raw_uncalib", self.imu_callback, qos_profile_best_effort)
        self.create_subscription(Temperature, "/imu/temperature", self.imu_temp_callback, qos_profile_best_effort)
        self.create_subscription(Int16, "/front_zone_switch", self.front_zone_callback, qos_profile_best_effort)
        
        # Create publisher
        self.pub_speed_limit = self.create_publisher(Twist, "/speed_limit", qos_profile_best_effort)
        
        # Declare parameter for the target IMU node name (allows override from launch file)
        self.declare_parameter('imu_node_name', 'imu_serial')
        imu_node_name = self.get_parameter('imu_node_name').get_parameter_value().string_value
        
        # Create service client to update led_imu node's vz_offset parameter
        self.led_imu_param_client = self.create_client(
            SetParameters, 
            f'/{imu_node_name}/set_parameters'
        )
        self.get_logger().info(f"Will update vz_offset on node: /{imu_node_name}")
        
        # Create timer for main loop
        self.timer = self.create_timer(1.0 / self.rate_hz, self.main_loop)
        
        # Set vz_offset as parameter
        self.declare_parameter('vz_offset', self.vz_offset)
        self.set_parameters([rclpy.parameter.Parameter('vz_offset', rclpy.Parameter.Type.DOUBLE, self.vz_offset)])
        
        self.get_logger().info(f"Global vz_offset set: {self.vz_offset:.5f}")
        
        # Update led_imu node's parameter with loaded value (if it's running)
        self.update_led_imu_vz_offset(self.vz_offset)
        
        # Start initial calibration
        self.get_logger().info("Initial command, starting calibration...")
        self.calibration_reason = "auto"
        self.pub_speed_limit.publish(self.stop_speed)
        time.sleep(0.5)
        self.start_calibration()

    def load_vz_offset(self):
        if os.path.exists(self.yaml_file):
            with open(self.yaml_file, 'r') as file:
                params = yaml.safe_load(file) or {}
                loaded_vz_offset = params.get("vz_offset", 0.0)
                self.get_logger().info(f"Loaded vz_offset from file: {loaded_vz_offset:.5f}")
                return loaded_vz_offset
        return 0.0  # Default if file doesn't exist

    def save_vz_offset(self, vz_offset):
        if os.path.exists(self.yaml_file):
            with open(self.yaml_file, 'r') as file:
                params = yaml.safe_load(file) or {}  # Ensure it is a dict
        else:
            params = {}

        params["vz_offset"] = vz_offset

        with open(self.yaml_file, 'w') as file:
            yaml.dump(params, file, default_flow_style=False)

        self.get_logger().info(f"vz_offset saved to {self.yaml_file}")

    def update_led_imu_vz_offset(self, vz_offset):
        """Update vz_offset parameter on the led_imu_crc_node in real-time."""
        if not self.led_imu_param_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().warn("led_imu_crc_node parameter service not available, skipping real-time update")
            return False
        
        # Create parameter request
        request = SetParameters.Request()
        param = Parameter()
        param.name = 'vz_offset'
        param.value = ParameterValue()
        param.value.type = ParameterType.PARAMETER_DOUBLE
        param.value.double_value = vz_offset
        request.parameters = [param]
        
        # Call service asynchronously
        future = self.led_imu_param_client.call_async(request)
        future.add_done_callback(self._param_update_callback)
        return True
    
    def _param_update_callback(self, future):
        """Callback for parameter update service call."""
        try:
            response = future.result()
            if response.results[0].successful:
                self.get_logger().info("Successfully updated vz_offset on led_imu_crc_node")
            else:
                self.get_logger().warn(f"Failed to update vz_offset: {response.results[0].reason}")
        except Exception as e:
            self.get_logger().error(f"Parameter update service call failed: {str(e)}")

    def create_csv_file(self):
        if not os.path.exists(self.csv_file):
            with open(self.csv_file, 'w') as file:
                writer = csv.writer(file)
                writer.writerow(['Timestamp', 'VZ_Offset', 'Calibration_Reason', 'Temperature_C'])
            self.get_logger().info(f"Created CSV log file: {self.csv_file}")

    def log_calibration_to_csv(self, vz_offset, reason, temperature):
        try:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            with open(self.csv_file, 'a') as file:
                writer = csv.writer(file)
                writer.writerow([timestamp, f'{vz_offset:.5f}', reason, f'{temperature:.2f}'])
            self.get_logger().info(f"Logged calibration to CSV: {timestamp} | {vz_offset} | {reason} | {temperature:.2f}C")
        except Exception as e:
            self.get_logger().warn(f"Failed to log to CSV: {str(e)}")

    def calibration_callback(self, msg):
        if msg.data and not self.collecting_data:
            self.get_logger().info("Manual Calibration started...")
            self.calibration_reason = "manual"
            self.start_calibration()
        elif self.collecting_data:
            self.get_logger().info("calibration in progress . . . ")

    def start_calibration(self):
        self.collecting_data = True
        self.left_speed_data = []
        self.right_speed_data = []
        self.yaw_data = []
        self.wheel_moved = False

        for remaining in range(self.required_samples, 0, -1):
            if self.wheel_moved:
                self.get_logger().warn("Wheel movement detected! Restarting calibration...")
                self.collecting_data = False
                time.sleep(1)
                self.start_calibration()
                return
            
            if self.front_zone_blocked:
                self.get_logger().warn("Front zone blocked (zone 4)! Restarting calibration...")
                self.collecting_data = False
                time.sleep(1)
                self.start_calibration()
                return

            sys.stdout.write(f"\rCalibration in progress... {self.required_samples-len(self.yaw_data)} data left")
            sys.stdout.flush()
            time.sleep(0.05)

        sys.stdout.flush()

    def left_speed_callback(self, msg):
        if self.collecting_data and not self.front_zone_blocked:
            if abs(msg.data) > self.stop_vel:
                self.wheel_moved = True
                return
            self.left_speed_data.append(msg.data)

    def right_speed_callback(self, msg):
        if self.collecting_data and not self.front_zone_blocked:
            if abs(msg.data) > self.stop_vel:
                self.wheel_moved = True
                return
            self.right_speed_data.append(msg.data)

    def imu_callback(self, msg):
        if self.collecting_data and not self.front_zone_blocked:
            self.yaw_data.append(msg.angular_velocity.z)

    def front_zone_callback(self, msg):
        if msg.data == 4:
            if self.collecting_data and not self.front_zone_blocked:
                self.get_logger().warn("Front zone blocked (zone 4)! Pausing calibration...")
                self.front_zone_blocked = True
                # Clear collected data when zone becomes blocked
                if self.collecting_data:
                    self.left_speed_data = []
                    self.right_speed_data = []
                    self.yaw_data = []
        else:
            if self.front_zone_blocked:
                self.get_logger().info("Front zone cleared! Resuming calibration...")
                self.front_zone_blocked = False
                # Always restart calibration when zone clears, regardless of current state
                self.left_speed_data = []
                self.right_speed_data = []
                self.yaw_data = []
                # Restart calibration process
                self.get_logger().info("Restarting calibration after zone cleared...")
                self.pub_speed_limit.publish(self.stop_speed)
                time.sleep(0.1)
                self.start_calibration()

    def imu_temp_callback(self, msg):
        curr_temperature = msg.temperature
        self.current_temperature = curr_temperature
        
        if self.last_temperature == -270.0:
            self.last_temperature = curr_temperature

        if abs(curr_temperature - self.last_temperature) > self.temperature_variation and not self.collecting_data:
            self.get_logger().info(f"temperature changed from start {self.last_temperature:.2f} to {curr_temperature:.2f} need to calibrate...")
            
            self.calibration_reason = "temperature_change"
            self.pub_speed_limit.publish(self.stop_speed)
            time.sleep(0.05)
            self.start_calibration()
            self.last_temperature = curr_temperature

    def calculate_yaw(self):
        if (len(self.left_speed_data) >= self.required_samples and
            len(self.right_speed_data) >= self.required_samples and
            len(self.yaw_data) >= self.required_samples):
                
            self.get_logger().info(f"Collected {self.required_samples} samples, checking velocity criteria...")
            
            self.left_speed_data = self.left_speed_data[10:]
            self.right_speed_data = self.right_speed_data[10:]
            
            if (all(abs(v) < self.stop_vel for v in self.left_speed_data) and
                all(abs(v) < self.stop_vel for v in self.right_speed_data)):

                if len(self.yaw_data) == 0:  # Prevent ZeroDivisionError
                    self.get_logger().warn("Yaw data is empty! Skipping calibration update.")
                    self.vz_offset = self.load_vz_offset()
                    return
                    
                # remove last 10 yaw data for having few noises
                self.yaw_data = self.yaw_data[10:-10]

                # Compute new yaw bias
                self.vz_offset = sum(self.yaw_data) / len(self.yaw_data)

                # Validate vz_offset - reject if greater than 0.03
                if abs(self.vz_offset) > 0.03:
                    self.get_logger().warn(f"Calibration rejected! vz_offset {self.vz_offset:.5f} exceeds threshold (0.03). Restarting calibration...")
                    # Reset data collection and restart
                    self.collecting_data = False
                    self.left_speed_data = []
                    self.right_speed_data = []
                    self.yaw_data = []
                    self.pub_speed_limit.publish(self.stop_speed)
                    time.sleep(0.5)
                    self.start_calibration()
                    return

                # Save to YAML and update parameter
                self.save_vz_offset(self.vz_offset)
                self.set_parameters([rclpy.parameter.Parameter('vz_offset', rclpy.Parameter.Type.DOUBLE, self.vz_offset)])
                
                # Update led_imu node's parameter in real-time
                self.update_led_imu_vz_offset(self.vz_offset)
                
                # Log to CSV file
                self.log_calibration_to_csv(self.vz_offset, self.calibration_reason, self.current_temperature)

                self.get_logger().info(f"Calibration successful. Updated vz_offset: {self.vz_offset:.5f}")
                self.get_logger().info(f"total yaw collected = {len(self.yaw_data)} with left data = {len(self.left_speed_data)} and right data = {len(self.right_speed_data)}.")
                self.pub_speed_limit.publish(self.normal_speed)
                
                sys.stdout.write(f"\rCalibration complete! Waiting for a calibration command; otherwise, will recalibrate in {self.calib_delay} minutes or with a temperature variation of {self.temperature_variation:.2f} degree celsius.\n")
                
                # Reset data collection
                self.collecting_data = False
                self.left_speed_data = []
                self.right_speed_data = []
                self.yaw_data = []
                self.prev_time = time.time()
                return

            else:
                self.get_logger().warn("Wheel speeds exceeded threshold! Restarting data collection...")
                self.start_calibration()  # Restart immediately

    def main_loop(self):
        curr_time = time.time()
        if (curr_time - self.prev_time > (60 * self.calib_delay)) and not self.collecting_data:
            """Auto-calibration trigger every configured minutes"""
            self.prev_time = curr_time

            self.get_logger().info(f"{self.calib_delay} minutes from last calibration Auto-calibration started...")
            self.calibration_reason = "auto"
            self.pub_speed_limit.publish(self.stop_speed)
            time.sleep(0.5)
            self.start_calibration()

        if self.collecting_data:
            self.calculate_yaw()

def main(args=None):
    rclpy.init(args=args)
    
    imu_calibration_node = IMUCalibrationNode()
    
    try:
        rclpy.spin(imu_calibration_node)
    except KeyboardInterrupt:
        pass
    finally:
        imu_calibration_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
