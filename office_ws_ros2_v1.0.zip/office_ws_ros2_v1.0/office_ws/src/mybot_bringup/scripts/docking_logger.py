#!/usr/bin/env python3
import os
import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Int16
from datetime import datetime, date
from geometry_msgs.msg import PoseStamped
import csv

class DockingLoggerNode(Node):
    def __init__(self):
        super().__init__('docking_logger_node')
        
        self.get_logger().info("Docker logging started")
        
        self.conveyor_data = None
        self.count = 0
        self.batt_per = 0.0
        self.count_prev = 0
        
        # Create subscribers
        self.docking_logger_sub = self.create_subscription(
            String,
            "/docking_logger",
            self.conveyor_log_callback,
            10
        )
        
        self.battery_sub = self.create_subscription(
            Int16,
            "/battery_percentage",
            self.battery_percentage_callback,
            10
        )
        
        # Initialize log file
        now = datetime.now()
        heading_val = str(now) + "\n"
        
        self.dir_path = f"/home/fleet-wipro/office_ws/src/mybot_bringup/log_data/conveyor_log_{str(date.today())}.csv"
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(self.dir_path), exist_ok=True)
        
        with open(self.dir_path, "w") as my_file:
            my_file.write(heading_val)
        
        # Create timer for 20 Hz operation
        self.timer = self.create_timer(0.05, self.timer_callback)  # 20 Hz = 0.05s
        
    def battery_percentage_callback(self, data):
        self.batt_per = data.data
        
    def conveyor_log_callback(self, data):
        self.count += 1
        self.conveyor_data = data.data
        
    def timer_callback(self):
        if self.count > self.count_prev:
            logged_val = f"{self.count} , {self.conveyor_data} , {self.batt_per}\n"
            
            with open(self.dir_path, "a") as my_file:
                my_file.write(logged_val)
                
            self.count_prev = self.count

def main(args=None):
    rclpy.init(args=args)
    
    docking_logger_node = DockingLoggerNode()
    
    try:
        rclpy.spin(docking_logger_node)
    except KeyboardInterrupt:
        pass
    finally:
        docking_logger_node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()