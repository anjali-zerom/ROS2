#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
import os
from std_msgs.msg import Int16

class ShutdownNode(Node):
    def __init__(self):
        super().__init__('shutdown_listener')
        
        qos_profile_reliable = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=5
        )
        # Create subscriber
        self.shutdown_sub = self.create_subscription(Int16,'/shutdown_button_pushed',self.shutdown_callback,qos_profile_reliable)
        
        self.get_logger().info("Shutdown listener node started. Waiting for shutdown signal...")
        
    def shutdown_callback(self, data):
        if data.data == 200:
            self.get_logger().info("Shutdown button pressed. Shutting down the system.")
            os.system("systemctl poweroff")

def main(args=None):
    rclpy.init(args=args)
    
    shutdown_node = ShutdownNode()
    
    try:
        rclpy.spin(shutdown_node)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
