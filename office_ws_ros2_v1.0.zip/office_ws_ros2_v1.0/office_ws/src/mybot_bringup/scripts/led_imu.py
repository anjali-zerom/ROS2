#!/usr/bin/env python3
import sys
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from std_msgs.msg import String
from sensor_msgs.msg import Imu, Temperature
import serial
import time
import struct

class LEDIMUNode(Node):
    def __init__(self):
        super().__init__('led_imu_crc_node')
        
        # QoS Profile for low latency communication (matching ticks_based_move_wrap.py)
        qos_profile_best_effort = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        self.led_data = None
        self.robot_status = "EMERF"
        self.com_port = None
        self.consecutive_errors = 0
        self.max_consecutive_errors = 10  # Reconnect after this many errors
        
        self.get_logger().info("Led_imu_crc node running")
        
        # Declare parameters
        self.declare_parameter('imu_ComPort', '/dev/ttyUSB0')
        self.declare_parameter('imu_baudrate', 115200)
        self.declare_parameter('imu_bytesize', 8)
        self.declare_parameter('imu_parity', 'N')
        self.declare_parameter('imu_stopbits', 1)
        self.declare_parameter('imu_timeout', 1)
        self.declare_parameter('vz_offset', 0.00000)
        
        # Store serial config for reconnection
        self.serial_config = {
            'port': self.get_parameter('imu_ComPort').get_parameter_value().string_value,
            'baudrate': self.get_parameter('imu_baudrate').get_parameter_value().integer_value,
            'bytesize': self.get_parameter('imu_bytesize').get_parameter_value().integer_value,
            'parity': self.get_parameter('imu_parity').get_parameter_value().string_value,
            'stopbits': self.get_parameter('imu_stopbits').get_parameter_value().integer_value,
            'timeout': self.get_parameter('imu_timeout').get_parameter_value().integer_value,
        }
        
        # Create publishers
        self.imu_publisher_raw = self.create_publisher(Imu, '/imu/imu_raw_uncalib', qos_profile_best_effort)
        self.imu_publisher_calib = self.create_publisher(Imu, '/imu/imu_raw_calib', qos_profile_best_effort)
        self.temp_pub = self.create_publisher(Temperature, '/imu/temperature', qos_profile_best_effort)
        self.error_pub = self.create_publisher(String, '/imu/error', qos_profile_best_effort)
        
        # Create subscriber
        self.create_subscription(String, "/robot_status", self.update_robot_status, qos_profile_best_effort)
        
        # Initialize serial communication
        if not self.init_serial_port():
            self.get_logger().error("Failed to initialize serial port on startup")
            
        # Initialize LED and IMU commands
        self.read_imu_data = bytearray(b'\x01\x06\x05\x49\x4D\x55\x44\x54\x0F\xDF')
        self.write_led_off = bytearray(b'\x01\x0A\x05\x00\x00\x00\x00\x0C\x2B\x97')
        
        # Turn off LED initially (if port is open)
        if self.com_port and self.com_port.is_open:
            try:
                self.com_port.write(self.write_led_off)
                time.sleep(0.5)
            except Exception as e:
                self.get_logger().warn(f"Failed to send initial LED off command: {e}")
        
        # Initialize LED control variables
        self.lock_bit = 12  # 0C
        self.color1 = [0, 0, 0, 0]
        self.color2 = [0, 0, 0, 0]
        self.led_visual = 0
        self.change = False
        
        # Create timer for main loop (20 Hz)
        self.timer = self.create_timer(0.05, self.main_loop)
    
    def init_serial_port(self):
        """Initialize or reinitialize the serial port with proper cleanup."""
        # Close existing port if open
        if self.com_port is not None:
            try:
                if self.com_port.is_open:
                    self.com_port.reset_input_buffer()
                    self.com_port.reset_output_buffer()
                    self.com_port.close()
                    time.sleep(0.1)  # Give OS time to release the port
            except Exception as e:
                self.get_logger().warn(f"Error closing existing port: {e}")
            self.com_port = None
        
        # Open new connection
        try:
            self.com_port = serial.Serial(
                port=self.serial_config['port'],
                baudrate=self.serial_config['baudrate'],
                bytesize=self.serial_config['bytesize'],
                parity=self.serial_config['parity'],
                stopbits=self.serial_config['stopbits'],
                timeout=self.serial_config['timeout'],
                write_timeout=1.0,  # Add write timeout
                exclusive=True  # Exclusive access to prevent conflicts
            )
            
            # Flush buffers after opening
            time.sleep(0.1)  # Wait for port to stabilize
            self.com_port.reset_input_buffer()
            self.com_port.reset_output_buffer()
            
            # Toggle DTR/RTS to reset the device
            self.com_port.dtr = False
            self.com_port.rts = False
            time.sleep(0.05)
            self.com_port.dtr = True
            self.com_port.rts = True
            time.sleep(0.1)
            
            # Clear any garbage data
            self.com_port.reset_input_buffer()
            
            self.consecutive_errors = 0
            self.get_logger().info(f"Serial port {self.serial_config['port']} initialized successfully")
            return True
            
        except Exception as e:
            self.get_logger().error(f"Failed to initialize serial port: {str(e)}")
            self.com_port = None
            return False
    
    def reconnect_serial(self):
        """Attempt to reconnect the serial port."""
        self.get_logger().warn("Attempting to reconnect serial port...")
        
        # Wait a bit before reconnecting
        time.sleep(0.5)
        
        if self.init_serial_port():
            # Re-send LED off command after reconnect
            try:
                self.com_port.write(self.write_led_off)
                time.sleep(0.1)
                self.get_logger().info("Serial port reconnected successfully")
                return True
            except Exception as e:
                self.get_logger().error(f"Failed to send LED command after reconnect: {e}")
                return False
        return False
        
    def crc16_generator_hex(self, data):
        data = bytearray(data)
        crc = 0xFFFF
        
        for b in data:
            crc ^= b
            for _ in range(0, 8):
                bcarry = crc & 0x0001
                crc >>= 1
                if bcarry:
                    crc ^= 0xa001
        return hex(crc)
        
    def check_crc(self, data):
        data_in = data[0:-2]
        crc_calculate = self.crc16_generator_hex(data_in)
        crc_calculate_int = int(crc_calculate, 16)
        
        crc_incoming_hex_1 = format(data[-1], "x")
        crc_incoming_hex_2 = format(data[-2], "x")
        
        crc_incoming_hex = hex(int(crc_incoming_hex_1, 16) << 8 | int(crc_incoming_hex_2, 16))
        crc_incoming_int = int(crc_incoming_hex, 16)
        
        if crc_calculate_int == crc_incoming_int:
            return True
        else:
            return False
            
    def hex_list_to_float(self, hex_list):
        hex_string = ''.join(hex_list)
        byte_array = bytearray.fromhex(hex_string)
        
        if len(byte_array) != 4:
            raise ValueError("Hex list must represent exactly 4 bytes.")
        
        float_value = struct.unpack('f', byte_array)[0]
        return round(float_value, 4)
        
    def update_robot_status(self, data):
        self.robot_status = data.data

    def main_loop(self):
        """Main loop for LED control and IMU data processing."""
        
        # LED status control logic
        if self.robot_status == "EMERF" or self.robot_status == "EMERR" or self.robot_status == "LIDRF":
            self.color1 = [255, 0, 0, 0]
            self.led_visual = 10  # constant
            self.change = True
            # emergency or lidar stop red
            
        elif self.robot_status == "DTDST":
            self.color1 = [0, 64, 128, 0]
            self.led_visual = 10  # constant
            self.change = True
            # driving to destination blue
            
        elif self.robot_status == "RIDLE":
            self.color1 = [255, 64, 0, 0]
            self.led_visual = 10  # constant
            self.change = True
            # robot idle yellow
            
        elif self.robot_status == "LEROR" or self.robot_status == "HEROR":
            self.color1 = [255, 0, 0, 0]
            self.color2 = [255, 64, 0, 0]
            self.led_visual = 249  # dual
            self.change = True
            # general error localization or hardware error red yellow
            
        elif self.robot_status == "RSHUT":
            self.color1 = [192, 192, 128, 0]
            self.led_visual = 171  # weavering
            self.change = True
            # robot shut down weavering white
            
        elif self.robot_status == "RCHRG":
            self.color1 = [0, 64, 128, 0]
            self.led_visual = 171  # weavering
            self.change = True
            # robot charging weavering blue
            
        elif self.robot_status == "BTLOW":
            self.color1 = [255, 0, 200, 0]
            self.led_visual = 171  # blinking
            self.change = True
            # robot battery low blinking red
            
        elif self.robot_status == "RDOCK":
            self.color1 = [0, 64, 128, 0]
            self.led_visual = 171  # blinking
            self.change = True
            # robot drives with muted protective field while docking blue
            
        elif self.robot_status == "BRAKE":
            self.color1 = [0, 64, 128, 0]
            self.color2 = [255, 64, 0, 0]
            self.led_visual = 249  # dual
            self.change = True
            # manual brake blue yellow
            
        elif self.robot_status == "off":
            self.color1 = [0, 0, 0, 0]
            self.led_visual = 10  # constant
            self.change = True
            
        elif self.robot_status == "red":
            self.color1 = [255, 0, 0, 0]
            self.led_visual = 10  # constant
            self.change = True
            
        elif self.robot_status == "green":
            self.color1 = [0, 255, 0, 0]
            self.led_visual = 10  # constant
            self.change = True
            
        elif self.robot_status == "blue":
            self.color1 = [0, 0, 255, 0]
            self.led_visual = 10  # constant
            self.change = True
            
        elif self.robot_status == "white":
            self.color1 = [0, 0, 0, 255]
            self.led_visual = 10  # constant
            self.change = True
            
        elif self.robot_status == "yellow":
            self.color1 = [249, 168, 0, 0]
            self.led_visual = 10  # constant
            self.change = True
            
        elif self.robot_status == "redlow":
            self.color1 = [150, 0, 0, 0]
            self.led_visual = 10  # constant
            self.change = True
            
        elif self.robot_status == "greenlow":
            self.color1 = [0, 150, 0, 0]
            self.led_visual = 10  # constant
            self.change = True
            
        elif self.robot_status == "bluelow":
            self.color1 = [0, 0, 150, 0]
            self.led_visual = 10  # constant
            self.change = True
            
        elif self.robot_status == "whitelow":
            self.color1 = [0, 0, 0, 150]
            self.led_visual = 10  # constant
            self.change = True
            
        elif self.robot_status == "yellowlow":
            self.color1 = [125, 84, 0, 0]
            self.led_visual = 10  # constant
            self.change = True
            
        elif self.robot_status == "cyanlow":
            self.color1 = [0, 152, 152, 0]
            self.led_visual = 10  # constant
            self.change = True
            
        elif self.robot_status == "yellowweav":
            self.color1 = [125, 84, 0, 0]
            self.led_visual = 171  # weavering
            self.change = True
            # robot battery low weavering red
            
        self.robot_status = None
        
        # Prepare LED data
        if self.led_visual == 249:
            led_data_hex = [1, self.led_visual, 9, self.color1[0], self.color1[1], self.color1[2], self.color1[3],
                           self.color2[0], self.color2[1], self.color2[2], self.color2[3], self.lock_bit]
            led_data_hex_crc = self.crc16_generator_hex(led_data_hex)
            led_data_crc_1 = int(hex(int(led_data_hex_crc, 16) >> 8), 16)
            led_data_crc_2 = int(hex(int(led_data_hex_crc, 16) & 0x00ff), 16)
            led_data_send = [1, self.led_visual, 9, self.color1[0], self.color1[1], self.color1[2], self.color1[3],
                            self.color2[0], self.color2[1], self.color2[2], self.color2[3], self.lock_bit,
                            led_data_crc_2, led_data_crc_1]
        else:
            led_data_hex = [1, self.led_visual, 5, self.color1[0], self.color1[1], self.color1[2], self.color1[3], self.lock_bit]
            led_data_hex_crc = self.crc16_generator_hex(led_data_hex)
            led_data_crc_1 = int(hex(int(led_data_hex_crc, 16) >> 8), 16)
            led_data_crc_2 = int(hex(int(led_data_hex_crc, 16) & 0x00ff), 16)
            led_data_send = [1, self.led_visual, 5, self.color1[0], self.color1[1], self.color1[2], self.color1[3],
                            self.lock_bit, led_data_crc_2, led_data_crc_1]
        
        # Read IMU data
        try:
            # Check if port is available
            if self.com_port is None or not self.com_port.is_open:
                self.reconnect_serial()
                error_msg = String()
                error_msg.data = "Serial port not open, reconnecting..."
                self.error_pub.publish(error_msg)
                return
            
            self.com_port.reset_input_buffer()
            time.sleep(0.004)
            self.com_port.write(self.read_imu_data)
            time.sleep(0.004)
            data_imu = self.com_port.read(44)
            time.sleep(0.004)
            
            # Send LED data if changed
            if self.change:
                self.com_port.write(led_data_send)
                time.sleep(0.004)
                self.com_port.read(10)
                self.change = False
                
            # Process IMU data
            if len(data_imu) == 44:
                if self.check_crc(data_imu):
                    self.consecutive_errors = 0  # Reset error counter on success
                    
                    # Parse 10 floats (40 bytes) starting at offset 2
                    ax = struct.unpack('f', data_imu[2:6])[0]
                    ay = struct.unpack('f', data_imu[6:10])[0]
                    az = struct.unpack('f', data_imu[10:14])[0]
                    vx = struct.unpack('f', data_imu[14:18])[0]
                    vy = struct.unpack('f', data_imu[18:22])[0]
                    vz = struct.unpack('f', data_imu[22:26])[0]
                    mx = struct.unpack('f', data_imu[26:30])[0]
                    my = struct.unpack('f', data_imu[30:34])[0]
                    mz = struct.unpack('f', data_imu[34:38])[0]
                    temp = struct.unpack('f', data_imu[38:42])[0]
                    
                    # Create timestamp
                    now = self.get_clock().now().to_msg()
                    
                    # Publish raw IMU data
                    imu_msg = Imu()
                    imu_msg.header.stamp = now
                    imu_msg.header.frame_id = "imu_link"
                    imu_msg.linear_acceleration.x = ax
                    imu_msg.linear_acceleration.y = ay
                    imu_msg.linear_acceleration.z = -az
                    imu_msg.angular_velocity.x = vx
                    imu_msg.angular_velocity.y = vy
                    imu_msg.angular_velocity.z = -vz
                    imu_msg.orientation.x = 0.0
                    imu_msg.orientation.y = 0.0
                    imu_msg.orientation.z = 0.0
                    imu_msg.orientation.w = 0.0
                    imu_msg.orientation_covariance = [1e6, 0, 0, 0, 1e6, 0, 0, 0, 1e-6]
                    imu_msg.angular_velocity_covariance = [1e6, 0, 0, 0, 1e6, 0, 0, 0, 1e-6]
                    imu_msg.linear_acceleration_covariance = [-1, 0, 0, 0, 0, 0, 0, 0, 0]
                    
                    self.imu_publisher_raw.publish(imu_msg)
                    
                    # Publish calibrated IMU data
                    vz_offset = self.get_parameter('vz_offset').get_parameter_value().double_value
                    imu_msg_calib = Imu()
                    imu_msg_calib.header.stamp = now
                    imu_msg_calib.header.frame_id = "imu_link"
                    imu_msg_calib.linear_acceleration.x = ax
                    imu_msg_calib.linear_acceleration.y = ay
                    imu_msg_calib.linear_acceleration.z = -az
                    imu_msg_calib.angular_velocity.x = vx
                    imu_msg_calib.angular_velocity.y = vy
                    imu_msg_calib.angular_velocity.z = -vz - vz_offset
                    imu_msg_calib.orientation.x = 0.0
                    imu_msg_calib.orientation.y = 0.0
                    imu_msg_calib.orientation.z = 0.0
                    imu_msg_calib.orientation.w = 0.0
                    imu_msg_calib.orientation_covariance = [1e6, 0, 0, 0, 1e6, 0, 0, 0, 1e-6]
                    imu_msg_calib.angular_velocity_covariance = [1e6, 0, 0, 0, 1e6, 0, 0, 0, 1e-6]
                    imu_msg_calib.linear_acceleration_covariance = [-1, 0, 0, 0, 0, 0, 0, 0, 0]
                    
                    self.imu_publisher_calib.publish(imu_msg_calib)
                    
                    # Publish temperature data
                    temp_msg = Temperature()
                    temp_msg.header.stamp = now
                    temp_msg.header.frame_id = "imu_link"
                    temp_msg.temperature = temp
                    temp_msg.variance = 1.0
                    
                    self.temp_pub.publish(temp_msg)

                    error_msg = String()
                    error_msg.data = "None"
                    self.error_pub.publish(error_msg)
                else:
                    self.consecutive_errors += 1
                    error_msg = String()
                    error_msg.data = "CRC mismatch"
                    self.error_pub.publish(error_msg)
            else:
                self.consecutive_errors += 1
                error_msg = String()
                error_msg.data = f"IMU communication error (got {len(data_imu)} bytes)"
                self.error_pub.publish(error_msg)
            
            # Check if we need to reconnect due to too many errors
            if self.consecutive_errors >= self.max_consecutive_errors:
                self.get_logger().warn(f"Too many consecutive errors ({self.consecutive_errors}), reconnecting...")
                self.reconnect_serial()
                
        except serial.SerialException as e:
            self.get_logger().error(f"Serial exception: {str(e)}")
            self.consecutive_errors += 1
            error_msg = String()
            error_msg.data = f"Serial exception: {str(e)}"
            self.error_pub.publish(error_msg)
            
            # Reconnect on serial exception
            self.reconnect_serial()
            
        except Exception as e:
            self.get_logger().error(f"Serial communication error: {str(e)}")
            self.consecutive_errors += 1
            error_msg = String()
            error_msg.data = f"Serial error: {str(e)}"
            self.error_pub.publish(error_msg)
            
            if self.consecutive_errors >= self.max_consecutive_errors:
                self.reconnect_serial()

def main(args=None):
    rclpy.init(args=args)
    
    led_imu_node = LEDIMUNode()
    
    try:
        rclpy.spin(led_imu_node)
    except KeyboardInterrupt:
        pass
    finally:
        # Properly close serial port on shutdown
        if led_imu_node.com_port is not None:
            try:
                if led_imu_node.com_port.is_open:
                    led_imu_node.com_port.reset_input_buffer()
                    led_imu_node.com_port.reset_output_buffer()
                    led_imu_node.com_port.close()
                    led_imu_node.get_logger().info("Serial port closed cleanly")
            except Exception as e:
                led_imu_node.get_logger().warn(f"Error closing serial port: {e}")
        led_imu_node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
