#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Int16,Int32, Int64, Float32, String, UInt64
from nav_msgs.msg import Odometry
import time
import tf2_ros
import os
import math
from math import pow, atan2, sqrt, pi,cos,sin
from geometry_msgs.msg import PoseStamped,Pose
from geometry_msgs.msg import PoseWithCovarianceStamped

class TicksBasedReverse(Node):
    def __init__(self):
        super().__init__('ticks_based_reverse')
        
        self.left_position = 0.0
        self.right_position = 0.0
        self.change_in_position = -0.1  # meter
        
        # Subscribers
        self.create_subscription(Int64, 'moons_left_position', self.get_left_position, 10)
        self.create_subscription(Int64, 'moons_right_position', self.get_right_position, 10)
        self.create_subscription(Float32, 'reverse_distance', self.get_rev_dist, 10)
        
        # Publishers
        self.velocity_publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        
        self.reverse()
    
    def get_left_position(self, data):
        self.left_position = data.data
        
    def get_right_position(self, data):
        self.right_position = data.data

    def clamp_velocity(self, velocity, min_velocity, max_velocity):
        min_velocity = abs(min_velocity)  # Ensure min_velocity is positive
        max_velocity = abs(max_velocity)  # Ensure max_velocity is positive
        
        if velocity >= 0:
            return min(max_velocity, max(min_velocity, velocity))
        else:
            return max(-max_velocity, min(-min_velocity, velocity))

    def add_offset(self, input_value, offset):
        if input_value > 0:
            return input_value + offset
        elif input_value < 0:
            return input_value - offset
        else:
            return 0

    def get_rev_dist(self, data):
        self.change_in_position = -1 * abs(data.data)

    def reverse(self):
        print("Let's reverse the robot")

        vel_msg = Twist()
        vel_msg.linear.x=0 #left wheel velocity
        vel_msg.linear.y=0
        vel_msg.linear.z=0
        vel_msg.angular.x = 0
        vel_msg.angular.y = 0
        vel_msg.angular.z = 0 #right wheel velocity

        moving = True 
  
        self.get_logger().info("entered zone 4 with distance %f" % self.change_in_position)
        initial_left_position  = 0
        initial_right_position = 0

        left_distance_travelled  = 0
        right_distance_travelled = 0

        ticks_per_meter = 452500.00 #339204.00
        base_width      = 0.734 

        dist_break      = 0.0015
        diff            = 0.0005
        max_wheel_vel   = 0.25        #m/sec
        min_wheel_vel   = 0.03    #m/sec

        kp = 1.0;ki = 0.000
        prev_pid_time = self.get_clock().now()
        integral = 0.0
        previous_error = 0.0
        left_stop = False
        right_stop = False
        
        initial_accel_dist_per  = 50.0
        accel_step              = 0.02
            ticks_travelled_left = (left_previous - left_position)
        
        left_previous = left_position
        left_increment = ticks_travelled_left

        if right_position < encoder_low_wrap and right_previous > encoder_high_wrap :
            ticks_travelled_right = (right_position - encoder_min) + (encoder_max - right_previous)
            
        elif right_position  > encoder_high_wrap and right_previous < encoder_low_wrap :
            ticks_travelled_right = -1 * ((right_previous - encoder_min) + (encoder_max - right_position))
        else :
            ticks_travelled_right = (right_position-right_previous)

        right_previous  = right_position
        right_increment = ticks_travelled_right


        if moving :

            pid_dt_duration = self.get_clock().now() - prev_pid_time
            pid_dt          = pid_dt_duration.to_sec()
            prev_pid_time   = self.get_clock().now()

            # print("left_increment",left_increment,"right_increment",right_increment)

            left_distance_travelled  = left_distance_travelled  - left_increment   #in ticks
            right_distance_travelled = right_distance_travelled + right_increment  #in ticks
            # print("left_distance_travelled",left_distance_travelled,"right_distance_travelled",right_distance_travelled)

            left_error      = (final_left_position-left_distance_travelled)/ ticks_per_meter     #in meter
            right_error     = (final_right_position-right_distance_travelled)/ticks_per_meter    #in meter

            # print("left_error",left_error,"right_error",right_error)
            
            if abs(left_error) > initial_accel_dist:
                max_vel = max_vel + accel_step
            else:
                max_vel = max_wheel_vel
            
            if abs(right_error) > initial_accel_dist:
                max_vel = max_vel + accel_step
            else:
                max_vel = max_wheel_vel

            if left_stop == False:
                vel_msg.linear.x    =   (left_error*kp)
                vel_msg.linear.x    = clamp_velocity(vel_msg.linear.x,min_wheel_vel,max_vel)
                vel_msg.linear.x    = clamp_velocity(vel_msg.linear.x,min_wheel_vel,max_wheel_vel)

            if right_stop == False:
                vel_msg.angular.z   =   (right_error*kp)
                vel_msg.angular.z   = clamp_velocity(vel_msg.angular.z,min_wheel_vel,max_vel)
                vel_msg.angular.z   = clamp_velocity(vel_msg.angular.z,min_wheel_vel,max_wheel_vel)
                
            diff_kp     = 1.5
            diff_error  = abs(left_error)-abs(right_error)
            diff_addup  = abs(diff_error*diff_kp)
            
            if abs(diff_error) > diff:
                if abs(left_error)<abs(right_error):
                    vel_msg.linear.x = add_offset(vel_msg.linear.x,-diff_addup)
                    vel_msg.angular.z = add_offset(vel_msg.angular.z,diff_addup)
                    
                elif abs(left_error)>abs(right_error):
                    vel_msg.linear.x = add_offset(vel_msg.linear.x,diff_addup)
                    vel_msg.angular.z = add_offset(vel_msg.angular.z,-diff_addup)
                
                # print("difference in distance",round(abs(abs(left_error)-abs(right_error)),4),"velocity comm",round(vel_msg.linear.x,4),round(vel_msg.angular.z,4))
            
            if left_stop == False:
                vel_msg.linear.x    = clamp_velocity(vel_msg.linear.x,min_wheel_vel/2,max_wheel_vel)

            if right_stop == False:
                vel_msg.angular.z   = clamp_velocity(vel_msg.angular.z,min_wheel_vel/2,max_wheel_vel)
            
            if  abs(left_error) <= dist_break:
                
                vel_msg.linear.x    = 0
                left_stop = True

            if abs(right_error) <= dist_break:
                
                vel_msg.angular.z   = 0
                right_stop = True

            if left_stop == True and right_stop == True:
                
                left_stop = False
                right_stop = False
                moving = False
                velocity_publisher.publish(vel_msg)

                zone_publisher.publish(1)
                print("entered zone 1 ")
                
                reverse_complete.publish("True")
                
                print(" left_error ",left_error,"right_error",right_error)
                # print(initial_left_position,left_position,initial_left_position-left_position,initial_right_position,right_position,initial_right_position-right_position)

                time.sleep(2)
                os._exit(0)
                # os._exit(0)

        self.velocity_publisher.publish(vel_msg)

def main(args=None):
    rclpy.init(args=args)
    node = TicksBasedReverse()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()