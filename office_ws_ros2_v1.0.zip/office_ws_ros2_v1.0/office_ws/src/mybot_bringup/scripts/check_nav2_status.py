#!/usr/bin/env python3
"""
Diagnostic script to check Nav2 system status
Checks topics, TF tree, and lifecycle node states
"""
import rclpy
from rclpy.node import Node
from lifecycle_msgs.srv import GetState
import time

class Nav2StatusChecker(Node):
    def __init__(self):
        super().__init__('nav2_status_checker')
        self.get_logger().info('=== Nav2 Status Checker ===\n')
        
        time.sleep(2.0)  # Wait for system to stabilize
        
        # Check lifecycle nodes
        self.check_lifecycle_nodes()
        
        # Check topics
        self.check_topics()
        
        self.get_logger().info('\n=== Status Check Complete ===')
        
    def check_lifecycle_nodes(self):
        """Check status of all Nav2 lifecycle nodes"""
        self.get_logger().info('--- Lifecycle Node Status ---')
        
        nodes = [
            '/map_server',
            '/amcl',
            '/controller_server',
            '/planner_server',
            '/recoveries_server',
            '/bt_navigator',
            '/waypoint_follower'
        ]
        
        state_names = {
            0: 'UNKNOWN',
            1: 'UNCONFIGURED',
            2: 'INACTIVE',
            3: 'ACTIVE',
            4: 'FINALIZED'
        }
        
        for node_name in nodes:
            state_id = self.get_node_state(node_name)
            state_name = state_names.get(state_id, 'UNKNOWN')
            
            if state_id == 3:
                status = '✓'
            elif state_id == 2:
                status = '⚠'
            else:
                status = '✗'
            
            self.get_logger().info(f'{status} {node_name}: {state_name}')
    
    def get_node_state(self, node_name):
        """Get current state of a lifecycle node"""
        client = self.create_client(GetState, f'{node_name}/get_state')
        
        if not client.wait_for_service(timeout_sec=2.0):
            return 0  # UNKNOWN
            
        request = GetState.Request()
        future = client.call_async(request)
        rclpy.spin_until_future_complete(self, future, timeout_sec=2.0)
        
        if future.result() is not None:
            return future.result().current_state.id
        return 0
    
    def check_topics(self):
        """Check if critical topics are being published"""
        self.get_logger().info('\n--- Critical Topics ---')
        
        topics_to_check = [
            '/scan',
            '/odom',
            '/map',
            '/tf',
            '/tf_static',
            '/local_costmap/costmap',
            '/global_costmap/costmap',
            '/plan',
            '/particle_cloud'
        ]
        
        topic_list = self.get_topic_names_and_types()
        available_topics = [t[0] for t in topic_list]
        
        for topic in topics_to_check:
            if topic in available_topics:
                self.get_logger().info(f'✓ {topic}')
            else:
                self.get_logger().info(f'✗ {topic} (NOT FOUND)')

def main(args=None):
    rclpy.init(args=args)
    checker = Nav2StatusChecker()
    
    # Don't spin, just run once
    time.sleep(1.0)
    
    checker.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
