#!/bin/bash
# Manual activation script for Nav2 lifecycle nodes
# Use this if activate_localization.py doesn't work properly

echo "=== Activating Nav2 Lifecycle Nodes ==="

# Wait for nodes to start
sleep 5

# Activate localization nodes
echo "Activating map_server..."
ros2 lifecycle set /map_server configure
sleep 1
ros2 lifecycle set /map_server activate
sleep 2

echo "Activating amcl..."
ros2 lifecycle set /amcl configure
sleep 1
ros2 lifecycle set /amcl activate
sleep 1

# Activate navigation nodes
echo "Activating controller_server..."
ros2 lifecycle set /controller_server configure
sleep 1
ros2 lifecycle set /controller_server activate
sleep 1

echo "Activating planner_server..."
ros2 lifecycle set /planner_server configure
sleep 1
ros2 lifecycle set /planner_server activate
sleep 1

echo "Activating waypoint_follower..."
ros2 lifecycle set /waypoint_follower configure
sleep 1
ros2 lifecycle set /waypoint_follower activate
sleep 1

echo "Activating bt_navigator..."
ros2 lifecycle set /bt_navigator configure
sleep 1
ros2 lifecycle set /bt_navigator activate
sleep 1

echo "Activating recoveries_server..."
ros2 lifecycle set /recoveries_server configure
sleep 1
ros2 lifecycle set /recoveries_server activate

echo "=== All nodes activated ==="
