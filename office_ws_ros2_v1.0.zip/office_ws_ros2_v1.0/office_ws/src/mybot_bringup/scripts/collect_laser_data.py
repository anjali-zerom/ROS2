#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Int16, Float32
import math

class CollectLaserDataNode(Node):
    def __init__(self):
        super().__init__('collect_laser_data')
        
        self.get_logger().info("laser filter while docking")
        
        self.laser_data = None
        self.new_data = False
        
        # Declare parameter
        self.declare_parameter('angle_open', 60)
        self.front_angle = self.get_parameter('angle_open').get_parameter_value().integer_value
        
        # Create publisher
        self.pub_f = self.create_publisher(
            LaserScan,
            'scan_front_laser',
            10
        )
        
        # Create subscriber
        self.laser_sub = self.create_subscription(
            LaserScan,
            '/scan_front_filtered',
            self.laser_callback,
            10
        )
        
        self.front_laser = LaserScan()
        
        # Create timer for 20 Hz operation
        self.timer = self.create_timer(0.05, self.timer_callback)  # 20 Hz = 0.05s
        
    def laser_callback(self, msg):
        self.laser_data = msg
        self.new_data = True
        
    def timer_callback(self):
        if self.new_data and self.laser_data is not None:
            front_angle_rad = self.front_angle * math.pi / 180
            min_angle = -1 * front_angle_rad / 2
            max_angle = front_angle_rad / 2

            array_len = len(self.laser_data.ranges)
            angle_resolution = self.laser_data.angle_increment
            desired_angle_array_len = front_angle_rad / (2 * angle_resolution)
            min_array = int(array_len / 2 - desired_angle_array_len)
            max_array = int(array_len / 2 + desired_angle_array_len)

            self.front_laser.header = self.laser_data.header
            self.front_laser.angle_min = min_angle
            self.front_laser.angle_max = max_angle
            self.front_laser.angle_increment = self.laser_data.angle_increment
            self.front_laser.time_increment = self.laser_data.time_increment
            self.front_laser.scan_time = self.laser_data.scan_time
            self.front_laser.range_min = self.laser_data.range_min
            self.front_laser.range_max = self.laser_data.range_max
            self.front_laser.ranges = self.laser_data.ranges[min_array:max_array]
            self.front_laser.intensities = self.laser_data.intensities[min_array:max_array]

            self.new_data = False
            self.pub_f.publish(self.front_laser)

def main(args=None):
    rclpy.init(args=args)
    
    collect_laser_node = CollectLaserDataNode()
    
    try:
        rclpy.spin(collect_laser_node)
    except KeyboardInterrupt:
        pass
    finally:
        collect_laser_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()