#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Header
from laser_line_extraction.msg import LineSegmentList
from visualization_msgs.msg import Marker

class LineSegmentSwitchNode(Node):
    def __init__(self):
        super().__init__('line_extractor_node')
        
        self.get_logger().info("Line Segment Switch Running...")
        
        # Initialize variables
        self.line_seg_far = None
        self.line_seg_near = None
        self.line_mark_far = None
        self.line_mark_near = None
        self.change_angle = "False"
        self.new_data = "False"
        
        # Create subscribers
        self.far_segment_sub = self.create_subscription(
            LineSegmentList,
            '/line_segments_far',
            self.far_segment_callback,
            10
        )
        
        self.near_segment_sub = self.create_subscription(
            LineSegmentList,
            '/line_segments_near',
            self.near_segment_callback,
            10
        )
        
        self.far_markers_sub = self.create_subscription(
            Marker,
            '/line_markers_far',
            self.far_markers_callback,
            10
        )
        
        self.near_markers_sub = self.create_subscription(
            Marker,
            '/line_markers_near',
            self.near_markers_callback,
            10
        )
        
        self.change_angle_sub = self.create_subscription(
            String,
            '/change_angle',
            self.change_angle_callback,
            10
        )
        
        # Create publishers
        self.line_segment_pub = self.create_publisher(
            LineSegmentList,
            '/line_segments_final',
            5
        )
        
        self.line_marker_pub = self.create_publisher(
            Marker,
            '/line_markers_final',
            5
        )
        
        self.line_seg_final = LineSegmentList()
        self.line_mark_final = Marker()
        
        # Create timer for 20 Hz operation
        self.timer = self.create_timer(0.05, self.timer_callback)  # 20 Hz = 0.05s
        
    def far_segment_callback(self, data):
        self.line_seg_far = data
        self.new_data = "True"
        
    def near_segment_callback(self, data):
        self.line_seg_near = data
        self.new_data = "True"
        
    def far_markers_callback(self, data):
        self.line_mark_far = data
        
    def near_markers_callback(self, data):
        self.line_mark_near = data
        
    def change_angle_callback(self, data):
        self.change_angle = data.data
        
    def timer_callback(self):
        if self.new_data == "True":
            if self.change_angle == "True":
                self.line_seg_final = self.line_seg_near
                self.line_mark_final = self.line_mark_near
                
            elif self.change_angle == "False":
                self.line_seg_final = self.line_seg_far
                self.line_mark_final = self.line_mark_far
                
            if self.line_seg_final and len(self.line_seg_final.line_segments) > 2:
                self.line_segment_pub.publish(self.line_seg_final)
                if self.line_mark_final:
                    self.line_marker_pub.publish(self.line_mark_final)
                    
            self.new_data = "False"

def main(args=None):
    rclpy.init(args=args)
    
    line_segment_switch_node = LineSegmentSwitchNode()
    
    try:
        rclpy.spin(line_segment_switch_node)
    except KeyboardInterrupt:
        pass
    finally:
        line_segment_switch_node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()



