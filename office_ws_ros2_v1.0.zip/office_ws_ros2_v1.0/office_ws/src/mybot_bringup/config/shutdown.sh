#!/usr/bin/env bash
echo 04082022 | sudo -S shutdown now
