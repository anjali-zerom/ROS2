#!/usr/bin/env python3

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition, UnlessCondition
from launch.substitutions import LaunchConfiguration, Command
from launch_ros.actions import Node

def generate_launch_description():
    # Get the package directory
    pkg_share = get_package_share_directory('mybot_description')
    
    # Set the path to the URDF file (updated to use the corrected URDF)
    default_model_path = os.path.join(pkg_share, 'urdf', 'mybot.urdf.xacro')
    
    # Set default RViz config path (fallback to our config if mybot_bringup doesn't exist)
    default_rviz_config_path = os.path.join(pkg_share, 'rviz', 'mybot.rviz')
    
    # Try to get mybot_bringup package path for RViz config
    try:
        bringup_pkg_share = get_package_share_directory('mybot_bringup')
        bringup_rviz_config = os.path.join(bringup_pkg_share, 'rviz', 'urdf.rviz')
        if os.path.exists(bringup_rviz_config):
            default_rviz_config_path = bringup_rviz_config
    except:
        pass  # Use fallback config
    
    # Declare launch arguments
    urdf_file_arg = DeclareLaunchArgument(
        name='urdf_file', 
        default_value=default_model_path,
        description='Absolute path to robot urdf file'
    )
    
    gui_arg = DeclareLaunchArgument(
        name='gui',
        default_value='true',
        description='Flag to enable joint_state_publisher_gui'
    )
    
    rviz_config_arg = DeclareLaunchArgument(
        name='rvizconfig', 
        default_value=default_rviz_config_path,
        description='Absolute path to rviz config file'
    )
    
    use_sim_time_arg = DeclareLaunchArgument(
        name='use_sim_time',
        default_value='false',
        description='Use simulation (Gazebo) clock if true'
    )

    # Robot State Publisher Node
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{
            'robot_description': Command(['xacro ', LaunchConfiguration('urdf_file')]),
            'use_sim_time': LaunchConfiguration('use_sim_time')
        }]
    )

    # Joint State Publisher Node (without GUI)
    joint_state_publisher_node = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        parameters=[{'use_sim_time': LaunchConfiguration('use_sim_time')}],
        condition=UnlessCondition(LaunchConfiguration('gui'))
    )

    # Joint State Publisher GUI Node (only if package exists)
    nodes = [
        urdf_file_arg,
        gui_arg,
        rviz_config_arg,
        use_sim_time_arg,
        robot_state_publisher_node,
        joint_state_publisher_node,
    ]
    
    # Try to add GUI node if package is available
    try:
        from ament_index_python.packages import get_package_share_directory
        get_package_share_directory('joint_state_publisher_gui')
        
        joint_state_publisher_gui_node = Node(
            package='joint_state_publisher_gui',
            executable='joint_state_publisher_gui',
            parameters=[{'use_sim_time': LaunchConfiguration('use_sim_time')}],
            condition=IfCondition(LaunchConfiguration('gui'))
        )
        nodes.append(joint_state_publisher_gui_node)
    except:
        pass  # GUI package not available, skip it

    # RViz Node
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', LaunchConfiguration('rvizconfig')],
        parameters=[{'use_sim_time': LaunchConfiguration('use_sim_time')}]
    )
    nodes.append(rviz_node)

    return LaunchDescription(nodes)
